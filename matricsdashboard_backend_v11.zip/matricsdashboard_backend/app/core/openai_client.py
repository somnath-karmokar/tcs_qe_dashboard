from openai import OpenAI, AzureOpenAI
from app.core.config import (
    USE_AZURE_OPENAI,
    OPENAI_API_KEY,
    OPENAI_MODEL,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    OPENAI_API_VERSION,
    AZURE_OPENAI_CHAT_DEPLOYMENT_NAME
)

if USE_AZURE_OPENAI:
    client = AzureOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=OPENAI_API_VERSION,
        timeout=12.0,
        max_retries=0,
    )
else:
    client = OpenAI(
        api_key=OPENAI_API_KEY,
        timeout=12.0,
        max_retries=0,
    )

def call_openai(prompt):
    kwargs = {
        "messages": [{"role": "user", "content": prompt}],
        "response_format": {"type": "json_object"}
    }
    
    if USE_AZURE_OPENAI:
        kwargs["model"] = AZURE_OPENAI_CHAT_DEPLOYMENT_NAME
    else:
        kwargs["model"] = OPENAI_MODEL
        
    response = client.chat.completions.create(**kwargs)
    return response.choices[0].message.content
