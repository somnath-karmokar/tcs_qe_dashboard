from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.core.config import CHROMA_DB_DIR

_DB: Any | None = None


@dataclass
class _FallbackDoc:
    page_content: str


class _FallbackVectorStore:
    def __init__(self) -> None:
        self._texts: list[str] = []

    def add_texts(self, texts: list[str]) -> None:
        self._texts.extend(texts)

    def persist(self) -> None:
        return

    def similarity_search(self, query: str, k: int = 5) -> list[_FallbackDoc]:
        query_lower = query.lower()
        ranked = sorted(
            self._texts,
            key=lambda text: (
                query_lower not in text.lower(),
                abs(len(text) - len(query)),
            ),
        )
        return [_FallbackDoc(page_content=text) for text in ranked[:k]]


def _build_db() -> Any:
    try:
        from langchain_community.vectorstores import Chroma
        from app.core.config import (
            USE_AZURE_OPENAI,
            OPENAI_API_VERSION,
            AZURE_OPENAI_ENDPOINT,
            AZURE_OPENAI_API_KEY,
            AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME
        )
        
        if USE_AZURE_OPENAI:
            from langchain_openai import AzureOpenAIEmbeddings
            embeddings = AzureOpenAIEmbeddings(
                azure_deployment=AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME,
                openai_api_version=OPENAI_API_VERSION,
                azure_endpoint=AZURE_OPENAI_ENDPOINT,
                api_key=AZURE_OPENAI_API_KEY,
            )
        else:
            from langchain_openai import OpenAIEmbeddings
            embeddings = OpenAIEmbeddings()
            
    except Exception as e:
        print(f"Error loading embeddings: {e}")
        return _FallbackVectorStore()

    try:
        return Chroma(
            collection_name="kpi_collection",
            embedding_function=embeddings,
            persist_directory=CHROMA_DB_DIR,
        )
    except Exception:
        return _FallbackVectorStore()


def _get_db() -> Any:
    global _DB
    if _DB is None:
        _DB = _build_db()
    return _DB


def add_texts(texts: list[str]) -> None:
    db = _get_db()
    db.add_texts(texts)
    db.persist()


def search(query: str, k: int = 5):
    db = _get_db()
    return db.similarity_search(query, k=k)
