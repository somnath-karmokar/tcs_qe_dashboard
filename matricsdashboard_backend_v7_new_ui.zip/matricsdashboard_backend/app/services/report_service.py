
from app.services.analysis_service import analyze_kpi

def generate_report(query):
    analysis = analyze_kpi(query)

    return {
        "report": {
            "executive_summary": analysis.get("ai_analysis"),
            "trend": analysis.get("trend"),
            "anomalies": analysis.get("anomalies")
        }
    }
