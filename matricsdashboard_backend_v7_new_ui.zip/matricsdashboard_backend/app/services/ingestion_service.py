
from app.core.vector_db import add_texts
from app.services.kpi_data_service import add_kpi_record
from datetime import datetime


def _pick_column(columns, candidates):
    for candidate in candidates:
        if candidate in columns:
            return candidate
    return None

def process_kpi_file(df):
    texts = []
    grouped = df.groupby("Metric Name")
    date_col = _pick_column(df.columns, ["Date", "date", "Month", "month"])
    project_col = _pick_column(df.columns, ["Project", "project"])
    team_col = _pick_column(df.columns, ["Team", "team"])

    rows_processed = 0
    default_date = datetime.utcnow().strftime("%Y-%m")

    for name, group in grouped:
        values = group["Value"].tolist()
        trend = "increasing" if values[-1] > values[0] else "decreasing"

        text = f"KPI: {name}, Values: {values}, Trend: {trend}"
        texts.append(text)

    for _, row in df.iterrows():
        try:
            metric_name = str(row["Metric Name"]).strip()
            value = float(row["Value"])
            date = str(row[date_col]).strip() if date_col else default_date
            project = str(row[project_col]).strip() if project_col else "Unknown Project"
            team = str(row[team_col]).strip() if team_col else "Unknown Team"
            add_kpi_record(
                metric_name=metric_name,
                value=value,
                date=date,
                project=project,
                team=team,
            )
            rows_processed += 1
        except Exception:
            continue

    add_texts(texts)
    return rows_processed
