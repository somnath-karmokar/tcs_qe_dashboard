
from app.core.vector_db import search
from app.core.openai_client import call_openai
import numpy as np

def detect_anomalies(values):
    mean = np.mean(values)
    std = np.std(values)
    return [v for v in values if abs(v - mean) > 1.5 * std]

def compute_trend(values):
    return "increasing" if values[-1] > values[0] else "decreasing"

def analyze_kpi(query):
    docs = search(query)
    context = "\n".join([d.page_content for d in docs])

    # Example simulated KPI values
    values = [10, 15, 18, 40, 22]

    anomalies = detect_anomalies(values)
    trend = compute_trend(values)

    prompt = f"""
    Context:
    {context}

    KPI Values: {values}
    Trend: {trend}
    Anomalies: {anomalies}

    Provide structured JSON:
    {{
      "summary": "",
      "risks": [],
      "recommendations": [],
      "trend": "{trend}",
      "anomalies": {anomalies}
    }}
    """

    response = call_openai(prompt)

    return {
        "ai_analysis": response,
        "trend": trend,
        "anomalies": anomalies
    }
