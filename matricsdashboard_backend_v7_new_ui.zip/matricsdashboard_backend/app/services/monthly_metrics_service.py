from __future__ import annotations

import json
import os
import re
import time
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

from app.core.openai_client import call_openai

DATA_DIR = Path("app/data")
MONTHLY_METRICS_PATH = DATA_DIR / "monthly_category_metrics.json"
MONTHLY_ANALYSIS_PATH = DATA_DIR / "monthly_category_analysis.json"
DOMAIN_PORTFOLIOS_PATH = DATA_DIR / "domain_portfolios.json"
DEFAULT_INSIGHTS_DOC_PATH = DATA_DIR / "QE_AI_Insights_Concise.docx"
FALLBACK_INSIGHTS_DOC_PATH = Path(r"C:\Users\Somnath\Downloads\QE_AI_Insights_Concise.docx")
DEFAULT_DOMAIN = "Unassigned"
DEFAULT_PORTFOLIO = "General"


def _pick_key(data: dict[str, Any], candidates: list[str]) -> Any | None:
    key_lookup = {_normalize_key(str(key)): key for key in data.keys()}
    for candidate in candidates:
        match = key_lookup.get(_normalize_key(candidate))
        if match is not None:
            return data.get(match)
    return None


def _normalize_key(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("\u200b", "").strip().lower())


def _clean_text(value: Any) -> str:
    return str(value).replace("\u200b", "").strip()


def _is_missing_text(value: str) -> bool:
    return value.strip().lower() in {"", "nan", "none", "null", "na", "n/a"}


def _parse_month_id(value: str) -> str:
    text = value.strip()
    if re.fullmatch(r"\d{4}-\d{2}", text):
        datetime.strptime(text, "%Y-%m")
        return text
    for fmt in ("%b %Y", "%B %Y"):
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m")
        except ValueError:
            continue
    raise ValueError("Invalid month format. Use YYYY-MM or 'Mon YYYY'.")


def _month_label(month_id: str) -> str:
    return datetime.strptime(month_id, "%Y-%m").strftime("%b %Y")


def _safe_round(value: float) -> float | int:
    rounded = round(float(value), 2)
    if float(rounded).is_integer():
        return int(rounded)
    return rounded


def _read_json(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default


def _insights_doc_path() -> Path | None:
    env_value = os.getenv("QE_AI_INSIGHTS_DOC_PATH", "").strip()
    if env_value:
        path = Path(env_value)
        if path.exists():
            return path
    if DEFAULT_INSIGHTS_DOC_PATH.exists():
        return DEFAULT_INSIGHTS_DOC_PATH
    if FALLBACK_INSIGHTS_DOC_PATH.exists():
        return FALLBACK_INSIGHTS_DOC_PATH
    return None


def _load_doc_insight_points() -> list[str]:
    insights = _load_doc_insights()
    points: list[str] = []
    for item in insights:
        title = str(item.get("title", "")).strip()
        description = str(item.get("description", "")).strip()
        example = str(item.get("example", "")).strip()
        if title:
            points.append(title)
        if description:
            points.append(description)
        if example:
            points.append(f"Example: {example}")
    return points


def _load_doc_insights() -> list[dict[str, str]]:
    path = _insights_doc_path()
    if path is None:
        return []

    try:
        from docx import Document  # type: ignore
    except ImportError:
        return []

    try:
        document = Document(path)
    except Exception:
        return []

    insights: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    for paragraph in document.paragraphs:
        text = _clean_text(paragraph.text)
        if _is_missing_text(text):
            continue
        if text.lower().startswith("qe dashboard ai insights"):
            continue
        heading = re.fullmatch(r"(\d+)\.\s+(.+)", text)
        if heading:
            if current:
                insights.append(current)
            current = {
                "title": heading.group(2).strip(),
                "description": "",
                "example": "",
            }
            continue
        if current is None:
            continue

        if text.lower().startswith("example:"):
            current["example"] = text.split(":", 1)[1].strip()
        elif not current.get("description"):
            current["description"] = text
        else:
            current["description"] = f"{current['description']} {text}".strip()

    if current:
        insights.append(current)

    deduped: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in insights:
        title_key = item.get("title", "").lower()
        if not title_key or title_key in seen:
            continue
        seen.add(title_key)
        deduped.append(item)
    return deduped


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8")


def _base_store() -> dict[str, Any]:
    return {"dashboard_title": "Quality Engineering Dashboard", "months": []}


def _base_domain_store() -> dict[str, Any]:
    return {"domains": []}


def _clean_optional_label(value: Any, fallback: str) -> str:
    text = _clean_text(value) if value is not None else ""
    return fallback if _is_missing_text(text) else text


def _ensure_domain_portfolio(domain: str, portfolio: str) -> dict[str, Any]:
    domain_text = _clean_optional_label(domain, DEFAULT_DOMAIN)
    portfolio_text = _clean_optional_label(portfolio, DEFAULT_PORTFOLIO)
    store = _read_json(DOMAIN_PORTFOLIOS_PATH, _base_domain_store())
    domains = store.setdefault("domains", [])

    match = None
    for item in domains:
        if str(item.get("name", "")).strip().lower() == domain_text.lower():
            match = item
            break
    if match is None:
        match = {"name": domain_text, "portfolios": []}
        domains.append(match)

    portfolios = match.setdefault("portfolios", [])
    if not any(str(item).strip().lower() == portfolio_text.lower() for item in portfolios):
        portfolios.append(portfolio_text)
        match["portfolios"] = sorted(portfolios, key=lambda item: str(item).lower())

    store["domains"] = sorted(domains, key=lambda item: str(item.get("name", "")).lower())
    _write_json(DOMAIN_PORTFOLIOS_PATH, store)
    return {"domain": domain_text, "portfolio": portfolio_text}


def list_domain_portfolios() -> list[dict[str, Any]]:
    store = _read_json(DOMAIN_PORTFOLIOS_PATH, _base_domain_store())
    return [
        {
            "name": str(item.get("name", "")).strip(),
            "portfolios": [
                str(portfolio).strip()
                for portfolio in item.get("portfolios", [])
                if str(portfolio).strip()
            ],
        }
        for item in store.get("domains", [])
        if str(item.get("name", "")).strip()
    ]


def create_domain_portfolio(domain: str, portfolio: str | None = None) -> dict[str, Any]:
    return _ensure_domain_portfolio(domain, portfolio or DEFAULT_PORTFOLIO)


def _normalize_rows(
    rows: list[dict[str, Any]],
    month_id: str,
    default_domain: str = DEFAULT_DOMAIN,
    default_portfolio: str = DEFAULT_PORTFOLIO,
) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    for row in rows:
        category = _pick_key(row, ["category", "dimension"])
        metric_name = _pick_key(row, ["metric_name", "metric", "metrics", "kpi_name", "kpiname", "name"])
        value = _extract_value(row, metric_name=metric_name)
        unit = _pick_key(row, ["unit", "uom"])
        domain = _pick_key(row, ["domain", "business_domain", "business domain"])
        portfolio = _pick_key(row, ["portfolio", "porfolio", "project_portfolio", "project portfolio"])

        if category is None or metric_name is None or value is None:
            continue

        try:
            numeric_value = float(str(value).strip())
        except ValueError:
            continue

        metric_name_text = _clean_text(metric_name)
        category_text = _clean_text(category)
        if _is_missing_text(metric_name_text) or _is_missing_text(category_text):
            continue
        unit_text = _clean_text(unit) if unit is not None else ""
        if not unit_text:
            guidelines = _clean_text(_pick_key(row, ["guidelines"]) or "")
            if "%" in metric_name_text or "%" in guidelines:
                unit_text = "%"

        normalized.append(
            {
                "category": category_text,
                "domain": _clean_optional_label(domain, default_domain),
                "portfolio": _clean_optional_label(portfolio, default_portfolio),
                "metric_name": metric_name_text,
                "value": numeric_value,
                "unit": unit_text,
                "month_id": month_id,
            }
        )
    return normalized


def _to_number(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = _clean_text(value)
    if not text:
        return None
    text = text.replace(",", "")
    text = re.sub(r"[^0-9.\-]+", "", text)
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _extract_value(row: dict[str, Any], metric_name: Any) -> float | None:
    # Preferred explicit value columns.
    explicit = _pick_key(
        row,
        [
            "value",
            "metric_value",
            "score",
            "current_value",
            "current month value",
            "actual",
            "actual value",
            "result",
        ],
    )
    explicit_num = _to_number(explicit)
    if explicit_num is not None:
        return explicit_num

    # Support files where raw data points are provided instead of direct value.
    numeric_points: list[float] = []
    for key, raw_value in row.items():
        key_norm = _normalize_key(str(key))
        if key_norm.startswith("data to be captured"):
            num = _to_number(raw_value)
            if num is not None:
                numeric_points.append(num)

    if not numeric_points:
        return None
    if len(numeric_points) == 1:
        return numeric_points[0]

    metric_text = _clean_text(metric_name).lower() if metric_name is not None else ""
    hints = f"{metric_text} {_clean_text(_pick_key(row, ['guidelines']) or '')}".lower()
    if "%" in hints and numeric_points[0] != 0:
        numerator = numeric_points[1]
        denominator = numeric_points[0]
        if numerator <= denominator:
            return (numerator / denominator) * 100.0

    # Otherwise use the second captured point as the closest "result-like" value.
    return numeric_points[1]


def upload_monthly_rows(
    rows: list[dict[str, Any]],
    month: str,
    dashboard_title: str = "Quality Engineering Dashboard",
    domain: str = DEFAULT_DOMAIN,
    portfolio: str = DEFAULT_PORTFOLIO,
) -> dict[str, Any]:
    month_id = _parse_month_id(month)
    defaults = _ensure_domain_portfolio(domain, portfolio)
    normalized = _normalize_rows(
        rows,
        month_id,
        default_domain=defaults["domain"],
        default_portfolio=defaults["portfolio"],
    )
    if not normalized:
        raise ValueError(
            "No valid rows found. Required columns: category/dimension, metric_name/metric/kpiname, value, optional unit."
        )

    categories: OrderedDict[str, list[dict[str, Any]]] = OrderedDict()
    for row in normalized:
        categories.setdefault(row["category"], []).append(
            {
                "name": row["metric_name"],
                "value": _safe_round(row["value"]),
                "unit": row["unit"] or "",
                "domain": row["domain"],
                "portfolio": row["portfolio"],
            }
        )

    snapshot = {
        "dashboard": {"title": dashboard_title.strip() or "Quality Engineering Dashboard", "month": _month_label(month_id)},
        "month_id": month_id,
        "categories": [{"name": key, "metrics": value} for key, value in categories.items()],
        "updated_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }

    store = _read_json(MONTHLY_METRICS_PATH, _base_store())
    store["dashboard_title"] = snapshot["dashboard"]["title"]
    months = [entry for entry in store.get("months", []) if entry.get("month_id") != month_id]
    months.append(snapshot)
    months = sorted(months, key=lambda item: item.get("month_id", ""))
    store["months"] = months
    _write_json(MONTHLY_METRICS_PATH, store)

    return {
        "status": "success",
        "month_id": month_id,
        "month": _month_label(month_id),
        "categories_count": len(snapshot["categories"]),
        "metrics_count": sum(len(category["metrics"]) for category in snapshot["categories"]),
        "domain": defaults["domain"],
        "portfolio": defaults["portfolio"],
        "storage_path": str(MONTHLY_METRICS_PATH),
    }


def _latest_snapshot(month_id: str | None = None) -> dict[str, Any]:
    store = _read_json(MONTHLY_METRICS_PATH, _base_store())
    months = sorted(store.get("months", []), key=lambda item: item.get("month_id", ""))
    if not months:
        raise ValueError("No monthly category metrics found. Upload monthly sheet data first.")
    if month_id is None:
        return months[-1]
    normalized_month = _parse_month_id(month_id)
    for snapshot in months:
        if snapshot.get("month_id") == normalized_month:
            return snapshot
    raise ValueError(f"Month '{normalized_month}' not found in monthly metric store.")


def list_uploaded_months() -> list[dict[str, str]]:
    store = _read_json(MONTHLY_METRICS_PATH, _base_store())
    months = sorted(store.get("months", []), key=lambda item: item.get("month_id", ""))
    return [{"month_id": item["month_id"], "month": _month_label(item["month_id"])} for item in months if item.get("month_id")]


def delete_monthly_history(month: str) -> dict[str, Any]:
    month_id = _parse_month_id(month)

    metrics_store = _read_json(MONTHLY_METRICS_PATH, _base_store())
    months = metrics_store.get("months", [])
    initial_month_count = len(months)
    filtered_months = [item for item in months if item.get("month_id") != month_id]
    deleted_month_records = initial_month_count - len(filtered_months)
    metrics_store["months"] = filtered_months
    _write_json(MONTHLY_METRICS_PATH, metrics_store)

    analysis_store = _read_json(MONTHLY_ANALYSIS_PATH, {"analyses": []})
    analyses = analysis_store.get("analyses", [])
    initial_analysis_count = len(analyses)
    filtered_analyses = [item for item in analyses if item.get("month_id") != month_id]
    deleted_analysis_records = initial_analysis_count - len(filtered_analyses)
    analysis_store["analyses"] = filtered_analyses
    _write_json(MONTHLY_ANALYSIS_PATH, analysis_store)

    return {
        "status": "success",
        "month_id": month_id,
        "deleted_month_records": deleted_month_records,
        "deleted_analysis_records": deleted_analysis_records,
    }


def delete_all_monthly_history() -> dict[str, Any]:
    metrics_store = _read_json(MONTHLY_METRICS_PATH, _base_store())
    analysis_store = _read_json(MONTHLY_ANALYSIS_PATH, {"analyses": []})

    deleted_month_records = len(metrics_store.get("months", []))
    deleted_analysis_records = len(analysis_store.get("analyses", []))

    _write_json(MONTHLY_METRICS_PATH, _base_store())
    _write_json(MONTHLY_ANALYSIS_PATH, {"analyses": []})

    return {
        "status": "success",
        "deleted_month_records": deleted_month_records,
        "deleted_analysis_records": deleted_analysis_records,
    }


def _metric_identity(category_name: str, metric: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        category_name,
        str(metric.get("name", "")).strip(),
        _clean_optional_label(metric.get("domain"), DEFAULT_DOMAIN),
        _clean_optional_label(metric.get("portfolio"), DEFAULT_PORTFOLIO),
    )


def _metric_series(selected_months: list[dict[str, Any]]) -> dict[tuple[str, str, str, str], dict[str, Any]]:
    metric_lookup: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for snapshot in selected_months:
        label = snapshot["dashboard"]["month"]
        month_id = snapshot["month_id"]
        for category in snapshot.get("categories", []):
            category_name = str(category.get("name", "")).strip()
            for metric in category.get("metrics", []):
                metric_name = str(metric.get("name", "")).strip()
                domain = _clean_optional_label(metric.get("domain"), DEFAULT_DOMAIN)
                portfolio = _clean_optional_label(metric.get("portfolio"), DEFAULT_PORTFOLIO)
                key = (category_name, metric_name, domain, portfolio)
                metric_lookup.setdefault(
                    key,
                    {
                        "category": category_name,
                        "name": metric_name,
                        "domain": domain,
                        "portfolio": portfolio,
                        "unit": metric.get("unit", ""),
                        "points": {},
                    },
                )
                metric_lookup[key]["points"][month_id] = {
                    "month": label,
                    "month_id": month_id,
                    "value": float(metric.get("value", 0)),
                }
    return metric_lookup


def _latest_analysis(month_id: str | None = None) -> dict[str, Any] | None:
    store = _read_json(MONTHLY_ANALYSIS_PATH, {"analyses": []})
    analyses = sorted(store.get("analyses", []), key=lambda item: item.get("month_id", ""))
    if not analyses:
        return None
    if month_id is None:
        return analyses[-1]
    normalized = _parse_month_id(month_id)
    for item in analyses:
        if item.get("month_id") == normalized:
            return item
    return None


def get_frontend_metrics(
    month: str | None = None,
    history_months: int = 6,
    ensure_analysis: bool = False,
    refresh_analysis: bool = False,
    use_llm: bool = True,
    max_llm_metrics: int = 8,
    llm_time_budget_seconds: int = 45,
) -> dict[str, Any]:
    if history_months < 1:
        raise ValueError("history_months must be at least 1.")

    store = _read_json(MONTHLY_METRICS_PATH, _base_store())
    months = sorted(store.get("months", []), key=lambda item: item.get("month_id", ""))
    if not months:
        raise ValueError("No monthly category metrics found. Upload monthly sheet data first.")

    target = _latest_snapshot(month)
    target_month_id = target["month_id"]
    month_analysis = _latest_analysis(target_month_id) or {}

    if ensure_analysis:
        llm_meta = month_analysis.get("llm_meta", {}) if isinstance(month_analysis, dict) else {}
        has_llm_analysis = bool(llm_meta.get("use_llm")) and int(llm_meta.get("llm_calls_used", 0) or 0) > 0
        has_generic_recommendations = False
        for row in (month_analysis.get("metric_month_analyses", []) if isinstance(month_analysis, dict) else []):
            if not isinstance(row, dict):
                continue
            if _is_generic_recommendation(str(row.get("recommendation", ""))):
                has_generic_recommendations = True
                break

        should_refresh = (
            bool(refresh_analysis)
            or not month_analysis
            or (bool(use_llm) and not has_llm_analysis)
            or has_generic_recommendations
        )
        if should_refresh:
            try:
                start_monthly_analysis(
                    month=target_month_id,
                    lookback_months=max(1, int(history_months)),
                    use_llm=bool(use_llm),
                    max_llm_metrics=int(max_llm_metrics),
                    llm_time_budget_seconds=int(llm_time_budget_seconds),
                    analyze_all_months=False,
                )
                month_analysis = _latest_analysis(target_month_id) or {}
            except Exception:
                # Keep response functional even if analysis generation fails.
                month_analysis = month_analysis or {}
    analysis_by_metric: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for row in month_analysis.get("metric_month_analyses", []):
        category = str(row.get("category", "")).strip()
        metric_name = str(row.get("metric_name", "")).strip()
        domain = _clean_optional_label(row.get("domain"), DEFAULT_DOMAIN)
        portfolio = _clean_optional_label(row.get("portfolio"), DEFAULT_PORTFOLIO)
        if not category or not metric_name:
            continue
        analysis_by_metric[(category, metric_name, domain, portfolio)] = row

    analysis_store = _read_json(MONTHLY_ANALYSIS_PATH, {"analyses": []})
    analysis_index: dict[tuple[str, str, str, str, str], dict[str, Any]] = {}
    for month_entry in analysis_store.get("analyses", []):
        month_id = str(month_entry.get("month_id", "")).strip()
        for row in month_entry.get("metric_month_analyses", []):
            category = str(row.get("category", "")).strip()
            metric_name = str(row.get("metric_name", "")).strip()
            domain = _clean_optional_label(row.get("domain"), DEFAULT_DOMAIN)
            portfolio = _clean_optional_label(row.get("portfolio"), DEFAULT_PORTFOLIO)
            if not month_id or not category or not metric_name:
                continue
            analysis_index[(month_id, category, metric_name, domain, portfolio)] = row

    all_ids = [item["month_id"] for item in months if item.get("month_id")]
    target_idx = all_ids.index(target_month_id)
    start_idx = max(0, target_idx - history_months)
    selected = months[start_idx : target_idx + 1]
    selected_ids = [item["month_id"] for item in selected]

    series = _metric_series(selected)
    selected_id_to_label = {item["month_id"]: item["dashboard"]["month"] for item in selected}

    categories: list[dict[str, Any]] = []
    for category in target.get("categories", []):
        metrics: list[dict[str, Any]] = []
        category_name = str(category.get("name", "")).strip()
        for metric in category.get("metrics", []):
            metric_name = str(metric.get("name", "")).strip()
            domain = _clean_optional_label(metric.get("domain"), DEFAULT_DOMAIN)
            portfolio = _clean_optional_label(metric.get("portfolio"), DEFAULT_PORTFOLIO)
            key = (category_name, metric_name, domain, portfolio)
            points_map = series.get(key, {}).get("points", {})
            full_history = []
            for month_id in reversed(selected_ids):
                point = points_map.get(month_id)
                if point is None:
                    full_history.append(
                        {"month": selected_id_to_label[month_id], "month_id": month_id, "value": None}
                    )
                else:
                    full_history.append(
                        {
                            "month": point["month"],
                            "month_id": point["month_id"],
                            "value": _safe_round(point["value"]),
                        }
                    )
            metrics.append(
                {
                    "name": metric_name,
                    "value": metric.get("value"),
                    "unit": metric.get("unit", ""),
                    "domain": domain,
                    "portfolio": portfolio,
                    "history": full_history,
                    "past_6_months": full_history[1:],
                    "analysis": analysis_by_metric.get((category_name, metric_name, domain, portfolio)),
                    "insights": (analysis_by_metric.get((category_name, metric_name, domain, portfolio)) or {}).get("insights", []),
                    "analysis_history": [
                        analysis_index.get((month_id, category_name, metric_name, domain, portfolio))
                        for month_id in reversed(selected_ids)
                    ],
                }
            )
        categories.append({"name": category_name, "metrics": metrics})

    return {
        "dashboard": target["dashboard"],
        "month_id": target_month_id,
        "categories": categories,
        "domain_portfolios": list_domain_portfolios(),
        "history_window_months": history_months,
        "months_available": [{"month_id": item["month_id"], "month": item["dashboard"]["month"]} for item in months],
        "analysis": month_analysis if month_analysis else None,
    }


def _fallback_metric_analysis(metric: dict[str, Any]) -> dict[str, Any]:
    current = float(metric["current_value"])
    history_values = [float(item["value"]) for item in metric["past_6_months"] if item["value"] is not None]

    if history_values:
        avg_history = float(np.mean(history_values))
        change = current - avg_history
        change_pct = (change / abs(avg_history) * 100.0) if avg_history != 0 else 0.0
    else:
        avg_history = current
        change = 0.0
        change_pct = 0.0

    if change_pct >= 5:
        trend = "improving"
        risk = "low"
    elif change_pct <= -10:
        trend = "declining"
        risk = "high"
    else:
        trend = "stable"
        risk = "medium"

    generated_metric = (current * 0.6) + (avg_history * 0.4)
    summary = (
        f"Current value is {current:.2f} versus a six-month average of {avg_history:.2f} "
        f"({change_pct:+.1f}% variance)."
    )
    if risk == "high":
        recommendation = (
            "Immediate corrective action is recommended: assign an owner, run a focused root-cause review, "
            "and execute a 2-4 week recovery plan with weekly checkpoints."
        )
    elif risk == "medium":
        recommendation = (
            "Stabilize performance by reviewing process deviations, tightening quality gates, and "
            "tracking this KPI in weekly governance until trend improves."
        )
    else:
        recommendation = (
            "Performance is stable. Scale current best practices, document winning patterns, and "
            "continue proactive monitoring through monthly leadership review."
        )

    return {
        "trend": trend,
        "risk": risk,
        "summary": summary,
        "recommendation": recommendation,
        "generated_metric": _safe_round(generated_metric),
        "change_vs_avg_pct": round(change_pct, 2),
    }


def _is_generic_recommendation(text: str) -> bool:
    normalized = str(text or "").strip().lower()
    if not normalized:
        return True
    generic_markers = [
        "maintain current approach",
        "monitor trend monthly",
        "continue monitoring",
        "keep monitoring",
        "review and monitor",
        "no action needed",
    ]
    return any(marker in normalized for marker in generic_markers)


def _build_professional_recommendation(
    metric_context: dict[str, Any],
    trend: str,
    risk: str,
    change_vs_avg_pct: float,
) -> str:
    metric_name = str(metric_context.get("metric_name", "this KPI")).strip() or "this KPI"
    risk_l = str(risk or "").strip().lower()
    trend_l = str(trend or "").strip().lower()

    if risk_l == "high" or change_vs_avg_pct <= -10:
        return (
            f"{metric_name} requires immediate recovery action: assign a metric owner, run a root-cause workshop "
            f"within 48 hours, and execute a 30-day improvement plan with weekly checkpoint reviews and target-based closure."
        )
    if risk_l == "medium" or trend_l == "stable":
        return (
            f"Stabilize {metric_name} through focused process tuning: validate input quality, tighten quality gates, "
            f"and track weekly leading indicators for the next two cycles to prevent slippage."
        )
    return (
        f"Scale the current momentum for {metric_name}: standardize successful practices across teams, "
        f"set stretch targets for the next cycle, and monitor early-warning indicators to sustain gains."
    )


def _llm_metric_analysis(metric: dict[str, Any]) -> dict[str, Any]:
    prompt = f"""
You are a quality engineering KPI analyst.
Use the current metric and the past six months data to generate insight.
Return strict JSON with keys:
trend, risk, summary, recommendation, generated_metric, change_vs_avg_pct, insights
Recommendation must be concrete and execution-oriented.
Do NOT use generic wording such as "Maintain current approach and monitor trend monthly."

insights must be a JSON array with 4 objects and keys:
title, description, example
Use these titles exactly:
1) Anomaly Detection
2) Trend Forecasting
3) Root Cause Analysis
4) Prescriptive Recommendations

Metric input:
{json.dumps(metric, ensure_ascii=True)}
""".strip()

    parsed = json.loads(call_openai(prompt))
    raw_insights = parsed.get("insights", [])
    normalized_insights: list[dict[str, str]] = []
    if isinstance(raw_insights, list):
        for item in raw_insights[:4]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title", "")).strip()
            description = str(item.get("description", "")).strip()
            example = str(item.get("example", "")).strip()
            if not title and not description:
                continue
            normalized_insights.append(
                {
                    "title": title,
                    "description": description,
                    "example": example,
                }
            )
    return {
        "trend": str(parsed.get("trend", "stable")),
        "risk": str(parsed.get("risk", "medium")),
        "summary": str(parsed.get("summary", "")),
        "recommendation": str(parsed.get("recommendation", "")),
        "generated_metric": parsed.get("generated_metric"),
        "change_vs_avg_pct": parsed.get("change_vs_avg_pct"),
        "insights": normalized_insights,
    }


def _fallback_dynamic_insights(metric_context: dict[str, Any], ai_result: dict[str, Any]) -> list[dict[str, str]]:
    metric_name = str(metric_context.get("metric_name", "Metric")).strip()
    current = float(metric_context.get("current_value", 0) or 0)
    history = [item for item in metric_context.get("past_6_months", []) if item.get("value") is not None]
    history_values = [float(item["value"]) for item in history]
    avg_history = float(np.mean(history_values)) if history_values else current
    delta_pct = float(ai_result.get("change_vs_avg_pct", 0) or 0)
    trend = str(ai_result.get("trend", "stable")).lower()
    generated_metric = ai_result.get("generated_metric", "NA")

    if abs(delta_pct) >= 10:
        anomaly_desc = (
            f"{metric_name} shows a significant shift of {delta_pct:+.1f}% compared to the six-month average "
            f"({avg_history:.2f})."
        )
    else:
        anomaly_desc = (
            f"{metric_name} is within normal variation at {delta_pct:+.1f}% versus the six-month average "
            f"({avg_history:.2f})."
        )

    if trend == "declining":
        forecast_desc = (
            f"Current trend is declining; projected next value is around {generated_metric} if current pattern continues."
        )
    elif trend == "improving":
        forecast_desc = (
            f"Current trend is improving; projected next value is around {generated_metric} with current momentum."
        )
    else:
        forecast_desc = (
            f"Current trend is stable; projected next value is around {generated_metric} based on recent history."
        )

    root_desc = str(ai_result.get("summary", "")).strip() or (
        f"{metric_name} performance is influenced by recent delivery and quality patterns across the last six months."
    )
    rec_desc = str(ai_result.get("recommendation", "")).strip() or (
        f"Review sprint actions and define targeted improvements for {metric_name} in the next cycle."
    )

    return [
        {
            "title": "Anomaly Detection",
            "description": anomaly_desc,
            "example": f"{metric_name} moved from historical average {avg_history:.2f} to current {current:.2f}.",
        },
        {
            "title": "Trend Forecasting",
            "description": forecast_desc,
            "example": f"Next-cycle estimate for {metric_name} is {generated_metric}.",
        },
        {
            "title": "Root Cause Analysis",
            "description": root_desc,
            "example": f"Recent six-month movement for {metric_name} is {delta_pct:+.1f}% vs average.",
        },
        {
            "title": "Prescriptive Recommendations",
            "description": rec_desc,
            "example": f"Prioritize actions that improve {metric_name} in the next sprint/release.",
        },
    ]


def _build_month_level_insights(metric_month_analyses: list[dict[str, Any]]) -> list[dict[str, str]]:
    if not metric_month_analyses:
        return []

    changes = [float(item.get("change_vs_avg_pct", 0) or 0) for item in metric_month_analyses]
    declining = [item for item in metric_month_analyses if str(item.get("trend", "")).lower() == "declining"]
    improving = [item for item in metric_month_analyses if str(item.get("trend", "")).lower() == "improving"]

    top_shift = sorted(
        metric_month_analyses,
        key=lambda item: abs(float(item.get("change_vs_avg_pct", 0) or 0)),
        reverse=True,
    )[0]
    top_metric_name = str(top_shift.get("metric_name", "metric"))
    top_shift_pct = float(top_shift.get("change_vs_avg_pct", 0) or 0)
    avg_shift = float(np.mean(changes)) if changes else 0.0

    return [
        {
            "title": "Anomaly Detection",
            "description": f"Largest metric shift this month is {top_metric_name} at {top_shift_pct:+.1f}% vs six-month average.",
            "example": f"Total declining metrics: {len(declining)} out of {len(metric_month_analyses)}.",
        },
        {
            "title": "Trend Forecasting",
            "description": f"Overall average shift across metrics is {avg_shift:+.1f}% for the selected month.",
            "example": f"Improving metrics: {len(improving)}; declining metrics: {len(declining)}.",
        },
        {
            "title": "Root Cause Analysis",
            "description": "Month-level variation suggests multiple metrics are moving together and need joint tracking.",
            "example": f"Top mover {top_metric_name} should be reviewed with related engineering and quality KPIs.",
        },
        {
            "title": "Prescriptive Recommendations",
            "description": "Focus on high-change metrics first and define sprint-level corrective actions with owners.",
            "example": "Track next-month recovery for high-risk metrics against generated targets.",
        },
    ]


def _compute_analysis_for_payload(
    payload: dict[str, Any],
    lookback_months: int,
    use_llm: bool,
    max_llm_metrics: int,
    llm_time_budget_seconds: int,
) -> dict[str, Any]:
    llm_started_at = time.perf_counter()
    llm_calls_attempted = 0
    llm_calls_used = 0
    metric_results: list[dict[str, Any]] = []
    metric_month_analyses: list[dict[str, Any]] = []

    for category in payload["categories"]:
        for metric in category["metrics"]:
            current_value = metric["value"]
            metric_context = {
                "category": category["name"],
                "metric_name": metric["name"],
                "domain": _clean_optional_label(metric.get("domain"), DEFAULT_DOMAIN),
                "portfolio": _clean_optional_label(metric.get("portfolio"), DEFAULT_PORTFOLIO),
                "unit": metric.get("unit", ""),
                "current_month": payload["dashboard"]["month"],
                "current_value": current_value,
                "past_6_months": metric.get("past_6_months", []),
            }
            fallback = _fallback_metric_analysis(metric_context)
            ai_result = fallback
            llm_budget_exhausted = (time.perf_counter() - llm_started_at) >= float(llm_time_budget_seconds)
            llm_quota_exhausted = llm_calls_attempted >= int(max_llm_metrics)
            if use_llm and not llm_budget_exhausted and not llm_quota_exhausted:
                llm_calls_attempted += 1
                try:
                    model_result = _llm_metric_analysis(metric_context)
                    ai_result = {**fallback, **{k: v for k, v in model_result.items() if v not in (None, "")}}
                    llm_calls_used += 1
                except Exception:
                    ai_result = fallback

            combined = {**metric_context, **ai_result}
            try:
                change_vs_avg = float(combined.get("change_vs_avg_pct", 0) or 0)
            except (TypeError, ValueError):
                change_vs_avg = 0.0

            if _is_generic_recommendation(str(combined.get("recommendation", ""))):
                combined["recommendation"] = _build_professional_recommendation(
                    metric_context=metric_context,
                    trend=str(combined.get("trend", "")),
                    risk=str(combined.get("risk", "")),
                    change_vs_avg_pct=change_vs_avg,
                )

            insights = combined.get("insights")
            if not isinstance(insights, list) or len(insights) == 0:
                combined["insights"] = _fallback_dynamic_insights(metric_context, combined)
            else:
                patched_insights: list[dict[str, str]] = []
                prescriptive_found = False
                for item in insights:
                    if not isinstance(item, dict):
                        continue
                    title = str(item.get("title", "")).strip()
                    description = str(item.get("description", "")).strip()
                    example = str(item.get("example", "")).strip()
                    is_prescriptive = "prescriptive" in title.lower() or "recommend" in title.lower()
                    if is_prescriptive:
                        prescriptive_found = True
                        if _is_generic_recommendation(description):
                            description = str(combined.get("recommendation", "")).strip()
                        if not example:
                            example = (
                                f"Define owner, target, and weekly checkpoints for {metric_context['metric_name']} "
                                f"until KPI trend improves."
                            )
                    patched_insights.append(
                        {"title": title, "description": description, "example": example}
                    )

                if not prescriptive_found:
                    patched_insights.append(
                        {
                            "title": "Prescriptive Recommendations",
                            "description": str(combined.get("recommendation", "")).strip(),
                            "example": (
                                f"Create an action register for {metric_context['metric_name']} with owner, "
                                "timeline, and weekly governance updates."
                            ),
                        }
                    )
                combined["insights"] = patched_insights[:4]
            metric_results.append(combined)
            metric_month_analyses.append(
                {
                    "metric_month_id": (
                        f"{payload['month_id']}::{metric_context['domain']}::"
                        f"{metric_context['portfolio']}::{metric_context['category']}::"
                        f"{metric_context['metric_name']}"
                    ),
                    "month_id": payload["month_id"],
                    "month": payload["dashboard"]["month"],
                    "category": metric_context["category"],
                    "domain": metric_context["domain"],
                    "portfolio": metric_context["portfolio"],
                    "metric_name": metric_context["metric_name"],
                    "unit": metric_context.get("unit", ""),
                    "current_value": metric_context.get("current_value"),
                    "past_6_months": metric_context.get("past_6_months", []),
                    "trend": combined.get("trend"),
                    "risk": combined.get("risk"),
                    "summary": combined.get("summary"),
                    "recommendation": combined.get("recommendation"),
                    "generated_metric": combined.get("generated_metric"),
                    "change_vs_avg_pct": combined.get("change_vs_avg_pct"),
                    "insights": combined.get("insights", []),
                    "generated_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
                }
            )

    generated_scores = [
        float(row["generated_metric"])
        for row in metric_results
        if isinstance(row.get("generated_metric"), (int, float))
    ]
    overall_generated = _safe_round(float(np.mean(generated_scores))) if generated_scores else None

    metric_wise_doc_insights = [
        {
            "metric_month_id": item.get("metric_month_id"),
            "month_id": item.get("month_id"),
            "month": item.get("month"),
            "category": item.get("category"),
            "domain": item.get("domain"),
            "portfolio": item.get("portfolio"),
            "metric_name": item.get("metric_name"),
            "insights": item.get("insights", []),
        }
        for item in metric_month_analyses
    ]
    month_level_points: list[str] = []
    for metric_item in metric_wise_doc_insights:
        metric_name = str(metric_item.get("metric_name", "")).strip()
        for insight in metric_item.get("insights", []):
            title = str(insight.get("title", "")).strip()
            description = str(insight.get("description", "")).strip()
            if metric_name and (title or description):
                month_level_points.append(f"{metric_name} | {title}: {description}".strip(": ").strip())

    return {
        "month_id": payload["month_id"],
        "month": payload["dashboard"]["month"],
        "lookback_months": lookback_months,
        "generated_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "overall_generated_metric": overall_generated,
        "llm_meta": {
            "use_llm": bool(use_llm),
            "max_llm_metrics": int(max_llm_metrics),
            "llm_time_budget_seconds": int(llm_time_budget_seconds),
            "llm_calls_attempted": int(llm_calls_attempted),
            "llm_calls_used": int(llm_calls_used),
            "used_fallback_for_remaining_metrics": bool(use_llm and llm_calls_attempted < len(metric_results)),
        },
        "doc_insights": metric_wise_doc_insights,
        "doc_insight_points": month_level_points,
        "metrics": metric_results,
        "metric_month_analyses": metric_month_analyses,
    }


def start_monthly_analysis(
    month: str | None = None,
    lookback_months: int = 6,
    use_llm: bool = True,
    max_llm_metrics: int = 3,
    llm_time_budget_seconds: int = 20,
    analyze_all_months: bool = True,
) -> dict[str, Any]:
    store = _read_json(MONTHLY_METRICS_PATH, _base_store())
    months = sorted(store.get("months", []), key=lambda item: item.get("month_id", ""))
    if not months:
        raise ValueError("No monthly category metrics found. Upload monthly sheet data first.")

    selected_month_id = _parse_month_id(month) if month else months[-1]["month_id"]
    known_month_ids = [item.get("month_id") for item in months if item.get("month_id")]
    if selected_month_id not in known_month_ids:
        raise ValueError(f"Month '{selected_month_id}' not found in monthly metric store.")

    month_ids_to_analyze = known_month_ids if analyze_all_months else [selected_month_id]

    analyses_by_month: dict[str, dict[str, Any]] = {}
    for month_id in month_ids_to_analyze:
        payload = get_frontend_metrics(month=month_id, history_months=lookback_months)
        analysis = _compute_analysis_for_payload(
            payload=payload,
            lookback_months=lookback_months,
            use_llm=use_llm,
            max_llm_metrics=max_llm_metrics,
            llm_time_budget_seconds=llm_time_budget_seconds,
        )
        analyses_by_month[month_id] = analysis

    store = _read_json(MONTHLY_ANALYSIS_PATH, {"analyses": []})
    analyses = [entry for entry in store.get("analyses", []) if entry.get("month_id") not in set(month_ids_to_analyze)]
    analyses.extend(analyses_by_month.values())
    analyses = sorted(analyses, key=lambda item: item.get("month_id", ""))
    store["analyses"] = analyses
    _write_json(MONTHLY_ANALYSIS_PATH, store)

    selected_analysis = analyses_by_month[selected_month_id]
    selected_analysis["analysis_run"] = {
        "analyzed_month_ids": month_ids_to_analyze,
        "analyzed_months_count": len(month_ids_to_analyze),
        "selected_month_id": selected_month_id,
    }
    return selected_analysis
