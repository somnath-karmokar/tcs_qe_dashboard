from fastapi import APIRouter, HTTPException

from app.services.kpi_data_service import get_recommendations, get_root_cause

router = APIRouter()


@router.get("/insights/root-cause/{metric}")
def root_cause(metric: str):
    try:
        return get_root_cause(metric)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.get("/insights/recommendations/{metric}")
def recommendations(metric: str):
    try:
        return get_recommendations(metric)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
