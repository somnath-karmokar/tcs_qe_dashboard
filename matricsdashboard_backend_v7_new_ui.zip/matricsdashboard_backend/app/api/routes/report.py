
from fastapi import APIRouter, Response
from app.services.report_service import generate_report

router = APIRouter()

@router.post("/report", deprecated=True)
def report(response: Response, data: dict):
    response.headers["Warning"] = '299 - "Deprecated endpoint. Use /api/dashboard/summary and /api/dashboard/summary/narrative instead."'
    try:
        payload = generate_report(data.get("query", "Generate KPI report"))
    except Exception as exc:
        payload = {"error": str(exc)}
    payload["warning"] = "Deprecated endpoint. Use /api/dashboard/summary and /api/dashboard/summary/narrative instead."
    return payload
