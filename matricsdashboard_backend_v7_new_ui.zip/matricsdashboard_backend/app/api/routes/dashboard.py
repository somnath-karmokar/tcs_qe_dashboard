from fastapi import APIRouter, HTTPException

from app.services.kpi_data_service import (
    get_dashboard_narrative,
    get_dashboard_summary,
    get_health_score,
)

router = APIRouter()


@router.get("/dashboard/summary")
def dashboard_summary():
    try:
        return get_dashboard_summary()
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.get("/dashboard/health-score")
def dashboard_health_score():
    try:
        return get_health_score()
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.get("/dashboard/summary/narrative")
def dashboard_narrative():
    try:
        return get_dashboard_narrative()
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
