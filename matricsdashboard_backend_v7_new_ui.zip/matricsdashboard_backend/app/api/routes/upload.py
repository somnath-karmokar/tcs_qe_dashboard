
from fastapi import APIRouter, UploadFile, File, Response
import pandas as pd
from app.services.ingestion_service import process_kpi_file

router = APIRouter()

@router.post("/upload", deprecated=True)
async def upload(response: Response, file: UploadFile = File(...)):
    response.headers["Warning"] = '299 - "Deprecated endpoint. Use /api/metrics/ingest instead."'
    df = pd.read_excel(file.file)
    result = process_kpi_file(df)
    return {
        "processed_rows": result,
        "warning": "Deprecated endpoint. Use /api/metrics/ingest instead.",
    }
