from pydantic import BaseModel
from fastapi import APIRouter, HTTPException

from app.services.kpi_data_service import (
    get_gauge_metrics,
    get_metric_definition,
    ingest_metric,
)

router = APIRouter()


class MetricIngestRequest(BaseModel):
    metric_name: str
    value: float
    date: str
    project: str
    team: str


@router.get("/metrics/gauges")
def metric_gauges():
    try:
        return get_gauge_metrics()
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.get("/metrics/definition/{metric_name}")
def metric_definition(metric_name: str):
    definition = get_metric_definition(metric_name)
    if not definition:
        raise HTTPException(status_code=404, detail=f"Metric definition not found for '{metric_name}'.")
    return {
        "metric_name": metric_name,
        "category": definition.get("category"),
        "frequency": definition.get("frequency"),
        "thresholds": definition.get("thresholds", {}),
    }


@router.post("/metrics/ingest")
def metric_ingest(payload: MetricIngestRequest):
    try:
        as_dict = payload.model_dump() if hasattr(payload, "model_dump") else payload.dict()
        return ingest_metric(as_dict)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
