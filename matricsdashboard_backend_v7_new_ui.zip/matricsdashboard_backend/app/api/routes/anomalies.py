from fastapi import APIRouter, HTTPException

from app.services.kpi_data_service import get_anomalies

router = APIRouter()


@router.get("/anomalies/{metric}")
def anomalies(metric: str):
    try:
        return get_anomalies(metric)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
