from pydantic import BaseModel
from fastapi import APIRouter, HTTPException

from app.services.kpi_data_service import ask_copilot

router = APIRouter()


class CopilotQueryRequest(BaseModel):
    question: str


@router.post("/copilot/query")
def copilot_query(payload: CopilotQueryRequest):
    try:
        return ask_copilot(payload.question)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
