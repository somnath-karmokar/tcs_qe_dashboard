from fastapi import APIRouter, HTTPException

from app.services.kpi_data_service import get_metric_trend

router = APIRouter()


@router.get("/trends/{metric_name}")
def metric_trend(metric_name: str):
    try:
        return get_metric_trend(metric_name)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
