
from fastapi import APIRouter, Response
from app.services.analysis_service import analyze_kpi

router = APIRouter()

@router.post("/analyze", deprecated=True)
def analyze(response: Response, data: dict):
    response.headers["Warning"] = '299 - "Deprecated endpoint. Use /api/copilot/query instead."'
    try:
        payload = analyze_kpi(data.get("query", "Analyze KPI performance"))
    except Exception as exc:
        payload = {"error": str(exc)}
    payload["warning"] = "Deprecated endpoint. Use /api/copilot/query instead."
    return payload
