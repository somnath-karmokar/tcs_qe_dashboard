from fastapi import APIRouter, HTTPException

from app.services.kpi_data_service import get_forecast

router = APIRouter()


@router.get("/forecast/{metric}")
def forecast(metric: str):
    try:
        return get_forecast(metric)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
