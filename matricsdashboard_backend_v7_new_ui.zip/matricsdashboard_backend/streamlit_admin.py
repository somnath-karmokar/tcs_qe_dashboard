﻿from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from urllib import error, request

import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="\U0001F4CA Metrics Contract Admin",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .block-container {
        padding-top: 1.2rem;
        padding-bottom: 2rem;
      }
      .hero {
        background: linear-gradient(120deg, #0f172a 0%, #1e3a8a 45%, #0f766e 100%);
        border-radius: 16px;
        padding: 1.1rem 1.25rem;
        margin-bottom: 1rem;
        color: #f8fafc;
        border: 1px solid rgba(148, 163, 184, 0.25);
      }
      .hero h1 {
        margin: 0;
        font-size: 1.5rem;
        line-height: 1.4;
      }
      .hero p {
        margin: 0.35rem 0 0 0;
        color: #dbeafe;
        font-size: 0.95rem;
      }
      .card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 0.8rem 0.95rem;
      }
      .pill {
        display: inline-block;
        background: #e2e8f0;
        color: #0f172a;
        border-radius: 999px;
        padding: 0.12rem 0.62rem;
        font-size: 0.78rem;
        margin-bottom: 0.25rem;
      }
      .ops-title {
        background: linear-gradient(120deg, #ecfeff 0%, #f0f9ff 100%);
        border: 1px solid #bae6fd;
        border-radius: 12px;
        padding: 0.85rem;
        margin-bottom: 0.85rem;
      }
      div[data-baseweb="tab-list"] button {
        font-weight: 600;
      }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="hero">
      <h1>&#128202; Metrics Dashboard Admin Console</h1>
      <p>Professional control center for FastAPI contracts, with a focused workflow for <b>Monthly Ops</b>.</p>
    </div>
    """,
    unsafe_allow_html=True,
)


def _api_call(
    base_url: str,
    method: str,
    path: str,
    payload: dict | None = None,
    timeout_seconds: int = 30,
) -> tuple[bool, int, dict]:
    url = f"{base_url.rstrip('/')}{path}"
    headers = {"Content-Type": "application/json"}
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
    req = request.Request(url=url, data=data, headers=headers, method=method.upper())

    try:
        with request.urlopen(req, timeout=timeout_seconds) as response:
            body = response.read().decode("utf-8")
            return True, response.status, json.loads(body) if body else {}
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8")
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError:
            parsed = {"detail": body}
        return False, exc.code, parsed
    except Exception as exc:  # noqa: BLE001
        return False, 0, {"detail": str(exc)}


def _show_result(
    ok: bool,
    status: int,
    payload: dict,
    label: str,
    success_message: str | None = None,
    error_message: str | None = None,
) -> None:
    if ok:
        st.success(success_message or f"\u2705 {label} succeeded (HTTP {status})")
    else:
        st.error(error_message or f"\u274C {label} failed (HTTP {status})")
    with st.expander("View response JSON", expanded=False):
        st.json(payload)


def _load_domain_portfolios(base_url: str) -> list[dict]:
    ok, _status, payload = _api_call(base_url, "GET", "/monthly-metrics/domain-portfolios")
    if not ok:
        return []
    domains = payload.get("domains", [])
    return domains if isinstance(domains, list) else []


def _render_api_details_page() -> None:
    st.subheader("API Details")
    st.caption("Reference view for endpoints used by this admin console.")

    sections = {
        "Monthly Ops": [
            ("GET", "/monthly-metrics/domain-portfolios", "List domains and related portfolios."),
            ("POST", "/monthly-metrics/domain-portfolios", "Create a domain/portfolio option."),
            ("POST", "/monthly-metrics/upload-rows", "Upload parsed rows for a specific month."),
            ("GET", "/monthly-metrics/months", "List all available month snapshots."),
            ("POST", "/monthly-metrics/start-analysis", "Run month-level analysis with lookback settings."),
            ("GET", "/monthly-metrics/frontend", "Fetch frontend-ready response payload."),
            ("DELETE", "/monthly-metrics/history?month={YYYY-MM}", "Delete history for one month."),
            ("DELETE", "/monthly-metrics/history/all", "Delete all monthly history."),
        ],
        "Dashboard": [
            ("GET", "/dashboard/summary", "Get dashboard summary metrics."),
            ("GET", "/dashboard/health-score", "Get aggregate health score."),
            ("GET", "/dashboard/summary/narrative", "Get narrative summary for dashboard."),
        ],
        "Metrics and Insights": [
            ("POST", "/metrics/ingest", "Ingest one metric record."),
            ("GET", "/metrics/gauges", "Get gauge-friendly metrics."),
            ("GET", "/metrics/definition/{metric_name}", "Get metric definition."),
            ("GET", "/trends/{metric_name}", "Get trend response for metric."),
            ("GET", "/anomalies/{metric}", "Get anomaly detection output."),
            ("GET", "/forecast/{metric}", "Get forecast projection."),
            ("GET", "/insights/root-cause/{metric}", "Get root-cause insights."),
            ("GET", "/insights/recommendations/{metric}", "Get recommendation insights."),
            ("POST", "/copilot/query", "Ask copilot question."),
        ],
    }

    for section_name, rows in sections.items():
        with st.container(border=True):
            st.markdown(f"#### {section_name}")
            for method, path, description in rows:
                st.markdown(f"- **{method}** `{path}`  \n  {description}")


with st.sidebar:
    st.markdown("### \U0001F50C Connection")
    api_base_url = st.text_input("API Base URL", value="http://localhost:8000/api")
    st.caption("Tip: Keep backend running before triggering actions.")

    ping_ok, ping_status, _ping_payload = _api_call(api_base_url, "GET", "/health")
    if ping_ok:
        st.success(f"API reachable (HTTP {ping_status})")
    else:
        st.warning("API not reachable right now")

    st.markdown("---")
    st.markdown("### \U0001F9ED Quick Guide")
    st.markdown(
        "1. Use **Monthly Ops** for upload -> analysis -> frontend payload.\n"
        "2. Keep month format as `YYYY-MM`.\n"
        "3. Use delete actions carefully."
    )

if "analysis_run_history" not in st.session_state:
    st.session_state.analysis_run_history = []
if "pending_analysis_payload" not in st.session_state:
    st.session_state.pending_analysis_payload = None
if "pending_analysis_summary" not in st.session_state:
    st.session_state.pending_analysis_summary = ""

tab_dashboard, tab_metrics, tab_trends, tab_anomalies, tab_forecast, tab_insights, tab_copilot, tab_monthly, tab_api_details = st.tabs(
    [
        "Dashboard",
        "Metrics",
        "Trends",
        "Anomalies",
        "Forecast",
        "AI Insights",
        "Copilot",
        "Monthly Ops",
        "API Details",
    ]
)

with tab_dashboard:
    st.subheader("\U0001F4C8 Dashboard APIs")
    col_a, col_b, col_c = st.columns(3)
    if col_a.button("Summary", use_container_width=True):
        ok, status, payload = _api_call(api_base_url, "GET", "/dashboard/summary")
        _show_result(ok, status, payload, "GET /dashboard/summary")
    if col_b.button("Health Score", use_container_width=True):
        ok, status, payload = _api_call(api_base_url, "GET", "/dashboard/health-score")
        _show_result(ok, status, payload, "GET /dashboard/health-score")
    if col_c.button("Narrative", use_container_width=True):
        ok, status, payload = _api_call(api_base_url, "GET", "/dashboard/summary/narrative")
        _show_result(ok, status, payload, "GET /dashboard/summary/narrative")

with tab_metrics:
    st.subheader("\U0001F9EE Metrics APIs")
    with st.form("ingest_form"):
        st.markdown("#### \u2795 POST /metrics/ingest")
        c1, c2 = st.columns(2)
        with c1:
            metric_name = st.text_input("metric_name", value="FTP")
            value = st.number_input("value", value=85.0, step=0.1)
            date = st.text_input("date (YYYY-MM)", value="2026-02")
        with c2:
            project = st.text_input("project", value="Project A")
            team = st.text_input("team", value="Team X")
            st.caption("Use valid month format for consistent history tracking.")
        ingest_submit = st.form_submit_button("Ingest Metric", type="primary")
    if ingest_submit:
        ok, status, payload = _api_call(
            api_base_url,
            "POST",
            "/metrics/ingest",
            {
                "metric_name": metric_name,
                "value": value,
                "date": date,
                "project": project,
                "team": team,
            },
        )
        _show_result(ok, status, payload, "POST /metrics/ingest")

    col1, col2 = st.columns(2)
    if col1.button("Get Gauges", use_container_width=True):
        ok, status, payload = _api_call(api_base_url, "GET", "/metrics/gauges")
        _show_result(ok, status, payload, "GET /metrics/gauges")

    with col2:
        definition_metric = st.text_input("metric_name for /metrics/definition/{metric_name}", value="FTP")
        if st.button("Get Metric Definition", use_container_width=True):
            ok, status, payload = _api_call(api_base_url, "GET", f"/metrics/definition/{definition_metric}")
            _show_result(ok, status, payload, "GET /metrics/definition/{metric_name}")

with tab_trends:
    st.subheader("\U0001F4C9 GET /trends/{metric_name}")
    trend_metric = st.text_input("trend metric_name", value="FTP")
    if st.button("Get Trend", type="primary"):
        ok, status, payload = _api_call(api_base_url, "GET", f"/trends/{trend_metric}")
        _show_result(ok, status, payload, "GET /trends/{metric_name}")

with tab_anomalies:
    st.subheader("\U0001F6A8 GET /anomalies/{metric}")
    anomaly_metric = st.text_input("anomaly metric", value="FTP")
    if st.button("Get Anomalies", type="primary"):
        ok, status, payload = _api_call(api_base_url, "GET", f"/anomalies/{anomaly_metric}")
        _show_result(ok, status, payload, "GET /anomalies/{metric}")

with tab_forecast:
    st.subheader("\U0001F52E GET /forecast/{metric}")
    forecast_metric = st.text_input("forecast metric", value="FTP")
    if st.button("Get Forecast", type="primary"):
        ok, status, payload = _api_call(api_base_url, "GET", f"/forecast/{forecast_metric}")
        _show_result(ok, status, payload, "GET /forecast/{metric}")

with tab_insights:
    st.subheader("\U0001F9E0 AI Insights APIs")
    insight_metric = st.text_input("insight metric", value="FTP")
    left, right = st.columns(2)
    if left.button("Get Root Cause", use_container_width=True):
        ok, status, payload = _api_call(api_base_url, "GET", f"/insights/root-cause/{insight_metric}")
        _show_result(ok, status, payload, "GET /insights/root-cause/{metric}")
    if right.button("Get Recommendations", use_container_width=True):
        ok, status, payload = _api_call(api_base_url, "GET", f"/insights/recommendations/{insight_metric}")
        _show_result(ok, status, payload, "GET /insights/recommendations/{metric}")

with tab_copilot:
    st.subheader("\U0001F916 POST /copilot/query")
    st.caption("Copilot answers are generated from the latest Monthly Ops analysis context (6-month lookback).")
    if "copilot_chat_history" not in st.session_state:
        st.session_state.copilot_chat_history = [
            {
                "role": "assistant",
                "content": (
                    "Hi, I am your QE Copilot. Ask me anything about the latest monthly trends, "
                    "risks, and recommendations."
                ),
            }
        ]

    top_col1, top_col2 = st.columns([4, 1])
    with top_col2:
        if st.button("Clear Chat", use_container_width=True):
            st.session_state.copilot_chat_history = [
                {
                    "role": "assistant",
                    "content": (
                        "Chat cleared. Ask a new question and I will answer using the latest 6-month analysis context."
                    ),
                }
            ]

    for message in st.session_state.copilot_chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("supporting_metrics"):
                st.caption(f"Supporting metrics: {', '.join(message['supporting_metrics'])}")

    user_prompt = st.chat_input("Ask about KPI trends, risks, root causes, or recommendations...")
    if user_prompt:
        user_text = user_prompt.strip()
        if not user_text:
            st.warning("Please enter a question.")
        else:
            st.session_state.copilot_chat_history.append({"role": "user", "content": user_text})
            with st.chat_message("user"):
                st.markdown(user_text)

            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    ok, status, payload = _api_call(
                        api_base_url,
                        "POST",
                        "/copilot/query",
                        {"question": user_text},
                        timeout_seconds=120,
                    )

                if ok:
                    answer = str(payload.get("answer", "")).strip()
                    supporting_metrics = payload.get("supporting_metrics", [])
                    if not isinstance(supporting_metrics, list):
                        supporting_metrics = []
                    supporting_metrics = [str(item).strip() for item in supporting_metrics if str(item).strip()]

                    if not answer:
                        answer = (
                            "I could not generate a detailed answer for this question yet. "
                            "Please try rephrasing with a specific metric or month."
                        )

                    st.markdown(answer)
                    if supporting_metrics:
                        st.caption(f"Supporting metrics: {', '.join(supporting_metrics)}")

                    st.session_state.copilot_chat_history.append(
                        {
                            "role": "assistant",
                            "content": answer,
                            "supporting_metrics": supporting_metrics,
                        }
                    )
                else:
                    error_message = str(payload.get("detail", "Unable to get response from Copilot.")).strip()
                    friendly_error = (
                        "I am sorry, I could not answer right now. "
                        f"Please try again. (HTTP {status}: {error_message})"
                    )
                    st.error(friendly_error)
                    st.session_state.copilot_chat_history.append(
                        {"role": "assistant", "content": friendly_error}
                    )

with tab_monthly:
    st.markdown(
        """
        <div class="ops-title">
          <div class="pill">Main Workflow</div>
          <h3 style="margin:0;">&#128467;&#65039; Monthly Ops</h3>
          <p style="margin:.35rem 0 0 0; color:#0f172a;">
            Upload monthly sheet, run analysis, and fetch frontend payload from one guided workspace.
          </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    default_month = datetime.now(timezone.utc).strftime("%Y-%m")

    with st.container(border=True):
        st.markdown("#### Domain and Portfolio Setup")
        domain_options = _load_domain_portfolios(api_base_url)
        if domain_options:
            domain_rows = [
                {
                    "Domain": item.get("name", ""),
                    "Portfolios": ", ".join(item.get("portfolios", [])),
                }
                for item in domain_options
            ]
            st.dataframe(pd.DataFrame(domain_rows), use_container_width=True, hide_index=True)
        else:
            st.info("No domain/portfolio options created yet. Use the form below to add one.")

        with st.form("domain_portfolio_form"):
            d_col, p_col, action_col = st.columns([2, 2, 1])
            with d_col:
                setup_domain = st.text_input("domain", value="", key="setup_domain")
            with p_col:
                setup_portfolio = st.text_input("portfolio", value="", key="setup_portfolio")
            with action_col:
                st.write("")
                st.write("")
                create_domain_submit = st.form_submit_button("Create", type="primary", use_container_width=True)

        if create_domain_submit:
            if not setup_domain.strip():
                st.error("Please provide a domain.")
            elif not setup_portfolio.strip():
                st.error("Please provide a portfolio.")
            else:
                ok, status, payload = _api_call(
                    api_base_url,
                    "POST",
                    "/monthly-metrics/domain-portfolios",
                    {"domain": setup_domain.strip(), "portfolio": setup_portfolio.strip()},
                )
                _show_result(
                    ok,
                    status,
                    payload,
                    "POST /monthly-metrics/domain-portfolios",
                    success_message=f"\u2705 Created {setup_domain.strip()} / {setup_portfolio.strip()}.",
                )

    st.write("")
    with st.container(border=True):
        st.markdown("#### 1) \U0001F4E4 Upload Monthly Sheet")
        left, right = st.columns([2, 3])
        with left:
            upload_month = st.text_input("month (YYYY-MM)", value=default_month, key="monthly_upload_month")
            upload_title = st.text_input(
                "dashboard_title",
                value="Quality Engineering Dashboard",
                key="monthly_upload_title",
            )
            latest_domain_options = _load_domain_portfolios(api_base_url)
            domain_names = [item.get("name", "") for item in latest_domain_options if item.get("name")]
            if "Unassigned" not in domain_names:
                domain_names = ["Unassigned", *domain_names]
            upload_domain = st.selectbox("domain", options=domain_names, key="monthly_upload_domain")
            portfolio_names = []
            for item in latest_domain_options:
                if item.get("name") == upload_domain:
                    portfolio_names = [name for name in item.get("portfolios", []) if name]
                    break
            if "General" not in portfolio_names:
                portfolio_names = ["General", *portfolio_names]
            upload_portfolio = st.selectbox("portfolio", options=portfolio_names, key="monthly_upload_portfolio")
        with right:
            uploaded_file = st.file_uploader(
                "Upload monthly metric sheet (.xlsx or .csv)",
                type=["xlsx", "csv"],
                key="monthly_file_upload",
            )
            st.caption(
                "Selected domain/portfolio is applied to all rows unless the sheet has domain and portfolio columns."
            )

        if st.button("Upload Monthly Dataset", type="primary", use_container_width=True):
            if uploaded_file is None:
                st.error("Please select a .xlsx or .csv file first.")
            else:
                try:
                    if uploaded_file.name.lower().endswith(".csv"):
                        df = pd.read_csv(uploaded_file)
                    else:
                        df = pd.read_excel(uploaded_file)
                    rows = json.loads(df.to_json(orient="records", date_format="iso"))
                    ok, status, payload = _api_call(
                        api_base_url,
                        "POST",
                        "/monthly-metrics/upload-rows",
                        {
                            "month": upload_month,
                            "dashboard_title": upload_title,
                            "domain": upload_domain,
                            "portfolio": upload_portfolio,
                            "rows": rows,
                        },
                    )
                    _show_result(
                        ok,
                        status,
                        payload,
                        "POST /monthly-metrics/upload-rows",
                        success_message=(
                            f"\u2705 Monthly dataset uploaded for "
                            f"{upload_month.strip() or default_month}."
                        ),
                    )
                except Exception as exc:  # noqa: BLE001
                    st.error(f"Failed to process upload: {exc}")

    st.write("")
    c_months, c_analysis, c_frontend = st.columns(3)

    with c_months:
        with st.container(border=True):
            st.markdown("#### 2) \U0001F4DA Months")
            st.caption("Check available monthly snapshots.")
            if st.button("View Available Months", use_container_width=True):
                ok, status, payload = _api_call(api_base_url, "GET", "/monthly-metrics/months")
                _show_result(
                    ok,
                    status,
                    payload,
                    "GET /monthly-metrics/months",
                    success_message="\u2705 Loaded available monthly snapshots.",
                )

    with c_analysis:
        with st.container(border=True):
            st.markdown("#### 3) \U0001F9EA Start Analysis")
            analysis_month = st.text_input("analysis month (blank=latest)", value="", key="analysis_month_input")
            lookback_months = st.number_input(
                "lookback_months",
                min_value=1,
                max_value=24,
                value=6,
                step=1,
                key="lookback_months_input",
            )
            use_llm = st.checkbox("Use LLM enhancement", value=False, key="use_llm_checkbox")
            with st.expander("Advanced analysis options", expanded=False):
                max_llm_metrics = st.number_input(
                    "Maximum metrics for LLM analysis",
                    min_value=0,
                    max_value=100,
                    value=3,
                    step=1,
                    key="max_llm_metrics_input",
                )
                llm_time_budget_seconds = st.number_input(
                    "LLM time budget (seconds)",
                    min_value=0,
                    max_value=300,
                    value=20,
                    step=1,
                    key="llm_time_budget_input",
                )

            target_month = analysis_month.strip() or "latest month"
            last_run = st.session_state.analysis_run_history[-1] if st.session_state.analysis_run_history else None
            rerun_requires_confirmation = False
            if last_run:
                try:
                    last_run_at = datetime.fromisoformat(str(last_run["run_at_utc"]))
                    rerun_requires_confirmation = datetime.now(timezone.utc) - last_run_at < timedelta(minutes=30)
                except Exception:  # noqa: BLE001
                    rerun_requires_confirmation = False

            payload_body = {
                "month": analysis_month.strip() or None,
                "lookback_months": int(lookback_months),
                "use_llm": bool(use_llm),
                "max_llm_metrics": int(max_llm_metrics),
                "llm_time_budget_seconds": int(llm_time_budget_seconds),
            }
            summary_text = (
                f"Month: {target_month}, lookback: {int(lookback_months)}, "
                f"LLM: {'on' if use_llm else 'off'}"
            )

            if st.button("Run Monthly Analysis", use_container_width=True):
                if rerun_requires_confirmation:
                    st.session_state.pending_analysis_payload = payload_body
                    st.session_state.pending_analysis_summary = summary_text
                    st.warning(
                        "A recent analysis was run within the last 30 minutes. "
                        "Please confirm before running again."
                    )
                else:
                    ok, status, payload = _api_call(
                        api_base_url,
                        "POST",
                        "/monthly-metrics/start-analysis",
                        payload_body,
                        timeout_seconds=120,
                    )
                    if ok:
                        st.session_state.analysis_run_history.append(
                            {
                                "run_at_utc": datetime.now(timezone.utc).isoformat(),
                                "month": payload_body["month"] or "latest",
                                "lookback_months": payload_body["lookback_months"],
                                "use_llm": payload_body["use_llm"],
                                "status": status,
                            }
                        )
                    _show_result(
                        ok,
                        status,
                        payload,
                        "POST /monthly-metrics/start-analysis",
                        success_message=(
                            f"\u2705 Analysis completed for {target_month} "
                            f"(lookback {int(lookback_months)} months)."
                        ),
                    )

            if st.session_state.pending_analysis_payload is not None:
                st.info(f"Pending re-run request: {st.session_state.pending_analysis_summary}")
                confirm_col, cancel_col = st.columns(2)
                if confirm_col.button("Confirm and Run Analysis", use_container_width=True):
                    pending_payload = st.session_state.pending_analysis_payload
                    ok, status, payload = _api_call(
                        api_base_url,
                        "POST",
                        "/monthly-metrics/start-analysis",
                        pending_payload,
                        timeout_seconds=120,
                    )
                    if ok:
                        st.session_state.analysis_run_history.append(
                            {
                                "run_at_utc": datetime.now(timezone.utc).isoformat(),
                                "month": pending_payload["month"] or "latest",
                                "lookback_months": pending_payload["lookback_months"],
                                "use_llm": pending_payload["use_llm"],
                                "status": status,
                            }
                        )
                    st.session_state.pending_analysis_payload = None
                    st.session_state.pending_analysis_summary = ""
                    _show_result(
                        ok,
                        status,
                        payload,
                        "POST /monthly-metrics/start-analysis",
                        success_message="\u2705 Analysis re-run completed successfully.",
                    )
                if cancel_col.button("Cancel Re-run", use_container_width=True):
                    st.session_state.pending_analysis_payload = None
                    st.session_state.pending_analysis_summary = ""
                    st.info("Re-run canceled.")

            if st.session_state.analysis_run_history:
                history_df = pd.DataFrame(st.session_state.analysis_run_history).copy()
                history_df["run_at_utc"] = pd.to_datetime(history_df["run_at_utc"]).dt.strftime("%Y-%m-%d %H:%M:%S")
                st.markdown("##### Recent Analysis Runs")
                st.dataframe(
                    history_df.rename(
                        columns={
                            "run_at_utc": "Run Time (UTC)",
                            "month": "Month",
                            "lookback_months": "Lookback",
                            "use_llm": "LLM",
                            "status": "HTTP",
                        }
                    ),
                    use_container_width=True,
                    hide_index=True,
                )

    with c_frontend:
        with st.container(border=True):
            st.markdown("#### 4) \U0001F9E9 Frontend Payload")
            frontend_month = st.text_input("frontend month (blank=latest)", value="", key="frontend_month_input")
            frontend_history = st.number_input(
                "frontend history_months",
                min_value=1,
                max_value=24,
                value=6,
                step=1,
                key="frontend_history_input",
            )
            if st.button("Generate Frontend Payload", use_container_width=True):
                path = f"/monthly-metrics/frontend?history_months={int(frontend_history)}"
                if frontend_month.strip():
                    path = f"{path}&month={frontend_month.strip()}"
                ok, status, payload = _api_call(api_base_url, "GET", path)
                _show_result(
                    ok,
                    status,
                    payload,
                    "GET /monthly-metrics/frontend",
                    success_message="\u2705 Frontend payload generated successfully.",
                )

    st.write("")
    with st.container(border=True):
        st.markdown("#### \U0001F5D1\ufe0f Delete Historical Data")
        st.caption("Danger zone: use only when cleanup is intentional.")
        del_col1, del_col2 = st.columns(2)

        with del_col1:
            delete_month = st.text_input("delete month (YYYY-MM)", value="", key="delete_month_input")
            if st.button("Delete Selected Month Data", use_container_width=True):
                month_value = delete_month.strip()
                if not month_value:
                    st.error("Please provide month in YYYY-MM format.")
                else:
                    ok, status, payload = _api_call(
                        api_base_url,
                        "DELETE",
                        f"/monthly-metrics/history?month={month_value}",
                    )
                    _show_result(
                        ok,
                        status,
                        payload,
                        "DELETE /monthly-metrics/history",
                        success_message=f"\u2705 Deleted monthly history for {month_value}.",
                    )

        with del_col2:
            confirm_delete_all = st.checkbox(
                "I understand this will delete all monthly history",
                value=False,
                key="confirm_delete_all_checkbox",
            )
            if st.button("Delete All Monthly History", use_container_width=True):
                if not confirm_delete_all:
                    st.error("Please confirm delete-all checkbox first.")
                else:
                    ok, status, payload = _api_call(
                        api_base_url,
                        "DELETE",
                        "/monthly-metrics/history/all",
                    )
                    _show_result(
                        ok,
                        status,
                        payload,
                        "DELETE /monthly-metrics/history/all",
                        success_message="\u2705 All monthly history deleted.",
                    )

    st.caption("Endpoint reference is available in the API Details tab.")

with tab_api_details:
    _render_api_details_page()
