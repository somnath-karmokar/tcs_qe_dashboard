import json
import re
from datetime import datetime
import shutil
import os

markdown_table = """
| Category      | Metrics / KPIs                                        |   2025-10-01 00:00:00 |   2025-11-01 00:00:00 |   2025-12-01 00:00:00 |   2026-01-01 00:00:00 |   2026-02-01 00:00:00 |   2026-03-01 00:00:00 | Remarks                                         |
|:--------------|:------------------------------------------------------|----------------------:|----------------------:|----------------------:|----------------------:|----------------------:|----------------------:|:------------------------------------------------|
| Engineering   | Unique GenAI Use cases                                |                     1 |                     2 |                     3 |                     2 |                     2 |                     1 | 0 = Red, 1=Amber , >=2 Green                    |
|               | GenAI Adoption (%)                                    |                     5 |                    12 |                    20 |                    25 |                    32 |                    35 | <10% -- Red, 10% - 25% - Amber, > 25% - Green   |
|               | Automation Adoption (%)                               |                    25 |                    32 |                    40 |                    45 |                    50 |                    54 | < 25% - Red , 25% - 70% - Amber , > 70% - Green |
|               | CICD Adoption (%)                                     |                    10 |                    15 |                    25 |                    30 |                    35 |                    40 | < 25% - Red , 25% - 70% - Amber , > 70% - Green |
|               | Regression Automation(%)                              |                    30 |                    35 |                    45 |                    50 |                    60 |                    65 | < 25% - Red , 25% - 70% - Amber , > 70% - Green |
|               | E2E Automation (%)                                    |                    20 |                    25 |                    35 |                    40 |                    45 |                    55 | < 25% - Red , 25% - 70% - Amber , > 70% - Green |
| Velocity      | First Time Right for Build %                          |                    72 |                    84 |                    92 |                    96 |                    97 |                    98 | < 85% - Red ,85 % - 95% - Amber , > 95% - Green |
|               | Defect Density                                        |                    15 |                     8 |                    13 |                    10 |                     8 |                     4 | < 5% - Green , 5% - 10% - Amber, >10% - Red     |
|               | Defect Re-Open %                                      |                     5 |                     2 |                     3 |                     1 |                     2 |                     2 | < 5% - Green , 5% - 10% - Amber, >10% - Red     |
|               | Environment availability %                            |                    96 |                    98 |                    97 |                    99 |                    99 |                    98 | < 95% - Red , 95% - 98% - Amber , > 98% - Green |
|               | Average Defect TAT for 1-Urgent and 2-High (in hours) |                    28 |                    22 |                    30 |                    26 |                    32 |                    18 | < 20 - Green , 20-30 - Amber, > 30- Green       |
|               | Ontime delivery %                                     |                    97 |                    99 |                    92 |                    90 |                    98 |                    99 | < 95% - Red , 95% - 98% - Amber , > 98% - Green |
| Quality       | Invalid Defects                                       |                    55 |                    58 |                    43 |                    19 |                    34 |                    18 | < 20 - Green , 20-30 - Amber, > 30- Green       |
|               | Escape Defect to Prod                                 |                     4 |                     7 |                     2 |                     4 |                     5 |                     7 | < 4 - Green, 4-6 - Amber, > 6- Red              |
|               | Escape Defect to UAT                                  |                     3 |                     2 |                     2 |                     1 |                     4 |                     3 | < 4 - Green, 4-6 - Amber, > 6- Red              |
|               | Test case Traceability %                              |                    97 |                    98 |                    98 |                    99 |                    98 |                    99 | < 95% - Red , 95% - 98% - Amber , > 98% - Green |
|               | Automated Data Provisioning %                         |                    55 |                    58 |                    60 |                    65 |                    70 |                    75 | < 25% - Red , 25% - 70% - Amber , > 70% - Green |
|               | Defect due to (Code, Config) from Defect RCA %        |                    78 |                    65 |                    70 |                    55 |                    50 |                    52 | < 60% - Green , 60% - 70% - Amber, > 70% - Red  |
| Collaboration | Improvement Ideas submitted                           |                     4 |                     3 |                     4 |                     2 |                     4 |                     3 | <2 - Red, 2-3 - Anber , >3 - Green              |
|               | Learning Hours                                        |                    75 |                    82 |                    78 |                    92 |                    94 |                    98 | <75 - Red , 75 - 85 - Amber , > 85 - Green      |
|               | Reusable Knowledge Assets                             |                     2 |                     3 |                     2 |                     5 |                     7 |                     9 | <2 - Red, 2-3 - Anber , >3 - Green              |
|               | Knowledge Sharing session                             |                     4 |                     3 |                     5 |                     4 |                     4 |                     5 | <2 - Red, 2-3 - Anber , >3 - Green              |
|               | Optimization Initiatives undertaken                   |                     3 |                     3 |                     2 |                     5 |                     4 |                     6 | <2 - Red, 2-3 - Anber , >3 - Green              |
|               | Audit compliance %                                    |                    70 |                    75 |                    72 |                    67 |                    79 |                    85 | < 70% - Red, 70% - 90% - Amber, > 90% - Green   |
"""

lines = [line for line in markdown_table.strip().split("\n") if line.startswith("|")]
header = [col.strip() for col in lines[0].split("|")[1:-1]]
months = header[2:-1]

data_by_month = {m: [] for m in months}
kpi_definitions = {}

current_category = ""
for line in lines[2:]:
    cols = [col.strip() for col in line.split("|")[1:-1]]
    
    if cols[0]:
        current_category = cols[0]
        
    metric_name = cols[1]
    
    # Process remarks
    remarks = cols[-1].lower()
    goal = "higher"
    good = 0
    average = 0
    risk = 0
    
    # Manual remark parsing based on standard patterns
    if ">=2 green" in remarks or ">3 - green" in remarks:
        goal = "higher"
        if "0 = red" in remarks:
            risk = 0
            average = 1
            good = 2
        else:
            risk = 2
            average = 3
            good = 4
    elif "green" in remarks and "red" in remarks:
        # e.g., < 25% - red, > 70% - green (goal = higher)
        # e.g., < 5% - green, > 10% - red (goal = lower)
        nums = sorted(list(map(int, re.findall(r'\d+', remarks))))
        if "< 5" in remarks and "green" in remarks and ">10" in remarks and "red" in remarks:
            goal = "lower"
            good = 5
            average = 10
            risk = 15
        elif "< 4" in remarks and "green" in remarks:
            goal = "lower"
            good = 4
            average = 6
            risk = 8
        elif "< 20" in remarks and "green" in remarks:
            goal = "lower"
            good = 20
            average = 30
            risk = 40
        elif "< 60" in remarks and "green" in remarks:
            goal = "lower"
            good = 60
            average = 70
            risk = 80
        elif "> 70" in remarks and "green" in remarks and "red" in remarks:
            goal = "higher"
            good = 70
            average = 25
            risk = 0
        elif "> 95" in remarks and "green" in remarks:
            goal = "higher"
            good = 95
            average = 85
            risk = 70
        elif "> 98" in remarks and "green" in remarks:
            goal = "higher"
            good = 98
            average = 95
            risk = 90
        elif "> 85 - green" in remarks:
            goal = "higher"
            good = 85
            average = 75
            risk = 60
        elif "> 25% - green" in remarks:
            goal = "higher"
            good = 25
            average = 10
            risk = 0
            
    unit = "%" if "%" in metric_name or "(%)" in metric_name else ""
    metric_clean_name = metric_name.replace("(%)", "").replace("%", "").strip()
    
    kpi_definitions[metric_clean_name.lower()] = {
        "category": current_category,
        "frequency": "Sprint",
        "goal": goal,
        "thresholds": {
            "good": good,
            "average": average,
            "risk": risk
        }
    }
    
    for i, month in enumerate(months):
        val_str = cols[2+i]
        try:
            val = float(val_str)
        except ValueError:
            val = 0.0
            
        data_by_month[month].append({
            "category": current_category,
            "name": metric_clean_name,
            "value": val,
            "unit": unit
        })

# Construct monthly_category_metrics.json
monthly_output = {
    "dashboard_title": "Quality Engineering Dashboard",
    "months": []
}

for month_dt_str in months:
    dt = datetime.strptime(month_dt_str, "%Y-%m-%d %H:%M:%S")
    month_id = dt.strftime("%Y-%m")
    month_label = dt.strftime("%b %Y")
    
    categories = {}
    for metric in data_by_month[month_dt_str]:
        cat = metric["category"]
        if cat not in categories:
            categories[cat] = []
        categories[cat].append({
            "name": metric["name"],
            "value": metric["value"],
            "unit": metric["unit"],
            "domain": "Unassigned",
            "portfolio": "General"
        })
        
    monthly_output["months"].append({
        "dashboard": {
            "title": "Quality Engineering Dashboard",
            "month": month_label
        },
        "month_id": month_id,
        "categories": [{"name": k, "metrics": v} for k, v in categories.items()],
        "updated_at": datetime.utcnow().isoformat() + "Z"
    })

# Save files
data_dir = "app/data"
with open(f"{data_dir}/monthly_category_metrics.json", "w", encoding="utf-8") as f:
    json.dump(monthly_output, f, indent=2)
    
with open(f"{data_dir}/kpi_definitions.json", "w", encoding="utf-8") as f:
    json.dump(kpi_definitions, f, indent=2)

# Wipe analysis
with open(f"{data_dir}/monthly_category_analysis.json", "w", encoding="utf-8") as f:
    json.dump({"analyses": []}, f, indent=2)

# Clear vector db
chroma_dir = "chroma_db"
if os.path.exists(chroma_dir):
    shutil.rmtree(chroma_dir)

print("Migration complete!")
