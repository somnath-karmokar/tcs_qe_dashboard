from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app
import app.services.kpi_data_service as kpi_data_service
import app.services.monthly_metrics_service as monthly_metrics_service


def _seed_definitions(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "FTP": {
                    "category": "Velocity",
                    "frequency": "Sprint",
                    "thresholds": {"good": 85, "average": 70, "risk": 60},
                },
                "Automation Script %": {
                    "category": "Engineering",
                    "frequency": "Sprint",
                    "thresholds": {"good": 85, "average": 70, "risk": 60},
                },
            }
        ),
        encoding="utf-8",
    )


def _prepare_storage(tmp_path: Path) -> None:
    kpi_data_service.DATA_DIR = tmp_path
    kpi_data_service.TIMESERIES_PATH = tmp_path / "kpi_timeseries.jsonl"
    kpi_data_service.DEFINITIONS_PATH = tmp_path / "kpi_definitions.json"
    monthly_metrics_service.DATA_DIR = tmp_path
    monthly_metrics_service.MONTHLY_METRICS_PATH = tmp_path / "monthly_category_metrics.json"
    monthly_metrics_service.MONTHLY_ANALYSIS_PATH = tmp_path / "monthly_category_analysis.json"
    _seed_definitions(kpi_data_service.DEFINITIONS_PATH)


def test_contract_endpoints_happy_path(tmp_path):
    _prepare_storage(tmp_path)
    client = TestClient(app)

    records = [
        {"metric_name": "FTP", "value": 78, "date": "2026-01", "project": "A", "team": "X"},
        {"metric_name": "FTP", "value": 84, "date": "2026-02", "project": "A", "team": "X"},
        {
            "metric_name": "Automation Script %",
            "value": 60,
            "date": "2026-01",
            "project": "A",
            "team": "X",
        },
        {
            "metric_name": "Automation Script %",
            "value": 72,
            "date": "2026-02",
            "project": "A",
            "team": "X",
        },
    ]

    for payload in records:
        response = client.post("/api/metrics/ingest", json=payload)
        assert response.status_code == 200
        assert response.json()["status"] == "success"

    summary = client.get("/api/dashboard/summary")
    assert summary.status_code == 200
    summary_json = summary.json()
    assert summary_json["month"] == "Feb 2026"
    assert "overall_score" in summary_json

    health = client.get("/api/dashboard/health-score")
    assert health.status_code == 200
    assert "score" in health.json()

    gauges = client.get("/api/metrics/gauges")
    assert gauges.status_code == 200
    assert "metrics" in gauges.json()

    definition = client.get("/api/metrics/definition/FTP")
    assert definition.status_code == 200
    assert definition.json()["metric_name"] == "FTP"

    trend = client.get("/api/trends/FTP")
    assert trend.status_code == 200
    assert trend.json()["metric"] == "FTP"

    anomalies = client.get("/api/anomalies/FTP")
    assert anomalies.status_code == 200
    assert "alerts" in anomalies.json()

    forecast = client.get("/api/forecast/FTP")
    assert forecast.status_code == 200
    assert "prediction" in forecast.json()


def test_missing_data_and_definition(tmp_path):
    _prepare_storage(tmp_path)
    client = TestClient(app)

    no_data = client.get("/api/dashboard/summary")
    assert no_data.status_code == 404
    assert "detail" in no_data.json()

    missing_definition = client.get("/api/metrics/definition/UNKNOWN")
    assert missing_definition.status_code == 404


def test_legacy_routes_are_deprecated():
    client = TestClient(app)
    payload = {"query": "sample"}

    analyze = client.post("/api/analyze", json=payload)
    assert analyze.status_code == 200
    assert "warning" in analyze.json()

    report = client.post("/api/report", json=payload)
    assert report.status_code == 200
    assert "warning" in report.json()


def test_monthly_upload_analysis_and_frontend_api(tmp_path):
    _prepare_storage(tmp_path)
    client = TestClient(app)

    months = ["2025-09", "2025-10", "2025-11", "2025-12", "2026-01", "2026-02", "2026-03"]
    for idx, month in enumerate(months):
        response = client.post(
            "/api/monthly-metrics/upload-rows",
            json={
                "month": month,
                "dashboard_title": "Quality Engineering Dashboard",
                "rows": [
                    {"category": "Engineering", "metric_name": "Automation Script %", "value": 70 + idx, "unit": "%"},
                    {"category": "Velocity", "metric_name": "First Time Pass (FTP)", "value": 80 + idx, "unit": "%"},
                ],
            },
        )
        assert response.status_code == 200
        assert response.json()["status"] == "success"

    months_response = client.get("/api/monthly-metrics/months")
    assert months_response.status_code == 200
    assert len(months_response.json()["months"]) == 7

    analysis = client.post(
        "/api/monthly-metrics/start-analysis",
        json={"lookback_months": 6, "use_llm": False},
    )
    assert analysis.status_code == 200
    analysis_json = analysis.json()
    assert analysis_json["month_id"] == "2026-03"
    assert len(analysis_json["metrics"]) == 2

    frontend = client.get("/api/monthly-metrics/frontend?history_months=6")
    assert frontend.status_code == 200
    frontend_json = frontend.json()
    assert frontend_json["month_id"] == "2026-03"
    assert len(frontend_json["categories"]) == 2
    first_metric_history = frontend_json["categories"][0]["metrics"][0]["history"]
    assert len(first_metric_history) == 7


def test_monthly_delete_history_options(tmp_path):
    _prepare_storage(tmp_path)
    client = TestClient(app)

    for month in ["2026-01", "2026-02", "2026-03"]:
        response = client.post(
            "/api/monthly-metrics/upload-rows",
            json={
                "month": month,
                "dashboard_title": "Quality Engineering Dashboard",
                "rows": [
                    {"category": "Engineering", "metric_name": "Automation Script %", "value": 70, "unit": "%"},
                ],
            },
        )
        assert response.status_code == 200

    analysis = client.post(
        "/api/monthly-metrics/start-analysis",
        json={"month": "2026-03", "lookback_months": 2, "use_llm": False},
    )
    assert analysis.status_code == 200

    delete_one = client.delete("/api/monthly-metrics/history?month=2026-02")
    assert delete_one.status_code == 200
    assert delete_one.json()["deleted_month_records"] == 1

    months_after_one_delete = client.get("/api/monthly-metrics/months")
    assert months_after_one_delete.status_code == 200
    returned_month_ids = [item["month_id"] for item in months_after_one_delete.json()["months"]]
    assert returned_month_ids == ["2026-01", "2026-03"]

    delete_all = client.delete("/api/monthly-metrics/history/all")
    assert delete_all.status_code == 200
    assert delete_all.json()["deleted_month_records"] == 2

    months_after_all_delete = client.get("/api/monthly-metrics/months")
    assert months_after_all_delete.status_code == 200
    assert months_after_all_delete.json()["months"] == []
