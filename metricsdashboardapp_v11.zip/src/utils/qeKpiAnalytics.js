import { QE_KPI_CONFIG } from "../data/qeKpiSlaConfig";

const normalize = (value) =>
  String(value || "")
    .replace(/\u200b/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

const toNumber = (value) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

function flattenMetrics(payload) {
  return (payload?.categories || []).flatMap((category) =>
    (category.metrics || []).map((metric) => ({
      ...metric,
      category: category.name,
      normalizedName: normalize(metric.name),
    })),
  );
}

function findMetric(metrics, aliases = []) {
  const normalizedAliases = aliases.map(normalize).filter(Boolean);
  return metrics.find((metric) =>
    normalizedAliases.some((alias) => metric.normalizedName === alias || metric.normalizedName.includes(alias)),
  );
}

function metricValue(metrics, aliases = []) {
  const metric = findMetric(metrics, aliases);
  return toNumber(metric?.value);
}

function historyFromMetric(metric) {
  if (!metric?.history?.length) return [];
  return [...metric.history].reverse().map((item) => ({
    month: item.month,
    value: toNumber(item.value) ?? 0,
  }));
}

function formulaSeries(metrics, components, calculate) {
  const componentMetrics = Object.fromEntries(
    Object.entries(components || {}).map(([key, aliases]) => [key, findMetric(metrics, aliases)]),
  );
  const firstHistory = Object.values(componentMetrics).find((metric) => metric?.history?.length)?.history || [];
  if (!firstHistory.length) return [];
  return [...firstHistory].reverse().map((point, index) => {
    const values = {};
    for (const [key, metric] of Object.entries(componentMetrics)) {
      const metricHistory = [...(metric?.history || [])].reverse();
      values[key] = toNumber(metricHistory[index]?.value) ?? 0;
    }
    return { month: point.month, value: calculate(values) };
  });
}

function statusFor(kpiId, value, parts = {}) {
  if (value == null) return "Unknown";
  switch (kpiId) {
    case "dre":
      if (value >= 98) return "Green";
      if (value >= 95) return "Amber";
      return "Red";
    case "criticalLeakage":
      if ((parts.sev1 || 0) > 0) return "Red";
      if ((parts.sev2 || 0) > 2 || value > 2) return "Amber";
      return "Green";
    case "regressionCycleTime":
    case "testExecutionAdherence":
      if (value >= 100) return "Green";
      if (value >= 95) return "Amber";
      return "Red";
    case "uatRejectionRate":
      if (value < 5) return "Green";
      if (value <= 10) return "Amber";
      return "Red";
    case "defectReopenRate":
      if (value <= 5) return "Green";
      if (value <= 10) return "Amber";
      return "Red";
    case "automationStability":
      if (value >= 95) return "Green";
      if (value >= 90) return "Amber";
      return "Red";
    default:
      return "Unknown";
  }
}

function calculateKpi(config, metrics) {
  const directMetric = findMetric(metrics, config.aliases);
  let value = toNumber(directMetric?.value);
  let trend = historyFromMetric(directMetric);
  const parts = {};

  if (config.id === "dre") {
    parts.sitDefects = metricValue(metrics, config.components.sitDefects) ?? 0;
    parts.uatDefects = metricValue(metrics, config.components.uatDefects) ?? 0;
    parts.productionDefects = metricValue(metrics, config.components.productionDefects) ?? 0;
    const denominator = parts.sitDefects + parts.uatDefects + parts.productionDefects;
    if (denominator > 0) value = ((parts.sitDefects + parts.uatDefects) / denominator) * 100;
    trend = formulaSeries(metrics, config.components, (p) => {
      const total = p.sitDefects + p.uatDefects + p.productionDefects;
      return total > 0 ? ((p.sitDefects + p.uatDefects) / total) * 100 : 0;
    });
  }

  if (config.id === "criticalLeakage") {
    parts.sev1 = metricValue(metrics, config.components.sev1) ?? 0;
    parts.sev2 = metricValue(metrics, config.components.sev2) ?? 0;
    value = parts.sev1 + parts.sev2;
    trend = formulaSeries(metrics, config.components, (p) => p.sev1 + p.sev2);
  }

  if (config.id === "testExecutionAdherence") {
    parts.executed = metricValue(metrics, config.components.executed) ?? 0;
    parts.planned = metricValue(metrics, config.components.planned) ?? 0;
    parts.excluded = metricValue(metrics, config.components.excluded) ?? 0;
    const denominator = Math.max(parts.planned - parts.excluded, 0);
    if (denominator > 0) value = (parts.executed / denominator) * 100;
    trend = formulaSeries(metrics, config.components, (p) => {
      const denominator = Math.max(p.planned - p.excluded, 0);
      return denominator > 0 ? (p.executed / denominator) * 100 : 0;
    });
  }

  if (config.id === "uatRejectionRate") {
    parts.uatDefects = metricValue(metrics, config.components.uatDefects) ?? 0;
    parts.sitDefects = metricValue(metrics, config.components.sitDefects) ?? 0;
    if (parts.sitDefects > 0) value = (parts.uatDefects / parts.sitDefects) * 100;
    trend = formulaSeries(metrics, config.components, (p) => (p.sitDefects > 0 ? (p.uatDefects / p.sitDefects) * 100 : 0));
  }

  if (config.id === "defectReopenRate") {
    parts.reopened = metricValue(metrics, config.components.reopened) ?? 0;
    parts.closed = metricValue(metrics, config.components.closed) ?? 0;
    if (parts.closed > 0) value = (parts.reopened / parts.closed) * 100;
    trend = formulaSeries(metrics, config.components, (p) => (p.closed > 0 ? (p.reopened / p.closed) * 100 : 0));
  }

  if (config.id === "automationStability") {
    parts.stableRuns = metricValue(metrics, config.components.stableRuns) ?? 0;
    parts.totalRuns = metricValue(metrics, config.components.totalRuns) ?? 0;
    if (parts.totalRuns > 0) value = (parts.stableRuns / parts.totalRuns) * 100;
    trend = formulaSeries(metrics, config.components, (p) => (p.totalRuns > 0 ? (p.stableRuns / p.totalRuns) * 100 : 0));
  }

  const roundedValue = value == null ? null : Math.round(value * 100) / 100;
  const previous = trend.length >= 2 ? trend[trend.length - 2]?.value : null;
  const delta = roundedValue != null && previous != null ? roundedValue - previous : 0;
  const status = statusFor(config.id, roundedValue, parts);

  return {
    ...config,
    value: roundedValue,
    displayValue: roundedValue == null ? "NA" : `${roundedValue}${config.unit}`,
    status,
    risk: status === "Red" ? "High" : status === "Amber" ? "Medium" : status === "Green" ? "Low" : "Unknown",
    trendDirection: delta > 0 ? "up" : delta < 0 ? "down" : "flat",
    delta: Math.round(delta * 100) / 100,
    parts,
    trend,
    sourceMetric: directMetric?.name || "Calculated / mapped",
  };
}

function buildPieData(metrics, aliases, fallbackLabels) {
  const values = fallbackLabels.map((item) => ({
    label: item.label,
    value: metricValue(metrics, aliases[item.key] || []) ?? item.value,
  }));
  const total = values.reduce((sum, item) => sum + item.value, 0);
  return total > 0 ? values : fallbackLabels.map((item) => ({ label: item.label, value: item.value }));
}

function buildHeatmap(metrics, kpis) {
  const categories = [...new Set(metrics.map((metric) => metric.category || "Unassigned"))];
  return categories.map((category) => {
    const categoryMetrics = metrics.filter((metric) => metric.category === category);
    const avgValue =
      categoryMetrics.reduce((sum, metric) => sum + (toNumber(metric.value) ?? 0), 0) / Math.max(categoryMetrics.length, 1);
    const breached = kpis.filter((kpi) => kpi.status === "Red").length;
    return {
      module: category,
      riskScore: Math.min(100, Math.round((100 - Math.min(avgValue, 100)) + breached * 8)),
    };
  });
}

export function buildQeSlaDashboard(payload) {
  const metrics = flattenMetrics(payload);
  const kpis = QE_KPI_CONFIG.map((config) => calculateKpi(config, metrics));
  const weightedScore = Math.round(
    kpis.reduce((sum, kpi) => {
      const score = kpi.status === "Green" ? 100 : kpi.status === "Amber" ? 70 : kpi.status === "Red" ? 35 : 0;
      return sum + score * (kpi.weightage / 100);
    }, 0),
  );
  const breachCount = kpis.filter((kpi) => kpi.status === "Red").length;
  const warningCount = kpis.filter((kpi) => kpi.status === "Amber").length;
  const health = breachCount > 0 ? "Red" : warningCount > 0 ? "Amber" : "Green";

  return {
    month: payload?.dashboard?.month || "",
    monthId: payload?.month_id || "",
    kpis,
    weightedScore,
    health,
    breachCount,
    warningCount,
    charts: {
      severityDistribution: buildPieData(
        metrics,
        {
          sev1: ["sev1 defects", "p1 defects"],
          sev2: ["sev2 defects", "p2 defects"],
          sev3: ["sev3 defects", "p3 defects", "total defects"],
        },
        [
          { key: "sev1", label: "Sev1", value: 0 },
          { key: "sev2", label: "Sev2", value: 2 },
          { key: "sev3", label: "Sev3+", value: 8 },
        ],
      ),
      defectStatus: buildPieData(
        metrics,
        {
          open: ["total defects raised", "defects raised"],
          closed: ["total defects fixed", "closed defects"],
          rejected: ["tcs defects rejected with valid reason"],
        },
        [
          { key: "open", label: "Open", value: 4 },
          { key: "closed", label: "Closed", value: 18 },
          { key: "rejected", label: "Rejected", value: 2 },
        ],
      ),
      reopenedDefects: buildPieData(
        metrics,
        {
          reopened: ["reopened defects", "retest fail count"],
          closed: ["closed defects", "total defects fixed"],
        },
        [
          { key: "reopened", label: "Reopened", value: 1 },
          { key: "closed", label: "Closed", value: 20 },
        ],
      ),
      heatmap: buildHeatmap(metrics, kpis),
    },
    insights: buildInsights(kpis, weightedScore, health),
  };
}

function buildInsights(kpis, weightedScore, health) {
  const red = kpis.filter((kpi) => kpi.status === "Red");
  const amber = kpis.filter((kpi) => kpi.status === "Amber");
  const declining = kpis.filter((kpi) => kpi.trendDirection === "down");
  const topRisk = [...red, ...amber][0];
  return [
    `Overall QE SLA health is ${health} with a weighted governance score of ${weightedScore}.`,
    topRisk
      ? `${topRisk.name} is the leading SLA risk and should be reviewed with release owners.`
      : "All mapped SLA KPIs are currently within healthy operating range.",
    declining.length
      ? `${declining.length} KPI(s) show a downward movement; validate release scope, environment stability, and defect triage discipline.`
      : "No significant downward KPI movement detected in the mapped trend window.",
    "Recommended action: review breach owners, confirm recovery dates, and publish an executive release-quality summary after each upload.",
  ];
}

export function exportQeSlaReport(dashboard) {
  const rows = dashboard.kpis.map((kpi) => ({
    KPI: kpi.name,
    Value: kpi.displayValue,
    Target: kpi.targetLabel,
    Status: kpi.status,
    Risk: kpi.risk,
    Weightage: `${kpi.weightage}%`,
    Source: kpi.sourceMetric,
  }));
  return JSON.stringify(
    {
      title: "QE KPI SLA Dashboard",
      month: dashboard.month,
      weightedScore: dashboard.weightedScore,
      health: dashboard.health,
      kpis: rows,
      insights: dashboard.insights,
    },
    null,
    2,
  );
}
