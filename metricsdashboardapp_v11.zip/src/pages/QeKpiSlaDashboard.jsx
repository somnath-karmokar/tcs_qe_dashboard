import React, { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  BrainCircuit,
  Download,
  FileText,
  Moon,
  ShieldCheck,
  Sun,
  Target,
} from "lucide-react";
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Bar, Doughnut, Line } from "react-chartjs-2";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { useMonth } from "../context/MonthContext";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";
import { STATUS_STYLES } from "../data/qeKpiSlaConfig";
import { buildQeSlaDashboard, exportQeSlaReport } from "../utils/qeKpiAnalytics";

ChartJS.register(
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
  Legend,
  Filler,
);

const chartColors = {
  green: "#22c55e",
  amber: "#f59e0b",
  red: "#ef4444",
  cyan: "#06b6d4",
  sky: "#38bdf8",
  slate: "#64748b",
};

function statusClass(status) {
  return STATUS_STYLES[status] || STATUS_STYLES.Unknown;
}

function trendIcon(direction) {
  if (direction === "up") return <ArrowUpRight size={16} />;
  if (direction === "down") return <ArrowDownRight size={16} />;
  return <ArrowRight size={16} />;
}

function lineDataset(kpi, color) {
  const labels = kpi.trend?.length ? kpi.trend.map((item) => item.month) : ["No data"];
  const values = kpi.trend?.length ? kpi.trend.map((item) => item.value) : [0];
  return {
    labels,
    datasets: [
      {
        data: values,
        borderColor: color,
        backgroundColor: `${color}26`,
        fill: true,
        tension: 0.35,
        pointRadius: 3,
        pointHoverRadius: 5,
      },
    ],
  };
}

function pieDataset(items) {
  return {
    labels: items.map((item) => item.label),
    datasets: [
      {
        data: items.map((item) => item.value),
        backgroundColor: [chartColors.red, chartColors.amber, chartColors.green, chartColors.cyan],
        borderColor: "rgba(255,255,255,0.14)",
        borderWidth: 1,
      },
    ],
  };
}

const baseChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    tooltip: { backgroundColor: "rgba(15,23,42,0.96)", borderColor: "#334155", borderWidth: 1 },
  },
  scales: {
    x: { grid: { color: "rgba(148,163,184,0.12)" }, ticks: { color: "#cbd5e1" } },
    y: { grid: { color: "rgba(148,163,184,0.12)" }, ticks: { color: "#cbd5e1" } },
  },
};

function MetricCard({ kpi, onSelect }) {
  const tone = statusClass(kpi.status);
  return (
    <button
      type="button"
      onClick={() => onSelect(kpi)}
      className={`group relative min-h-[168px] overflow-hidden rounded-xl border ${tone.border} bg-slate-950/85 p-4 text-left shadow-xl backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_22px_60px_rgba(2,6,23,0.45)]`}
    >
      <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${tone.rail}`} />
      <div className={`absolute -right-10 -top-10 h-28 w-28 rounded-full ${tone.bg} blur-2xl transition-transform group-hover:scale-125`} />
      <div className="relative z-10 flex h-full flex-col justify-between gap-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm font-bold leading-snug text-white">{kpi.name}</p>
            <p className="mt-1 text-xs font-semibold uppercase tracking-normal text-slate-400">
              Weightage {kpi.weightage}%
            </p>
          </div>
          <span className={`rounded-full border px-2.5 py-1 text-xs font-extrabold ${tone.bg} ${tone.border} ${tone.text}`}>
            {tone.label}
          </span>
        </div>
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className={`text-4xl font-black leading-none ${tone.text}`}>{kpi.displayValue}</p>
            <p className="mt-2 text-xs text-slate-300">Target {kpi.targetLabel}</p>
          </div>
          <div className={`flex items-center gap-1 rounded-lg border px-2 py-1 text-xs font-bold ${tone.bg} ${tone.border} ${tone.text}`}>
            {trendIcon(kpi.trendDirection)}
            {Math.abs(kpi.delta || 0)}
          </div>
        </div>
      </div>
    </button>
  );
}

function Panel({ title, icon: Icon, children, className = "" }) {
  return (
    <section className={`rounded-2xl border border-slate-700/60 bg-slate-900/75 p-5 shadow-xl backdrop-blur-md ${className}`}>
      <div className="mb-4 flex items-center gap-3">
        <div className="rounded-lg border border-cyan-300/25 bg-cyan-400/10 p-2 text-cyan-200">
          <Icon size={18} />
        </div>
        <h2 className="font-inter text-lg font-bold text-white">{title}</h2>
      </div>
      {children}
    </section>
  );
}

export default function QeKpiSlaDashboard() {
  const navigate = useNavigate();
  const { selectedMonth } = useMonth();
  const [payload, setPayload] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedKpi, setSelectedKpi] = useState(null);
  const [lightMode, setLightMode] = useState(false);

  useEffect(() => {
    let active = true;
    if (!selectedMonth) {
      setPayload(null);
      setError("");
      return () => {
        active = false;
      };
    }

    setLoading(true);
    setError("");
    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 10,
      llmTimeBudgetSeconds: 45,
    })
      .then((data) => {
        if (!active) return;
        setPayload(data);
      })
      .catch((err) => {
        if (!active) return;
        setPayload(null);
        setError(err?.message || "No QE SLA data available for the selected month.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  const dashboard = useMemo(() => (payload ? buildQeSlaDashboard(payload) : null), [payload]);
  const activeKpi = selectedKpi || dashboard?.kpis?.[0] || null;

  const trendKpis = dashboard?.kpis || [];
  const dre = trendKpis.find((item) => item.id === "dre");
  const automation = trendKpis.find((item) => item.id === "automationStability");
  const leakage = trendKpis.find((item) => item.id === "criticalLeakage");
  const uat = trendKpis.find((item) => item.id === "uatRejectionRate");

  const handleDownload = () => {
    if (!dashboard) return;
    const blob = new Blob([exportQeSlaReport(dashboard)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `qe-kpi-sla-report-${dashboard.monthId || "latest"}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`${lightMode ? "bg-slate-100 text-slate-950" : "bg-slate-950 text-slate-100"} min-h-screen overflow-x-hidden font-inter`}>
      <Header />
      <main className="mx-auto flex w-full max-w-[1500px] flex-1 flex-col gap-6 px-4 pb-10">
        <div className="rounded-2xl border border-cyan-300/20 bg-gradient-to-br from-slate-900 via-cyan-950/45 to-slate-900 p-6 shadow-2xl">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <button
                type="button"
                onClick={() => navigate("/")}
                className="mb-4 inline-flex items-center gap-2 rounded-lg border border-slate-600 bg-slate-900/70 px-3 py-2 text-sm font-bold text-slate-200 hover:border-cyan-300/50 hover:text-white"
              >
                <ArrowLeft size={16} />
                Back
              </button>
              <p className="text-sm font-bold uppercase tracking-[0.18em] text-cyan-200">Executive QE Governance</p>
              <h1 className="mt-2 text-3xl font-black tracking-normal text-white md:text-5xl">QE KPI SLA Dashboard</h1>
              <p className="mt-3 max-w-3xl text-base leading-relaxed text-slate-300">
                AI-ready release quality cockpit for SLA monitoring, defect leakage tracking, automation stability, and executive KPI reporting.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setLightMode((value) => !value)}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-600 bg-slate-900/70 px-3 py-2 text-sm font-bold text-slate-200 hover:border-cyan-300/50"
              >
                {lightMode ? <Moon size={16} /> : <Sun size={16} />}
                {lightMode ? "Dark" : "Light"}
              </button>
              <button
                type="button"
                onClick={handleDownload}
                disabled={!dashboard}
                className="inline-flex items-center gap-2 rounded-lg border border-cyan-300/35 bg-cyan-400/15 px-3 py-2 text-sm font-bold text-cyan-100 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Download size={16} />
                Report
              </button>
            </div>
          </div>
        </div>

        {loading && (
          <div className="rounded-xl border border-slate-700 bg-slate-900/80 p-8 text-center text-slate-300">
            Loading QE SLA analytics...
          </div>
        )}

        {!loading && error && (
          <div className="rounded-xl border border-amber-300/30 bg-amber-500/10 p-8 text-center text-amber-100">
            {error}
          </div>
        )}

        {!loading && !error && !dashboard && (
          <div className="rounded-xl border border-slate-700 bg-slate-900/80 p-8 text-center text-slate-300">
            Upload monthly KPI data to generate the QE KPI SLA Dashboard.
          </div>
        )}

        {dashboard && (
          <>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
              <Panel title="Release Health" icon={ShieldCheck}>
                <p className={`text-4xl font-black ${statusClass(dashboard.health).text}`}>{statusClass(dashboard.health).label}</p>
                <p className="mt-2 text-sm text-slate-400">Month {dashboard.month}</p>
              </Panel>
              <Panel title="Weighted Score" icon={Target}>
                <p className="text-4xl font-black text-cyan-100">{dashboard.weightedScore}</p>
                <p className="mt-2 text-sm text-slate-400">SLA weighted governance score</p>
              </Panel>
              <Panel title="Breach Alerts" icon={AlertTriangle}>
                <p className="text-4xl font-black text-red-200">{dashboard.breachCount}</p>
                <p className="mt-2 text-sm text-slate-400">{dashboard.warningCount} KPI(s) in warning</p>
              </Panel>
              <Panel title="Mapped KPIs" icon={BarChart3}>
                <p className="text-4xl font-black text-white">{dashboard.kpis.length}</p>
                <p className="mt-2 text-sm text-slate-400">Metadata-driven SLA rules</p>
              </Panel>
            </div>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-7">
              {dashboard.kpis.map((kpi) => (
                <MetricCard key={kpi.id} kpi={kpi} onSelect={setSelectedKpi} />
              ))}
            </div>

            <div className="flex flex-col gap-6">
              <Panel title="Trend Charts" icon={BarChart3}>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
                  {[
                    [dre, chartColors.green],
                    [automation, chartColors.cyan],
                    [leakage, chartColors.red],
                    [uat, chartColors.amber],
                  ].map(([kpi, color]) => (
                    <div key={kpi?.id || color} className="h-56 rounded-xl border border-slate-700/70 bg-slate-950/70 p-4">
                      <p className="mb-2 text-sm font-bold text-white">{kpi?.name}</p>
                      {kpi && <Line data={lineDataset(kpi, color)} options={baseChartOptions} />}
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel title="Defect Distribution" icon={FileText}>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                  {[
                    ["Severity", dashboard.charts.severityDistribution],
                    ["Defect Status", dashboard.charts.defectStatus],
                    ["Reopened", dashboard.charts.reopenedDefects],
                  ].map(([title, data]) => (
                    <div key={title} className="h-80 flex flex-col rounded-xl border border-slate-700/70 bg-slate-950/70 p-4">
                      <p className="mb-4 text-sm font-bold text-white">{title}</p>
                      <div className="relative flex-1 w-full min-h-0">
                        <Doughnut data={pieDataset(data)} options={{ ...baseChartOptions, scales: undefined }} />
                      </div>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel title="Module Risk Heatmap" icon={AlertTriangle}>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
                  {dashboard.charts.heatmap.map((item) => (
                    <div
                      key={item.module}
                      className="rounded-xl border border-white/10 p-4"
                      style={{
                        background: `linear-gradient(135deg, rgba(239,68,68,${item.riskScore / 160}), rgba(14,165,233,0.12))`,
                      }}
                    >
                      <p className="text-sm font-bold text-white">{item.module}</p>
                      <p className="mt-3 text-2xl font-black text-cyan-100">{item.riskScore}</p>
                      <p className="text-xs text-slate-400">risk score</p>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel title="SLA Breach Heatmap" icon={Target}>
                <div className="h-48 w-full">
                  <Bar
                    data={{
                      labels: dashboard.kpis.map((item) => item.shortName),
                      datasets: [
                        {
                          data: dashboard.kpis.map((item) => (item.status === "Red" ? 100 : item.status === "Amber" ? 60 : 20)),
                          backgroundColor: dashboard.kpis.map((item) =>
                            item.status === "Red" ? chartColors.red : item.status === "Amber" ? chartColors.amber : chartColors.green,
                          ),
                        },
                      ],
                    }}
                    options={baseChartOptions}
                  />
                </div>
              </Panel>
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
              <Panel title="SLA Compliance Matrix" icon={ShieldCheck} className="xl:col-span-2">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[760px] text-left text-sm">
                    <thead className="border-b border-slate-700 text-slate-400">
                      <tr>
                        <th className="py-3 pr-4">KPI</th>
                        <th className="py-3 pr-4">Current</th>
                        <th className="py-3 pr-4">Target</th>
                        <th className="py-3 pr-4">SLA</th>
                        <th className="py-3 pr-4">Risk</th>
                        <th className="py-3 pr-4">Weight</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dashboard.kpis.map((kpi) => {
                        const tone = statusClass(kpi.status);
                        return (
                          <tr key={kpi.id} className="border-b border-slate-800">
                            <td className="py-3 pr-4 font-bold text-white">{kpi.name}</td>
                            <td className={`py-3 pr-4 font-black ${tone.text}`}>{kpi.displayValue}</td>
                            <td className="py-3 pr-4 text-slate-300">{kpi.targetLabel}</td>
                            <td className="py-3 pr-4">
                              <span className={`rounded-full border px-2 py-1 text-xs font-bold ${tone.bg} ${tone.border} ${tone.text}`}>{tone.label}</span>
                            </td>
                            <td className="py-3 pr-4 text-slate-300">{kpi.risk}</td>
                            <td className="py-3 pr-4 text-slate-300">{kpi.weightage}%</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Panel>

              <Panel title="AI-Powered Insights" icon={BrainCircuit}>
                <div className="space-y-3">
                  {dashboard.insights.map((insight) => (
                    <div key={insight} className="rounded-xl border border-cyan-300/15 bg-cyan-400/10 p-4 text-sm leading-relaxed text-cyan-50">
                      {insight}
                    </div>
                  ))}
                </div>
              </Panel>
            </div>

            {activeKpi && (
              <Panel title="Drill-Down Analytics" icon={BarChart3}>
                <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                  <div className="lg:col-span-2">
                    <p className="text-xl font-black text-white">{activeKpi.name}</p>
                    <p className="mt-2 text-sm leading-relaxed text-slate-300">{activeKpi.rule}</p>
                    <div className="mt-4 h-64 rounded-xl border border-slate-700/70 bg-slate-950/70 p-4">
                      <Line data={lineDataset(activeKpi, chartColors.cyan)} options={baseChartOptions} />
                    </div>
                  </div>
                  <div className="space-y-3">
                    {Object.entries(activeKpi.parts || {}).map(([key, value]) => (
                      <div key={key} className="rounded-xl border border-slate-700 bg-slate-950/70 p-4">
                        <p className="text-xs font-bold uppercase text-slate-400">{key}</p>
                        <p className="mt-1 text-2xl font-black text-white">{value}</p>
                      </div>
                    ))}
                    <div className="rounded-xl border border-slate-700 bg-slate-950/70 p-4">
                      <p className="text-xs font-bold uppercase text-slate-400">Source</p>
                      <p className="mt-1 text-sm font-bold text-white">{activeKpi.sourceMetric}</p>
                    </div>
                  </div>
                </div>
              </Panel>
            )}
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
