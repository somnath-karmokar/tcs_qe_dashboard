import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { MonthProvider } from "./context/MonthContext";
import HomePage from "./pages/HomePage";
import KPIDetailsPage from "./pages/KPIDetailsPage";
import TrendAnalysisPage from "./pages/TrendAnalysisPage";
import ChatAssistantPage from "./pages/ChatAssistantPage";
import QeKpiSlaDashboard from "./pages/QeKpiSlaDashboard";

function App() {
  return (
    <div className="font-montserrat">
      <MonthProvider>
        <Router>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/assistant" element={<ChatAssistantPage />} />
            <Route path="/qe-kpi-dashboard" element={<QeKpiSlaDashboard />} />
            <Route path="/dashboard/qe-quality-metrics" element={<QeKpiSlaDashboard />} />
            <Route path="/kpi/:kpiName" element={<KPIDetailsPage />} />
            <Route
              path="/trendanalysis/:kpiName"
              element={<TrendAnalysisPage />}
            />
          </Routes>
        </Router>
      </MonthProvider>
    </div>
  );
}

export default App;
