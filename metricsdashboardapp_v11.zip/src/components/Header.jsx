import React from "react";
import logo from "../assets/primark-logo.webp";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, LayoutDashboard, BotMessageSquare, ShieldCheck } from "lucide-react";
import { useMonth } from "../context/MonthContext";

export default function Header() {
  const navigate = useNavigate();
  const { selectedMonth, setSelectedMonth, months } = useMonth();

  const handleLogoClick = () => {
    navigate("/");
  };

  const handlePrevious = () => {
    const currentIndex = months.indexOf(selectedMonth);
    if (currentIndex < months.length - 1) {
      setSelectedMonth(months[currentIndex + 1]);
    }
  };

  const handleNext = () => {
    const currentIndex = months.indexOf(selectedMonth);
    if (currentIndex > 0) {
      setSelectedMonth(months[currentIndex - 1]);
    }
  };

  const currentIndex = months.indexOf(selectedMonth);
  const hasMonths = months.length > 0 && currentIndex >= 0;
  const isFirstMonth = !hasMonths || currentIndex === 0;
  const isLastMonth = !hasMonths || currentIndex === months.length - 1;

  return (
    <header className="relative bg-slate-800/50 backdrop-blur-md border border-slate-700/50 rounded-2xl flex items-center justify-between px-6 py-4 mb-6 mt-2 mx-2 shadow-xl">
      <div className="flex items-center space-x-4 z-10">
        <div className="relative group cursor-pointer" onClick={handleLogoClick}>
          <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-400 to-sky-500 rounded-xl blur opacity-50 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <img
            src={logo}
            alt="Primark logo"
            className="relative h-14 w-20 rounded-xl object-contain bg-slate-950/80 p-1 ring-1 ring-white/20"
          />
        </div>
        <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 bg-slate-900/50 rounded-lg border border-slate-700">
          <LayoutDashboard size={20} className="text-cyan-400" />
          <span className="text-base font-semibold text-slate-300 tracking-wide">Primark</span>
        </div>
      </div>
      
      <h1 className="absolute inset-x-0 text-center text-2xl md:text-3xl font-bold tracking-tight text-white drop-shadow-md pointer-events-none hidden md:block">
        Primark Quality Engineering Dashboard
      </h1>
      
      <div className="flex items-center space-x-4 z-10">
        <div className="flex items-center space-x-2 bg-slate-900/60 p-1.5 rounded-xl border border-slate-700 shadow-inner">
          <button
            onClick={handlePrevious}
            disabled={isLastMonth}
            className="p-2 rounded-lg text-slate-400 hover:bg-slate-700 hover:text-white hover:shadow-sm disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            title="Previous Month"
          >
            <ChevronLeft size={24} />
          </button>
          
          <div className="px-5 py-2 min-w-[140px] text-center">
            <p className="text-white font-bold text-base tracking-wide">{selectedMonth || "No data"}</p>
          </div>
          
          <button
            onClick={handleNext}
            disabled={isFirstMonth}
            className="p-2 rounded-lg text-slate-400 hover:bg-slate-700 hover:text-white hover:shadow-sm disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            title="Next Month"
          >
            <ChevronRight size={24} />
          </button>
        </div>

        <button
          onClick={() => navigate("/qe-kpi-dashboard")}
          className="relative group p-3 bg-gradient-to-br from-emerald-500/15 to-cyan-500/15 hover:from-emerald-500/30 hover:to-cyan-500/30 border border-emerald-400/25 rounded-xl text-emerald-300 transition-all shadow-[0_0_15px_rgba(16,185,129,0.12)] hover:shadow-[0_0_20px_rgba(16,185,129,0.25)]"
          title="QE KPI SLA Dashboard"
        >
          <ShieldCheck size={24} />
        </button>

        <button
          onClick={() => navigate("/assistant")}
          className="relative group p-3 bg-gradient-to-br from-indigo-500/20 to-cyan-500/20 hover:from-indigo-500/40 hover:to-cyan-500/40 border border-cyan-500/30 rounded-xl text-cyan-400 transition-all shadow-[0_0_15px_rgba(6,182,212,0.15)] hover:shadow-[0_0_20px_rgba(6,182,212,0.3)]"
          title="AI Data Assistant"
        >
          <BotMessageSquare size={24} />
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
          </span>
        </button>
      </div>
    </header>
  );
}
