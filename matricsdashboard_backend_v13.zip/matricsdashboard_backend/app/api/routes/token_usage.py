from __future__ import annotations

from fastapi import APIRouter

from app.services.token_usage_service import clear_token_usage_log, get_token_usage_summary

router = APIRouter()


@router.get("/token-usage/summary")
def token_usage_summary() -> dict:
    return get_token_usage_summary()


@router.delete("/token-usage/clear")
def token_usage_clear() -> dict:
    return clear_token_usage_log()
