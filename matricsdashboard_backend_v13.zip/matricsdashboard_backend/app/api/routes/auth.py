from __future__ import annotations

import os

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()


class LoginRequest(BaseModel):
    username: str
    password: str


@router.post("/auth/login")
def admin_login(req: LoginRequest) -> dict:
    admin_username = os.getenv("ADMIN_USERNAME", "admin")
    admin_password = os.getenv("ADMIN_PASSWORD", "admin@123")
    if req.username == admin_username and req.password == admin_password:
        return {"success": True, "role": "admin"}
    return {"success": False, "role": None}
