from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.services.sla_data_service import load_sla_rows

router = APIRouter()


@router.get("/sla-dashboard/data")
def sla_dashboard_data():
    try:
        return load_sla_rows()
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
