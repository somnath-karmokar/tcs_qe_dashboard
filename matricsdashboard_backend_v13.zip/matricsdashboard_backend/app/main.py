
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import (
    analyze,
    anomalies,
    auth,
    copilot,
    dashboard,
    forecast,
    health,
    insights,
    metrics,
    monthly_metrics,
    report,
    sla_dashboard,
    token_usage,
    trends,
    upload,
)
import logging

logging.basicConfig(level=logging.INFO)

app = FastAPI(title="QE KPI AI Enterprise Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(upload.router, prefix="/api")
app.include_router(analyze.router, prefix="/api")
app.include_router(report.router, prefix="/api")
app.include_router(health.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(metrics.router, prefix="/api")
app.include_router(trends.router, prefix="/api")
app.include_router(anomalies.router, prefix="/api")
app.include_router(forecast.router, prefix="/api")
app.include_router(insights.router, prefix="/api")
app.include_router(copilot.router, prefix="/api")
app.include_router(monthly_metrics.router, prefix="/api")
app.include_router(sla_dashboard.router, prefix="/api")
app.include_router(token_usage.router, prefix="/api")

@app.get("/")
def root():
    return {"message": "Enterprise QE KPI Backend Running"}
