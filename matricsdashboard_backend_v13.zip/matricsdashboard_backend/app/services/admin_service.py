from __future__ import annotations

import json
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any

import pandas as pd

from app.core.openai_client import call_openai
from app.core.vector_db import add_texts, search
from app.services.ingestion_service import process_kpi_file

SUPPORTED_EXTENSIONS = {".csv", ".xlsx", ".xls", ".txt", ".md", ".json", ".docx", ".pdf"}
INSIGHTS_HISTORY_PATH = Path("app/data/historical_insights.jsonl")


def _safe_decode(content: bytes) -> str:
    for encoding in ("utf-8", "utf-16", "latin-1"):
        try:
            return content.decode(encoding)
        except UnicodeDecodeError:
            continue
    return content.decode("utf-8", errors="ignore")


def _extract_text_from_dataframe(df: pd.DataFrame, max_rows: int = 500) -> str:
    head_df = df.head(max_rows)
    preview_rows = [
        " | ".join(str(value) for value in row)
        for row in head_df.astype(str).fillna("").to_numpy().tolist()
    ]

    sections = [
        f"Columns: {', '.join(df.columns.astype(str).tolist())}",
        f"Row count: {len(df)}",
        "Preview:",
        "\n".join(preview_rows),
    ]
    return "\n".join(sections).strip()


def _read_docx_text(content: bytes) -> str:
    try:
        from docx import Document  # type: ignore
    except ImportError:
        raise RuntimeError("python-docx is not installed. Install it to parse .docx files.")

    from io import BytesIO

    doc = Document(BytesIO(content))
    return "\n".join(p.text for p in doc.paragraphs if p.text)


def _read_pdf_text(content: bytes) -> str:
    try:
        from pypdf import PdfReader  # type: ignore
    except ImportError:
        raise RuntimeError("pypdf is not installed. Install it to parse .pdf files.")

    from io import BytesIO

    reader = PdfReader(BytesIO(content))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages)


def parse_document(file_name: str, content: bytes) -> dict[str, Any]:
    suffix = Path(file_name).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type '{suffix}'. Allowed: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")

    result: dict[str, Any] = {
        "file_name": file_name,
        "extension": suffix,
        "text": "",
        "dataframe": None,
        "kpi_rows_processed": 0,
    }

    if suffix in {".csv", ".xlsx", ".xls"}:
        if suffix == ".csv":
            df = pd.read_csv(BytesIO(content))
        else:
            df = pd.read_excel(BytesIO(content))

        result["dataframe"] = df
        result["text"] = _extract_text_from_dataframe(df)

        required_columns = {"Metric Name", "Value"}
        if required_columns.issubset(df.columns):
            result["kpi_rows_processed"] = process_kpi_file(df)
        return result

    if suffix in {".txt", ".md"}:
        result["text"] = _safe_decode(content)
        return result

    if suffix == ".json":
        decoded = _safe_decode(content)
        try:
            as_obj = json.loads(decoded)
            result["text"] = json.dumps(as_obj, indent=2)
        except json.JSONDecodeError:
            result["text"] = decoded
        return result

    if suffix == ".docx":
        result["text"] = _read_docx_text(content)
        return result

    if suffix == ".pdf":
        result["text"] = _read_pdf_text(content)
        return result

    return result


def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 150) -> list[str]:
    clean_text = text.strip()
    if not clean_text:
        return []

    chunks: list[str] = []
    start = 0
    text_len = len(clean_text)

    while start < text_len:
        end = min(start + chunk_size, text_len)
        chunks.append(clean_text[start:end])
        if end == text_len:
            break
        start = max(end - overlap, start + 1)

    return chunks


def ingest_documents(files: list[tuple[str, bytes]]) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []

    for file_name, content in files:
        parsed = parse_document(file_name=file_name, content=content)

        text_chunks = chunk_text(parsed["text"])
        vector_chunks = [f"SOURCE: {file_name}\n{chunk}" for chunk in text_chunks]

        if vector_chunks:
            add_texts(vector_chunks)

        results.append(
            {
                "file_name": file_name,
                "chunks_added": len(vector_chunks),
                "kpi_rows_processed": parsed["kpi_rows_processed"],
                "text_preview": parsed["text"][:600],
            }
        )

    return results


def load_historical_insights(limit: int | None = None) -> list[dict[str, Any]]:
    if not INSIGHTS_HISTORY_PATH.exists():
        return []

    rows: list[dict[str, Any]] = []
    with INSIGHTS_HISTORY_PATH.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    rows = sorted(rows, key=lambda x: x.get("created_at", ""), reverse=True)
    if limit is not None:
        return rows[:limit]
    return rows


def save_historical_insight(record: dict[str, Any]) -> None:
    INSIGHTS_HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    with INSIGHTS_HISTORY_PATH.open("a", encoding="utf-8") as file:
        file.write(json.dumps(record, ensure_ascii=True) + "\n")



def _build_analysis_prompt(current_doc_text: str, historical_context: str, query: str) -> str:
    return f"""
You are an enterprise KPI analyst.
Use the historical insights and current document to generate actionable admin insights.
Return strict JSON with keys exactly:
summary, key_findings, risks, recommendations, trend_comparison, anomaly_notes.

User Query:
{query}

Current Document:
{current_doc_text[:12000]}

Historical Insights:
{historical_context[:12000]}
""".strip()



def analyze_with_history(current_file_name: str, current_content: bytes, query: str) -> dict[str, Any]:
    parsed_current = parse_document(current_file_name, current_content)
    current_text = parsed_current["text"]

    current_chunks = chunk_text(current_text)
    current_query = current_chunks[0][:700] if current_chunks else query

    retrieved = search(current_query, k=8)
    historical_context = "\n\n".join(doc.page_content for doc in retrieved)

    prompt = _build_analysis_prompt(
        current_doc_text=current_text,
        historical_context=historical_context,
        query=query,
    )

    ai_output_raw = call_openai(prompt, feature="admin_analysis")
    try:
        ai_output = json.loads(ai_output_raw)
    except json.JSONDecodeError:
        ai_output = {"summary": ai_output_raw}

    insight_record = {
        "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "source_file": current_file_name,
        "query": query,
        "analysis": ai_output,
        "historical_refs": len(retrieved),
    }

    save_historical_insight(insight_record)
    add_texts(
        [
            f"HISTORICAL_INSIGHT from {current_file_name} at {insight_record['created_at']}: "
            f"{json.dumps(ai_output, ensure_ascii=True)}"
        ]
    )

    return {
        "insight_record": insight_record,
        "current_doc_preview": current_text[:1500],
        "retrieved_context_count": len(retrieved),
        "kpi_rows_processed": parsed_current["kpi_rows_processed"],
    }
