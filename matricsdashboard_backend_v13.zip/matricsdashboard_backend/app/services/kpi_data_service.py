from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

from app.core.openai_client import call_openai
from app.core.vector_db import add_texts, search

DATA_DIR = Path("app/data")
TIMESERIES_PATH = DATA_DIR / "kpi_timeseries.jsonl"
DEFINITIONS_PATH = DATA_DIR / "kpi_definitions.json"


def _parse_month(value: str) -> datetime:
    return datetime.strptime(value, "%Y-%m")


def _month_label(value: str) -> str:
    return _parse_month(value).strftime("%b %Y")


def _to_float(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    return float(str(value).strip())


def _normalize_metric(value: str) -> str:
    return value.strip()


def _safe_round(value: float) -> float | int:
    rounded = round(value, 2)
    if float(rounded).is_integer():
        return int(rounded)
    return rounded


def load_metric_definitions() -> dict[str, dict[str, Any]]:
    if not DEFINITIONS_PATH.exists():
        return {}
    raw = json.loads(DEFINITIONS_PATH.read_text(encoding="utf-8"))
    normalized: dict[str, dict[str, Any]] = {}
    for key, value in raw.items():
        normalized[_normalize_metric(key).lower()] = value
    return normalized


def get_metric_definition(metric_name: str) -> dict[str, Any] | None:
    return load_metric_definitions().get(_normalize_metric(metric_name).lower())


def _read_records() -> list[dict[str, Any]]:
    if not TIMESERIES_PATH.exists():
        return []

    rows: list[dict[str, Any]] = []
    with TIMESERIES_PATH.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
                row["metric_name"] = _normalize_metric(row["metric_name"])
                row["value"] = _to_float(row["value"])
                _parse_month(row["date"])
                rows.append(row)
            except (json.JSONDecodeError, KeyError, ValueError):
                continue
    return rows


def add_kpi_record(metric_name: str, value: float, date: str, project: str, team: str) -> dict[str, Any]:
    normalized_name = _normalize_metric(metric_name)
    _parse_month(date)
    numeric_value = _to_float(value)
    payload = {
        "metric_name": normalized_name,
        "value": numeric_value,
        "date": date,
        "project": project.strip(),
        "team": team.strip(),
        "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with TIMESERIES_PATH.open("a", encoding="utf-8") as file:
        file.write(json.dumps(payload, ensure_ascii=True) + "\n")

    add_texts(
        [
            f"KPI_RECORD metric={normalized_name} value={numeric_value} date={date} "
            f"project={payload['project']} team={payload['team']}"
        ]
    )

    return payload


def _group_by_metric(records: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in records:
        grouped[row["metric_name"]].append(row)
    for metric in grouped:
        grouped[metric] = sorted(grouped[metric], key=lambda item: item["date"])
    return grouped


def _metric_month_average(records: list[dict[str, Any]]) -> dict[tuple[str, str], float]:
    values: dict[tuple[str, str], list[float]] = defaultdict(list)
    for row in records:
        values[(row["metric_name"], row["date"])].append(row["value"])
    return {key: float(np.mean(v)) for key, v in values.items()}


def _category_buckets() -> dict[str, str]:
    definitions = load_metric_definitions()
    result: dict[str, str] = {}
    for metric_lower, definition in definitions.items():
        result[metric_lower] = str(definition.get("category", "Uncategorized")).strip()
    return result


def list_metric_names() -> list[str]:
    names = sorted({_normalize_metric(row["metric_name"]) for row in _read_records()})
    return names


def get_dashboard_summary() -> dict[str, Any]:
    records = _read_records()
    if not records:
        raise ValueError("No KPI data available. Ingest KPI records first.")

    month_values = sorted({row["date"] for row in records})
    latest_month = month_values[-1]
    previous_month = month_values[-2] if len(month_values) > 1 else None

    month_avg = _metric_month_average(records)
    latest_metric_values: dict[str, float] = {}
    previous_metric_values: dict[str, float] = {}

    for metric, value in month_avg.items():
        metric_name, month = metric
        if month == latest_month:
            latest_metric_values[metric_name] = value
        if previous_month and month == previous_month:
            previous_metric_values[metric_name] = value

    if not latest_metric_values:
        raise ValueError("Latest month has no KPI metrics.")

    overall_score = float(np.mean(list(latest_metric_values.values())))
    previous_score = None
    if previous_metric_values:
        previous_score = float(np.mean(list(previous_metric_values.values())))

    trend_delta = overall_score - previous_score if previous_score is not None else 0.0
    trend_text = f"{trend_delta:+.0f}"

    metric_to_category = _category_buckets()
    categorized: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for metric, value in sorted(latest_metric_values.items()):
        category = metric_to_category.get(metric.lower(), "Other")
        categorized[category].append({"name": metric, "value": _safe_round(value)})

    response = {
        "month": _month_label(latest_month),
        "overall_score": _safe_round(overall_score),
        "trend": trend_text,
        "engineering": categorized.get("Engineering", []),
        "velocity": categorized.get("Velocity", []),
        "quality": categorized.get("Quality", []),
        "collaboration": categorized.get("Collaboration", []),
    }
    return response


def get_health_score() -> dict[str, Any]:
    summary = get_dashboard_summary()
    records = _read_records()
    month_values = sorted({row["date"] for row in records})
    previous_month = month_values[-2] if len(month_values) > 1 else None

    contributors: list[str] = []
    if previous_month:
        month_avg = _metric_month_average(records)
        latest_month = month_values[-1]
        deltas: list[tuple[str, float]] = []
        for (metric_name, month), value in month_avg.items():
            if month != latest_month:
                continue
            prev_key = (metric_name, previous_month)
            if prev_key in month_avg:
                deltas.append((metric_name, value - month_avg[prev_key]))
        deltas = sorted(deltas, key=lambda item: item[1], reverse=True)
        for metric, delta in deltas[:2]:
            if delta > 0:
                contributors.append(f"Improved {metric} by {delta:.1f} points")

    if not contributors:
        contributors = [f"Baseline established for {summary['month']}"]

    return {
        "score": summary["overall_score"],
        "trend": summary["trend"],
        "contributors": contributors,
    }


def get_dashboard_narrative() -> dict[str, str]:
    summary = get_dashboard_summary()
    health = get_health_score()
    response_text = (
        f"{summary['month']} overall score is {summary['overall_score']} with trend {summary['trend']}. "
        f"Top contributors: {', '.join(health['contributors'])}."
    )
    return {"summary": response_text}


def ingest_metric(payload: dict[str, Any]) -> dict[str, str]:
    add_kpi_record(
        metric_name=str(payload["metric_name"]),
        value=float(payload["value"]),
        date=str(payload["date"]),
        project=str(payload["project"]),
        team=str(payload["team"]),
    )
    return {"status": "success", "message": "Metric stored successfully"}


def get_gauge_metrics() -> dict[str, list[dict[str, Any]]]:
    records = _read_records()
    if not records:
        raise ValueError("No KPI data available. Ingest KPI records first.")

    definitions = load_metric_definitions()
    grouped = _group_by_metric(records)
    response_rows: list[dict[str, Any]] = []

    for metric_name, rows in grouped.items():
        per_month: dict[str, list[float]] = defaultdict(list)
        for row in rows:
            per_month[row["date"]].append(row["value"])
        recent_months = sorted(per_month.keys())[-2:]
        definition = definitions.get(metric_name.lower(), {})
        thresholds = definition.get("thresholds", {})
        goal = str(definition.get("goal", "higher")).lower()
        good = thresholds.get("good")
        average = thresholds.get("average")
        for month in recent_months:
            value = float(np.mean(per_month[month]))
            if good is not None and average is not None:
                if goal == "lower":
                    if value <= float(good):
                        status = "GREEN"
                    elif value <= float(average):
                        status = "AMBER"
                    else:
                        status = "RED"
                else:
                    if value >= float(good):
                        status = "GREEN"
                    elif value >= float(average):
                        status = "AMBER"
                    else:
                        status = "RED"
            else:
                status = "UNKNOWN"
            response_rows.append(
                {
                    "name": metric_name,
                    "month": _month_label(month),
                    "value": _safe_round(value),
                    "status": status,
                }
            )

    response_rows = sorted(response_rows, key=lambda row: (row["name"], row["month"]))
    return {"metrics": response_rows}


def get_metric_trend(metric_name: str) -> dict[str, Any]:
    target = _normalize_metric(metric_name).lower()
    records = [row for row in _read_records() if row["metric_name"].lower() == target]
    if not records:
        raise ValueError(f"No KPI history found for metric '{metric_name}'.")

    per_month: dict[str, list[float]] = defaultdict(list)
    for row in records:
        per_month[row["date"]].append(row["value"])

    months = sorted(per_month.keys())
    points = [{"month": _month_label(month), "value": _safe_round(float(np.mean(per_month[month])))} for month in months]
    numeric_values = [float(np.mean(per_month[month])) for month in months]

    highest_idx = int(np.argmax(numeric_values))
    lowest_idx = int(np.argmin(numeric_values))
    latest_idx = len(numeric_values) - 1

    if len(numeric_values) > 1 and numeric_values[-2] != 0:
        pct_change = ((numeric_values[-1] - numeric_values[-2]) / abs(numeric_values[-2])) * 100.0
    else:
        pct_change = 0.0

    definition = get_metric_definition(metric_name)
    ideal_threshold = definition.get("thresholds", {}).get("good") if definition else _safe_round(float(np.mean(numeric_values)))

    return {
        "metric": _normalize_metric(metric_name),
        "ideal_threshold": _safe_round(float(ideal_threshold)),
        "data": points,
        "highlights": {
            "highest": {"value": _safe_round(numeric_values[highest_idx]), "month": points[highest_idx]["month"]},
            "lowest": {"value": _safe_round(numeric_values[lowest_idx]), "month": points[lowest_idx]["month"]},
            "latest": {"value": _safe_round(numeric_values[latest_idx]), "month": points[latest_idx]["month"]},
            "change": f"{pct_change:+.1f}%",
        },
    }


def get_anomalies(metric_name: str) -> dict[str, Any]:
    trend = get_metric_trend(metric_name)
    data = trend["data"]
    values = [float(point["value"]) for point in data]
    alerts: list[dict[str, str]] = []

    if len(values) >= 2:
        prev = values[-2]
        latest = values[-1]
        change = latest - prev
        if prev != 0:
            pct = (change / abs(prev)) * 100.0
        else:
            pct = 0.0
        if abs(pct) >= 20.0:
            alert_type = "DROP" if change < 0 else "SPIKE"
            severity = "HIGH" if abs(pct) >= 30.0 else "MEDIUM"
            alerts.append(
                {
                    "type": alert_type,
                    "message": f"{_normalize_metric(metric_name)} changed {pct:+.1f}% vs previous period",
                    "root_cause": "Large shift detected against recent trend",
                    "severity": severity,
                }
            )

    return {"metric": _normalize_metric(metric_name), "alerts": alerts}


def get_forecast(metric_name: str) -> dict[str, Any]:
    trend = get_metric_trend(metric_name)
    values = [float(point["value"]) for point in trend["data"]]
    if len(values) < 2:
        raise ValueError(f"Insufficient history to forecast metric '{metric_name}'.")

    deltas = [values[idx] - values[idx - 1] for idx in range(1, len(values))]
    avg_delta = float(np.mean(deltas))
    volatility = float(np.std(deltas)) if len(deltas) > 1 else 0.0
    confidence = max(0.5, min(0.95, 0.9 - (volatility / max(abs(values[-1]), 1.0))))

    prediction = values[-1] + avg_delta
    if avg_delta > 0:
        trend_label = "UPWARD"
    elif avg_delta < 0:
        trend_label = "DOWNWARD"
    else:
        trend_label = "FLAT"

    return {
        "metric": _normalize_metric(metric_name),
        "prediction": {
            "next_sprint": _safe_round(prediction),
            "confidence": round(confidence, 2),
            "trend": trend_label,
        },
    }


def _build_metric_month_matrix(records: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    values = _metric_month_average(records)
    matrix: dict[str, dict[str, float]] = defaultdict(dict)
    for (metric_name, month), value in values.items():
        matrix[metric_name][month] = value
    return matrix


def get_root_cause(metric_name: str) -> dict[str, Any]:
    records = _read_records()
    matrix = _build_metric_month_matrix(records)
    metric_input = _normalize_metric(metric_name).lower()
    metric_lookup = {name.lower(): name for name in matrix.keys()}
    metric = metric_lookup.get(metric_input)
    if metric is None:
        raise ValueError(f"No KPI history found for metric '{metric_name}'.")

    target_series = matrix[metric]
    insights: list[dict[str, Any]] = []
    for other_metric, other_series in matrix.items():
        if other_metric == metric:
            continue
        overlap_months = sorted(set(target_series.keys()) & set(other_series.keys()))
        if len(overlap_months) < 3:
            continue
        x = [target_series[month] for month in overlap_months]
        y = [other_series[month] for month in overlap_months]
        correlation = float(np.corrcoef(x, y)[0, 1])
        if np.isnan(correlation):
            continue
        if abs(correlation) < 0.4:
            continue
        factor = f"Low {other_metric}" if correlation < 0 else f"Change in {other_metric}"
        insights.append(
            {
                "factor": factor,
                "impact": f"{abs(correlation) * 100:.0f}%",
                "correlation": round(correlation, 2),
            }
        )

    if not insights:
        raise ValueError(f"Insufficient correlated KPI history for metric '{metric_name}'.")

    insights = sorted(insights, key=lambda item: abs(item["correlation"]), reverse=True)[:3]
    return {"metric": metric, "insights": insights}


def get_recommendations(metric_name: str) -> dict[str, Any]:
    root = get_root_cause(metric_name)
    recommendations: list[str] = []
    for insight in root["insights"]:
        factor = insight["factor"]
        if factor.startswith("Low "):
            focus_metric = factor.replace("Low ", "").strip()
            recommendations.append(f"Increase {focus_metric} with targeted sprint-level actions.")
        else:
            recommendations.append(f"Review dependency between {metric_name} and {factor.replace('Change in ', '')}.")

    recommendations = recommendations[:3]
    return {"metric": _normalize_metric(metric_name), "recommendations": recommendations}


def _ensure_latest_monthly_analysis() -> dict[str, Any] | None:
    try:
        from app.services import monthly_metrics_service
    except Exception:
        return None

    analysis = monthly_metrics_service._latest_analysis()  # noqa: SLF001
    if analysis:
        return analysis

    try:
        # Build analysis context on-demand using the default 6-month lookback.
        monthly_metrics_service.start_monthly_analysis(
            lookback_months=6,
            use_llm=False,
            max_llm_metrics=0,
            llm_time_budget_seconds=0,
        )
        return monthly_metrics_service._latest_analysis()  # noqa: SLF001
    except Exception:
        return None


def _build_monthly_copilot_context(analysis: dict[str, Any], max_metrics: int = 30) -> tuple[str, list[str]]:
    month = str(analysis.get("month", analysis.get("month_id", ""))).strip() or "latest month"
    lookback = int(analysis.get("lookback_months", 6) or 6)
    rows = analysis.get("metric_month_analyses", [])
    if not isinstance(rows, list):
        rows = []

    lines: list[str] = [f"Analysis month: {month}", f"Lookback window: {lookback} months"]
    metric_names: list[str] = []
    for row in rows[:max_metrics]:
        if not isinstance(row, dict):
            continue
        metric_name = str(row.get("metric_name", "")).strip()
        category = str(row.get("category", "")).strip()
        trend = str(row.get("trend", "")).strip()
        risk = str(row.get("risk", "")).strip()
        change = row.get("change_vs_avg_pct")
        current = row.get("current_value")
        summary = str(row.get("summary", "")).strip()
        recommendation = str(row.get("recommendation", "")).strip()
        if metric_name:
            metric_names.append(metric_name)

        line = (
            f"{category} | {metric_name}: current={current}, trend={trend}, "
            f"risk={risk}, change_vs_avg_pct={change}. summary={summary} "
            f"recommendation={recommendation}"
        )
        lines.append(line)

    return "\n".join(lines), sorted({name for name in metric_names if name})


def _fallback_monthly_answer(question_text: str, analysis: dict[str, Any]) -> tuple[str, list[str]]:
    rows = analysis.get("metric_month_analyses", [])
    if not isinstance(rows, list) or not rows:
        return (
            "Monthly analysis context is not available yet. Run Monthly Ops analysis for the last 6 months and retry.",
            [],
        )

    sorted_rows = sorted(
        [row for row in rows if isinstance(row, dict)],
        key=lambda item: abs(float(item.get("change_vs_avg_pct", 0) or 0)),
        reverse=True,
    )
    top_rows = sorted_rows[:3]
    highlights = []
    support = []
    for row in top_rows:
        metric_name = str(row.get("metric_name", "")).strip()
        trend = str(row.get("trend", "")).strip() or "stable"
        change = float(row.get("change_vs_avg_pct", 0) or 0)
        risk = str(row.get("risk", "")).strip() or "medium"
        if metric_name:
            support.append(metric_name)
            highlights.append(f"{metric_name} is {trend} ({change:+.1f}% vs 6-month avg, risk {risk})")

    answer = (
        f"Based on the latest monthly analysis ({analysis.get('month', analysis.get('month_id', 'latest'))}) "
        f"and the past 6-month window, key signals are: " + "; ".join(highlights) + "."
    )
    return answer, sorted(set(support))


def _to_readable_answer(raw_answer: Any) -> str:
    if isinstance(raw_answer, str):
        text = raw_answer.strip()
    elif isinstance(raw_answer, dict):
        text = str(raw_answer.get("answer") or raw_answer.get("summary") or "").strip()
    elif isinstance(raw_answer, list):
        text = " ".join(str(item).strip() for item in raw_answer if str(item).strip())
    else:
        text = str(raw_answer).strip()

    if not text:
        return ""

    if text.startswith("{") and text.endswith("}"):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                text = str(parsed.get("answer") or parsed.get("summary") or "").strip() or text
        except json.JSONDecodeError:
            pass

    if text.startswith("[") and text.endswith("]"):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                text = " ".join(str(item).strip() for item in parsed if str(item).strip())
        except json.JSONDecodeError:
            pass

    text = text.replace("\n\n", "\n").strip()
    return text


def ask_copilot(question: str) -> dict[str, Any]:
    question_text = question.strip()
    if not question_text:
        raise ValueError("Question cannot be empty.")

    monthly_analysis = _ensure_latest_monthly_analysis()
    if monthly_analysis:
        monthly_context, monthly_metrics = _build_monthly_copilot_context(monthly_analysis)
        prompt = f"""
You are a QE KPI copilot.
Answer the user question using only the monthly analysis context below.
The context is based on the latest analysis with a 6-month lookback.
Return strict JSON with keys: answer, supporting_metrics.

Question: {question_text}
Monthly Analysis Context:
{monthly_context[:12000]}
""".strip()

        try:
            parsed = json.loads(call_openai(prompt, feature="copilot"))
            answer_text = _to_readable_answer(parsed.get("answer", ""))
            supporting_metrics = parsed.get("supporting_metrics", [])
            if isinstance(supporting_metrics, list):
                merged_metrics = sorted(
                    {
                        *monthly_metrics,
                        *[str(item).strip() for item in supporting_metrics if str(item).strip()],
                    }
                )
            else:
                merged_metrics = monthly_metrics

            if answer_text:
                return {"answer": answer_text, "supporting_metrics": merged_metrics}
        except Exception:
            pass

        fallback_answer, fallback_metrics = _fallback_monthly_answer(question_text, monthly_analysis)
        return {"answer": fallback_answer, "supporting_metrics": fallback_metrics or monthly_metrics}

    # Legacy fallback when monthly analysis context is unavailable.
    known_metrics = list_metric_names()
    supporting_metrics = [metric for metric in known_metrics if metric.lower() in question_text.lower()]

    context_parts: list[str] = []
    try:
        docs = search(question_text, k=5)
        context_parts.extend([doc.page_content for doc in docs])
    except Exception:
        docs = []

    if not context_parts:
        records = _read_records()
        if records:
            latest = sorted(records, key=lambda item: item["date"])[-10:]
            context_parts.extend(
                [
                    f"{row['metric_name']}={row['value']} on {row['date']} "
                    f"(project={row['project']}, team={row['team']})"
                    for row in latest
                ]
            )

    context = "\n".join(context_parts)[:12000]
    prompt = f"""
You are a QE KPI copilot.
Answer the user question using only the provided KPI context.
Return strict JSON with keys: answer, supporting_metrics.

Question: {question_text}
KPI Context:
{context}
""".strip()

    answer_text: str
    try:
        parsed = json.loads(call_openai(prompt, feature="copilot"))
        answer_text = _to_readable_answer(parsed.get("answer", ""))
        model_metrics = parsed.get("supporting_metrics", [])
        if isinstance(model_metrics, list):
            supporting_metrics.extend([str(item) for item in model_metrics if str(item).strip()])
    except Exception:
        answer_text = ""

    if not answer_text:
        if context:
            answer_text = "Recent KPI history indicates trends in the requested area. Review supporting metrics for details."
        else:
            answer_text = (
                "No monthly analysis context is available yet. "
                "Upload monthly data and run Monthly Ops analysis (lookback 6 months), then retry."
            )

    supporting_metrics = sorted({metric.strip() for metric in supporting_metrics if metric.strip()})
    return {"answer": answer_text, "supporting_metrics": supporting_metrics}
