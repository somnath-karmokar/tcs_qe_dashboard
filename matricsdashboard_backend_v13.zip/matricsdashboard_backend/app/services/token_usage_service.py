from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

TOKEN_LOG_PATH = Path("data/token_usage.jsonl")

# Cost per 1 000 tokens (USD) — approximate public pricing
_MODEL_COST: dict[str, dict[str, float]] = {
    "gpt-4o-mini": {"input": 0.00015, "output": 0.00060},
    "gpt-4o": {"input": 0.00250, "output": 0.01000},
    "gpt-4": {"input": 0.03000, "output": 0.06000},
    "gpt-3.5-turbo": {"input": 0.00050, "output": 0.00150},
}
_DEFAULT_COST = {"input": 0.00200, "output": 0.00600}

_FEATURE_LABELS: dict[str, str] = {
    "metric_analysis": "Monthly Metric Analysis",
    "copilot": "AI Copilot",
    "kpi_analysis": "KPI Analysis",
    "admin_analysis": "Admin Analysis",
    "general": "General",
}


def _model_cost(model: str) -> dict[str, float]:
    for key, cost in _MODEL_COST.items():
        if key in model.lower():
            return cost
    return _DEFAULT_COST


def _estimate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    cost = _model_cost(model)
    return round(
        (prompt_tokens / 1_000) * cost["input"]
        + (completion_tokens / 1_000) * cost["output"],
        6,
    )


def _read_log() -> list[dict[str, Any]]:
    if not TOKEN_LOG_PATH.exists():
        return []
    records: list[dict[str, Any]] = []
    with TOKEN_LOG_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return records


def get_token_usage_summary() -> dict[str, Any]:
    records = _read_log()

    total_calls = len(records)
    total_prompt = 0
    total_completion = 0
    total_tokens_all = 0
    total_cost = 0.0

    feature_map: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "estimated_cost_usd": 0.0}
    )
    model_map: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "estimated_cost_usd": 0.0}
    )
    daily_map: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"calls": 0, "total_tokens": 0}
    )

    for record in records:
        p = int(record.get("prompt_tokens") or 0)
        c = int(record.get("completion_tokens") or 0)
        t = int(record.get("total_tokens") or 0)
        model = str(record.get("model") or "unknown")
        feature = str(record.get("feature") or "general")
        ts = str(record.get("timestamp") or "")
        cost = _estimate_cost(model, p, c)

        total_prompt += p
        total_completion += c
        total_tokens_all += t
        total_cost += cost

        feature_map[feature]["calls"] += 1
        feature_map[feature]["prompt_tokens"] += p
        feature_map[feature]["completion_tokens"] += c
        feature_map[feature]["total_tokens"] += t
        feature_map[feature]["estimated_cost_usd"] = round(
            feature_map[feature]["estimated_cost_usd"] + cost, 6
        )

        model_map[model]["calls"] += 1
        model_map[model]["prompt_tokens"] += p
        model_map[model]["completion_tokens"] += c
        model_map[model]["total_tokens"] += t
        model_map[model]["estimated_cost_usd"] = round(
            model_map[model]["estimated_cost_usd"] + cost, 6
        )

        day = ts[:10] if len(ts) >= 10 else "unknown"
        daily_map[day]["calls"] += 1
        daily_map[day]["total_tokens"] += t

    recent = sorted(records, key=lambda r: r.get("timestamp", ""), reverse=True)[:20]
    for r in recent:
        r["estimated_cost_usd"] = _estimate_cost(
            str(r.get("model") or "unknown"),
            int(r.get("prompt_tokens") or 0),
            int(r.get("completion_tokens") or 0),
        )

    by_feature = [
        {
            "feature": feature,
            "label": _FEATURE_LABELS.get(feature, feature.replace("_", " ").title()),
            **stats,
            "estimated_cost_usd": round(stats["estimated_cost_usd"], 6),
        }
        for feature, stats in sorted(feature_map.items(), key=lambda item: item[1]["total_tokens"], reverse=True)
    ]
    by_model = [
        {"model": model, **stats, "estimated_cost_usd": round(stats["estimated_cost_usd"], 6)}
        for model, stats in sorted(model_map.items(), key=lambda item: item[1]["total_tokens"], reverse=True)
    ]
    daily = [
        {"date": day, **stats}
        for day, stats in sorted(daily_map.items())
    ]

    now_utc = datetime.now(timezone.utc).isoformat(timespec="seconds")

    return {
        "generated_at": now_utc,
        "total_calls": total_calls,
        "total_prompt_tokens": total_prompt,
        "total_completion_tokens": total_completion,
        "total_tokens": total_tokens_all,
        "total_estimated_cost_usd": round(total_cost, 6),
        "has_data": total_calls > 0,
        "by_feature": by_feature,
        "by_model": by_model,
        "daily": daily,
        "recent_calls": recent,
    }


def clear_token_usage_log() -> dict[str, Any]:
    count = len(_read_log())
    if TOKEN_LOG_PATH.exists():
        TOKEN_LOG_PATH.unlink()
    return {"status": "cleared", "deleted_records": count}
