from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Any

import pandas as pd

BACKEND_ROOT = Path(__file__).resolve().parents[2]
SLA_DATA_DIR = BACKEND_ROOT / "data" / "sla"
SLA_DATA_FILE = SLA_DATA_DIR / "sla_kpi_data.csv"

REQUIRED_SLA_COLUMNS = [
    "month",
    "sit_defects",
    "uat_defects",
    "prod_defects",
    "sev1",
    "sev2",
    "planned_tests",
    "executed_tests",
    "reopened_defects",
    "closed_defects",
    "successful_runs",
    "total_runs",
    "regression_cycles_completed",
    "total_regression_cycles",
    "uat_missed_defects",
    "total_uat_defects",
]


def normalize_sla_column(value: object) -> str:
    text = str(value or "").replace("\u200b", "").strip().lower()
    normalized = []
    last_was_separator = False
    for char in text:
        if char.isalnum():
            normalized.append(char)
            last_was_separator = False
        elif not last_was_separator:
            normalized.append("_")
            last_was_separator = True
    return "".join(normalized).strip("_")


def normalize_sla_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    normalized = df.copy()
    normalized.columns = [normalize_sla_column(column) for column in normalized.columns]
    return normalized


def validate_sla_dataframe(df: pd.DataFrame) -> list[str]:
    if df.empty:
        return ["CSV contains no data rows."]
    missing = [column for column in REQUIRED_SLA_COLUMNS if column not in df.columns]
    if missing:
        return [f"Missing required columns: {', '.join(missing)}"]
    return []


def read_sla_csv_bytes(file_bytes: bytes) -> pd.DataFrame:
    try:
        df = pd.read_csv(BytesIO(file_bytes))
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Unable to read SLA CSV file: {exc}") from exc
    normalized = normalize_sla_dataframe(df)
    errors = validate_sla_dataframe(normalized)
    if errors:
        raise ValueError("; ".join(errors))
    return normalized


def save_sla_csv(file_bytes: bytes) -> dict[str, Any]:
    df = read_sla_csv_bytes(file_bytes)
    SLA_DATA_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(SLA_DATA_FILE, index=False)
    return {
        "status": "success",
        "file": str(SLA_DATA_FILE),
        "rows": int(len(df)),
        "columns": list(df.columns),
        "months": [str(value) for value in df["month"].dropna().unique().tolist()],
    }


def load_sla_rows() -> dict[str, Any]:
    if not SLA_DATA_FILE.exists():
        return {
            "status": "empty",
            "file": str(SLA_DATA_FILE),
            "rows": [],
            "message": "No SLA CSV has been uploaded yet.",
        }
    df = pd.read_csv(SLA_DATA_FILE)
    normalized = normalize_sla_dataframe(df)
    errors = validate_sla_dataframe(normalized)
    if errors:
        raise ValueError("; ".join(errors))
    return {
        "status": "success",
        "file": str(SLA_DATA_FILE),
        "row_count": int(len(normalized)),
        "rows": normalized.to_dict(orient="records"),
    }
