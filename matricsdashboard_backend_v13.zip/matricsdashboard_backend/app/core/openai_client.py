from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from openai import OpenAI, AzureOpenAI

from app.core.config import (
    USE_AZURE_OPENAI,
    OPENAI_API_KEY,
    OPENAI_MODEL,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    OPENAI_API_VERSION,
    AZURE_OPENAI_CHAT_DEPLOYMENT_NAME,
)

logger = logging.getLogger(__name__)

TOKEN_LOG_PATH = Path("data/token_usage.jsonl")

if USE_AZURE_OPENAI:
    client = AzureOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=OPENAI_API_VERSION,
        timeout=12.0,
        max_retries=0,
    )
else:
    client = OpenAI(
        api_key=OPENAI_API_KEY,
        timeout=12.0,
        max_retries=0,
    )


def _log_token_usage(
    feature: str,
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
) -> None:
    try:
        TOKEN_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "feature": feature,
            "model": model,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": total_tokens,
        }
        with TOKEN_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=True) + "\n")
    except Exception:  # noqa: BLE001
        logger.warning("Failed to log token usage", exc_info=True)


def call_openai(prompt: str, feature: str = "general") -> str:
    if USE_AZURE_OPENAI:
        model = AZURE_OPENAI_CHAT_DEPLOYMENT_NAME
    else:
        model = OPENAI_MODEL

    kwargs = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "response_format": {"type": "json_object"},
    }

    response = client.chat.completions.create(**kwargs)

    usage = response.usage
    if usage:
        _log_token_usage(
            feature=feature,
            model=model,
            prompt_tokens=int(usage.prompt_tokens or 0),
            completion_tokens=int(usage.completion_tokens or 0),
            total_tokens=int(usage.total_tokens or 0),
        )

    return response.choices[0].message.content
