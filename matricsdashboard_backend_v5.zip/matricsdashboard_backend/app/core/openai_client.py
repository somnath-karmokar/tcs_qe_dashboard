
from openai import OpenAI
from app.core.config import OPENAI_API_KEY

client = OpenAI(
    api_key=OPENAI_API_KEY,
    timeout=12.0,
    max_retries=0,
)

def call_openai(prompt):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"}
    )
    return response.choices[0].message.content
