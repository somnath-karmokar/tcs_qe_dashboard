from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.monthly_metrics_service import (
    delete_all_monthly_history,
    delete_monthly_history,
    get_frontend_metrics,
    list_uploaded_months,
    start_monthly_analysis,
    upload_monthly_rows,
)

router = APIRouter()


class MonthlyRowsUploadRequest(BaseModel):
    month: str = Field(..., description="Month in YYYY-MM or Mon YYYY format")
    dashboard_title: str = "Quality Engineering Dashboard"
    rows: list[dict[str, Any]]


class MonthlyAnalysisRequest(BaseModel):
    month: str | None = None
    lookback_months: int = Field(default=6, ge=1, le=24)
    use_llm: bool = False
    max_llm_metrics: int = Field(default=3, ge=0, le=100)
    llm_time_budget_seconds: int = Field(default=20, ge=0, le=300)


@router.post("/monthly-metrics/upload-rows")
def upload_rows(payload: MonthlyRowsUploadRequest):
    try:
        data = payload.model_dump() if hasattr(payload, "model_dump") else payload.dict()
        return upload_monthly_rows(
            rows=data["rows"],
            month=data["month"],
            dashboard_title=data["dashboard_title"],
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/monthly-metrics/months")
def monthly_months():
    return {"months": list_uploaded_months()}


@router.post("/monthly-metrics/start-analysis")
def monthly_start_analysis(payload: MonthlyAnalysisRequest):
    try:
        data = payload.model_dump() if hasattr(payload, "model_dump") else payload.dict()
        return start_monthly_analysis(
            month=data.get("month"),
            lookback_months=int(data["lookback_months"]),
            use_llm=bool(data["use_llm"]),
            max_llm_metrics=int(data["max_llm_metrics"]),
            llm_time_budget_seconds=int(data["llm_time_budget_seconds"]),
            analyze_all_months=True,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/monthly-metrics/frontend")
def monthly_frontend_data(
    month: str | None = None,
    history_months: int = 6,
    ensure_analysis: bool = False,
    refresh_analysis: bool = False,
    use_llm: bool = True,
    max_llm_metrics: int = 8,
    llm_time_budget_seconds: int = 45,
):
    try:
        return get_frontend_metrics(
            month=month,
            history_months=history_months,
            ensure_analysis=ensure_analysis,
            refresh_analysis=refresh_analysis,
            use_llm=use_llm,
            max_llm_metrics=max_llm_metrics,
            llm_time_budget_seconds=llm_time_budget_seconds,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/monthly-metrics/history")
def monthly_delete_history(month: str):
    try:
        result = delete_monthly_history(month=month)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    if result["deleted_month_records"] == 0 and result["deleted_analysis_records"] == 0:
        raise HTTPException(status_code=404, detail=f"No historical data found for month '{result['month_id']}'.")
    return result


@router.delete("/monthly-metrics/history/all")
def monthly_delete_all_history():
    return delete_all_monthly_history()
