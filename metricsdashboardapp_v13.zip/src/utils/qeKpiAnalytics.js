import { REQUIRED_SLA_COLUMNS, SLA_KPI_RULES } from "../data/qeKpiSlaConfig";

const round = (value, precision = 2) => {
  if (!Number.isFinite(value)) return 0;
  const factor = 10 ** precision;
  return Math.round(value * factor) / factor;
};

const ratio = (numerator, denominator) => (denominator > 0 ? (numerator / denominator) * 100 : 0);

const normalizeHeader = (value) =>
  String(value || "")
    .replace(/\u200b/g, "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");

const toNumber = (value) => {
  const parsed = Number(String(value ?? "").replace(/,/g, "").trim());
  return Number.isFinite(parsed) ? parsed : 0;
};

function parseCsvLine(line) {
  const values = [];
  let current = "";
  let quoted = false;

  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const next = line[index + 1];

    if (char === '"' && quoted && next === '"') {
      current += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      values.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }

  values.push(current.trim());
  return values;
}

export function parseSlaCsv(text) {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length < 2) {
    return { rows: [], errors: ["CSV must include a header row and at least one data row."] };
  }

  const headers = parseCsvLine(lines[0]).map(normalizeHeader);
  const missing = REQUIRED_SLA_COLUMNS.filter((column) => !headers.includes(column));
  if (missing.length) {
    return { rows: [], errors: [`Missing required columns: ${missing.join(", ")}`] };
  }

  const rows = lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    return headers.reduce((row, header, index) => {
      row[header] = values[index] ?? "";
      return row;
    }, {});
  });

  return { rows, errors: [] };
}

function statusFor(id, value, row) {
  if (id === "dre") return value >= 98 ? "Green" : value >= 95 ? "Amber" : "Red";
  if (id === "criticalLeakage") {
    if (row.sev1 > 0) return "Red";
    if (row.sev2 > 2) return "Amber";
    return "Green";
  }
  if (id === "regressionCycleTime" || id === "testExecutionAdherence") {
    return value >= 100 ? "Green" : value >= 98 ? "Amber" : "Red";
  }
  if (id === "uatRejectionRate") return value < 5 ? "Green" : value <= 10 ? "Amber" : "Red";
  if (id === "defectReopenRate") return value <= 5 ? "Green" : "Red";
  if (id === "automationStability") return value >= 95 ? "Green" : value >= 90 ? "Amber" : "Red";
  return "Red";
}

function achievementFor(id, value, status, row) {
  if (status === "Green") return 100;
  if (status === "Amber") return 92;
  if (id === "criticalLeakage") return row.sev1 > 0 ? 0 : 75;
  if (id === "uatRejectionRate") return Math.max(0, 90 - Math.max(0, value - 10) * 8);
  if (id === "defectReopenRate") return Math.max(0, 90 - Math.max(0, value - 5) * 10);
  if (id === "automationStability") return Math.max(0, Math.min(89, value));
  return Math.max(0, Math.min(89, value));
}

function normalizeRow(row) {
  const normalized = { month: row.month || "Unknown" };
  REQUIRED_SLA_COLUMNS.filter((column) => column !== "month").forEach((column) => {
    normalized[column] = toNumber(row[column]);
  });
  normalized.blocked_due_to_environment = toNumber(row.blocked_due_to_environment);
  normalized.blocked_due_to_test_data = toNumber(row.blocked_due_to_test_data);
  normalized.false_negatives = toNumber(row.false_negatives);
  return normalized;
}

function calculateMonthly(row) {
  const denominator = row.sit_defects + row.uat_defects + row.prod_defects;
  const adjustedPlanned = Math.max(
    row.planned_tests - row.blocked_due_to_environment - row.blocked_due_to_test_data,
    0,
  );
  const adjustedRuns = Math.max(row.total_runs - row.false_negatives, 0);

  const values = {
    dre: ratio(row.sit_defects + row.uat_defects, denominator),
    criticalLeakage: row.sev1 + row.sev2,
    regressionCycleTime: ratio(row.regression_cycles_completed, row.total_regression_cycles),
    testExecutionAdherence: ratio(row.executed_tests, adjustedPlanned),
    uatRejectionRate: ratio(row.uat_missed_defects, row.total_uat_defects),
    defectReopenRate: ratio(row.reopened_defects, row.closed_defects),
    automationStability: ratio(row.successful_runs, adjustedRuns),
  };

  const kpis = SLA_KPI_RULES.map((rule) => {
    const value = round(values[rule.id]);
    const status = statusFor(rule.id, value, row);
    const achievement = round(achievementFor(rule.id, value, status, row));
    return {
      ...rule,
      value,
      displayValue: `${value}${rule.unit}`,
      status,
      risk: status === "Red" ? "High" : status === "Amber" ? "Medium" : "Low",
      achievement,
      weightedContribution: round((achievement * rule.weightage) / 100),
    };
  });

  const score = round(kpis.reduce((sum, kpi) => sum + kpi.weightedContribution, 0));
  const status = score >= 95 ? "Green" : score >= 90 ? "Amber" : "Red";
  const creditRisk = score >= 95 ? 0 : round((95 - score) * (score >= 90 ? 0.5 : 1.25));

  return {
    ...row,
    kpis,
    score,
    status,
    failedKpis: kpis.filter((kpi) => kpi.status === "Red").length,
    warningKpis: kpis.filter((kpi) => kpi.status === "Amber").length,
    criticalKpis: kpis.filter((kpi) => kpi.status === "Red" && kpi.weightage >= 20).length,
    serviceCreditRisk: creditRisk,
  };
}

function trendDirection(months) {
  if (months.length < 2) return "Stable";
  const current = months[months.length - 1].score;
  const previous = months[months.length - 2].score;
  if (current > previous) return "Improving";
  if (current < previous) return "Declining";
  return "Stable";
}

function buildObservations(latest, previous) {
  const observations = [];
  const red = latest.kpis.filter((kpi) => kpi.status === "Red");
  const amber = latest.kpis.filter((kpi) => kpi.status === "Amber");

  observations.push(`Overall SLA score is ${latest.score}% with ${latest.failedKpis} failed KPI(s).`);
  if (latest.sev1 > 0) observations.push("Critical defect leakage requires immediate release governance review because Sev1 leakage is present.");
  if (latest.sev2 > 2) observations.push("Sev2 leakage is above tolerance; strengthen production-readiness gates and defect triage.");
  if (latest.automationStability < 95) observations.push("Automation stability is below SLA; review flaky scripts, timeouts, false negatives, and environment instability.");
  if (latest.uatRejectionRate > 10) observations.push("UAT rejection is critical; missed SIT coverage and acceptance criteria should be re-baselined.");
  if (previous && latest.score < previous.score) observations.push(`SLA score declined by ${round(previous.score - latest.score)} points compared with ${previous.month}.`);
  if (!red.length && !amber.length) observations.push("All KPI rules are currently inside healthy operating thresholds.");

  return observations.slice(0, 6);
}

export function buildSlaDashboard(rawRows) {
  const months = rawRows.map(normalizeRow).map(calculateMonthly);
  const latest = months[months.length - 1];
  const previous = months[months.length - 2] || null;
  const trend = trendDirection(months);

  const latestKpis = latest.kpis.map((kpi) => ({
    ...kpi,
    trend: months.map((month) => ({
      month: month.month,
      value: month.kpis.find((item) => item.id === kpi.id)?.value || 0,
    })),
    delta: previous ? round(kpi.value - (previous.kpis.find((item) => item.id === kpi.id)?.value || 0)) : 0,
  }));

  return {
    months,
    latest: { ...latest, kpis: latestKpis },
    trend,
    observations: buildObservations(latest, previous),
    severityDistribution: [
      { label: "Sev1", value: latest.sev1 },
      { label: "Sev2", value: latest.sev2 },
      { label: "SIT", value: latest.sit_defects },
      { label: "UAT", value: latest.uat_defects },
    ],
    defectStatus: [
      { label: "Closed", value: latest.closed_defects },
      { label: "Reopened", value: latest.reopened_defects },
      { label: "Production", value: latest.prod_defects },
    ],
    moduleRisk: latest.kpis.map((kpi) => ({
      label: kpi.shortName,
      name: kpi.name,
      value: kpi.status === "Red" ? 35 : kpi.status === "Amber" ? 70 : 100,
      status: kpi.status,
      actual: kpi.displayValue,
      target: kpi.targetLabel,
      weightage: kpi.weightage,
      message: kpi.status === "Red" ? "SLA breached" : kpi.status === "Amber" ? "Needs attention" : "On track",
    })),
  };
}

export function toCsv(rows) {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  return [
    headers.join(","),
    ...rows.map((row) => headers.map((header) => JSON.stringify(row[header] ?? "")).join(",")),
  ].join("\n");
}

export function downloadText(filename, text, type = "text/plain") {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function buildReportRows(dashboard) {
  return dashboard.latest.kpis.map((kpi) => ({
    Month: dashboard.latest.month,
    KPI: kpi.name,
    Value: kpi.displayValue,
    Target: kpi.targetLabel,
    Status: kpi.status,
    Risk: kpi.risk,
    Weightage: `${kpi.weightage}%`,
    Achievement: `${kpi.achievement}%`,
    Contribution: kpi.weightedContribution,
  }));
}

export function buildExcelHtml(dashboard) {
  const rows = buildReportRows(dashboard);
  const header = Object.keys(rows[0] || {});
  return `<table><thead><tr>${header.map((item) => `<th>${item}</th>`).join("")}</tr></thead><tbody>${rows
    .map((row) => `<tr>${header.map((item) => `<td>${row[item]}</td>`).join("")}</tr>`)
    .join("")}</tbody></table>`;
}
