import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { MonthProvider } from "./context/MonthContext";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import HomePage from "./pages/HomePage";
import KPIDetailsPage from "./pages/KPIDetailsPage";
import TrendAnalysisPage from "./pages/TrendAnalysisPage";
import ChatAssistantPage from "./pages/ChatAssistantPage";
import SlaDashboard from "./pages/SlaDashboard";
import AdminLoginPage from "./pages/AdminLoginPage";
import TokenUsagePage from "./pages/TokenUsagePage";

function App() {
  return (
    <div className="font-montserrat">
      <AuthProvider>
        <MonthProvider>
          <Router>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/assistant" element={<ChatAssistantPage />} />
              <Route path="/admin-login" element={<AdminLoginPage />} />
              <Route
                path="/sla-dashboard"
                element={
                  <ProtectedRoute>
                    <SlaDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/qe-kpi-dashboard"
                element={
                  <ProtectedRoute>
                    <SlaDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/qe-quality-metrics"
                element={
                  <ProtectedRoute>
                    <SlaDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/token-usage"
                element={
                  <ProtectedRoute>
                    <TokenUsagePage />
                  </ProtectedRoute>
                }
              />
              <Route path="/kpi/:kpiName" element={<KPIDetailsPage />} />
              <Route
                path="/trendanalysis/:kpiName"
                element={<TrendAnalysisPage />}
              />
            </Routes>
          </Router>
        </MonthProvider>
      </AuthProvider>
    </div>
  );
}

export default App;
