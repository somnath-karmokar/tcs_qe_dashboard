import React, { createContext, useContext, useState } from "react";

const AuthContext = createContext(null);

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [isAdmin, setIsAdmin] = useState(
    () => localStorage.getItem("sla_admin") === "true",
  );

  function login() {
    localStorage.setItem("sla_admin", "true");
    setIsAdmin(true);
  }

  function logout() {
    localStorage.removeItem("sla_admin");
    setIsAdmin(false);
  }

  return (
    <AuthContext.Provider value={{ isAdmin, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
