const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000/api";

async function handleResponse(response) {
  if (!response.ok) {
    let detail = `Request failed (${response.status})`;
    try {
      const parsed = await response.json();
      if (parsed?.detail) detail = parsed.detail;
    } catch {
      // keep default detail
    }
    throw new Error(detail);
  }
  return response.json();
}

export async function fetchSlaDashboardRows() {
  const response = await fetch(`${API_BASE_URL}/sla-dashboard/data`);
  const payload = await handleResponse(response);
  return Array.isArray(payload?.rows) ? payload.rows : [];
}
