import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ShieldCheck, Eye, EyeOff, Lock, User } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { loginAdmin } from "../services/authApi";

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!username.trim() || !password.trim()) {
      setError("Username and password are required.");
      return;
    }
    setLoading(true);
    try {
      const result = await loginAdmin(username.trim(), password.trim());
      if (result?.success && result?.role === "admin") {
        login();
        navigate("/sla-dashboard", { replace: true });
      } else {
        setError("Invalid admin credentials. Please try again.");
      }
    } catch (err) {
      setError(err.message || "Login failed. Ensure the backend is running.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-slate-900 font-inter text-slate-100 flex items-center justify-center">
      {/* Background glows */}
      <div className="absolute top-[-10%] right-[-5%] h-[600px] w-[600px] rounded-full bg-fuchsia-600/20 blur-[120px] pointer-events-none" />
      <div className="absolute top-[40%] left-[-10%] h-[500px] w-[500px] rounded-full bg-cyan-500/20 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[20%] h-[400px] w-[400px] rounded-full bg-emerald-500/10 blur-[100px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-md px-4">
        <div className="rounded-3xl border border-slate-700/50 bg-slate-800/70 p-8 shadow-2xl backdrop-blur-md">
          {/* Top gradient stripe */}
          <div className="absolute inset-x-0 top-0 h-1.5 rounded-t-3xl bg-gradient-to-r from-cyan-500 via-emerald-500 to-amber-500" />

          {/* Icon + heading */}
          <div className="flex flex-col items-center gap-3 mb-8">
            <div className="rounded-2xl border border-emerald-400/30 bg-emerald-500/15 p-4 text-emerald-300">
              <ShieldCheck size={36} />
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight">Admin Login</h1>
            <p className="text-sm font-semibold text-slate-400 text-center">
              Sign in to access the SLA Dashboard
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Username */}
            <div>
              <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">
                Username
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-3 flex items-center text-slate-500">
                  <User size={16} />
                </span>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  autoComplete="username"
                  className="w-full rounded-xl border border-slate-700 bg-slate-900/70 py-3 pl-9 pr-4 text-sm font-semibold text-slate-100 placeholder-slate-600 outline-none focus:border-cyan-400/60 focus:ring-1 focus:ring-cyan-400/30"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">
                Password
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-3 flex items-center text-slate-500">
                  <Lock size={16} />
                </span>
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="w-full rounded-xl border border-slate-700 bg-slate-900/70 py-3 pl-9 pr-11 text-sm font-semibold text-slate-100 placeholder-slate-600 outline-none focus:border-cyan-400/60 focus:ring-1 focus:ring-cyan-400/30"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute inset-y-0 right-3 flex items-center text-slate-500 hover:text-slate-300"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="rounded-xl border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-300">
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-gradient-to-r from-cyan-600 to-emerald-600 py-3 text-sm font-black text-white shadow-lg shadow-cyan-600/20 hover:from-cyan-700 hover:to-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {loading ? "Signing in…" : "Sign in as Admin"}
            </button>
          </form>

          {/* Back link */}
          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => navigate("/")}
              className="text-sm font-semibold text-slate-400 hover:text-cyan-300 transition-colors"
            >
              ← Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
