import React, { useState, useRef, useEffect } from "react";
import { Send, User, Bot, Sparkles, Loader2, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";

export default function ChatAssistantPage() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hello! I am your Primark metrics AI assistant. Ask me any questions regarding the KPIs, dimensions, or trends across the dashboard.",
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userMsg = inputValue.trim();
    setInputValue("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setIsLoading(true);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/copilot/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: userMsg }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch response from assistant");
      }

      const data = await response.json();
      
      // Assuming data is either a string or an object with an answer/response key.
      const botResponse = typeof data === "string" ? data : data.answer || data.response || JSON.stringify(data);

      setMessages((prev) => [...prev, { role: "assistant", content: botResponse }]);
    } catch (error) {
      console.error(error);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "I'm sorry, I encountered an error while trying to process your request." },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white font-montserrat flex flex-col relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-fuchsia-600/20 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-600/20 blur-[120px] rounded-full pointer-events-none" />

      <Header />

      <main className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 z-10 w-full max-w-5xl mx-auto h-[calc(100vh-160px)]">
        <div className="w-full flex items-center mb-6">
          <button
            onClick={() => navigate(-1)}
            className="p-3 bg-slate-800/80 rounded-xl text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700 shadow-xl"
            title="Go Back"
          >
            <ArrowLeft size={24} />
          </button>
          <div className="ml-4 flex items-center space-x-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
              <Sparkles size={24} className="text-white" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight drop-shadow-md">
              AI Data Assistant
            </h1>
          </div>
        </div>

        <div className="flex-1 w-full bg-slate-800/60 backdrop-blur-md border border-slate-700 rounded-2xl shadow-2xl flex flex-col overflow-hidden relative">
          
          <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`flex ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`flex max-w-[85%] sm:max-w-[75%] gap-4 ${
                    msg.role === "user" ? "flex-row-reverse" : "flex-row"
                  }`}
                >
                  <div className="flex-shrink-0 mt-1">
                    {msg.role === "user" ? (
                      <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center border border-slate-600 shadow-inner">
                        <User size={20} className="text-slate-300" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-md">
                        <Bot size={20} className="text-white" />
                      </div>
                    )}
                  </div>
                  
                  <div
                    className={`p-4 rounded-2xl shadow-inner text-base leading-relaxed ${
                      msg.role === "user"
                        ? "bg-cyan-600/20 border border-cyan-500/30 text-white rounded-tr-sm"
                        : "bg-slate-900/80 border border-slate-700 text-slate-100 rounded-tl-sm"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="flex gap-4 flex-row">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-md animate-pulse">
                      <Bot size={20} className="text-white" />
                    </div>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700 text-slate-300 rounded-tl-sm flex items-center space-x-2">
                    <div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" />
                    <div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" style={{ animationDelay: "0.2s" }} />
                    <div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" style={{ animationDelay: "0.4s" }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 bg-slate-900/80 border-t border-slate-700 backdrop-blur-md">
            <form onSubmit={handleSubmit} className="relative flex items-center max-w-4xl mx-auto">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about your metrics..."
                className="w-full bg-slate-800 text-white border border-slate-600 rounded-full py-4 pl-6 pr-14 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all shadow-inner text-base"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isLoading}
                className="absolute right-2 p-3 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white rounded-full hover:shadow-[0_0_15px_rgba(6,182,212,0.6)] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {isLoading ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
              </button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
