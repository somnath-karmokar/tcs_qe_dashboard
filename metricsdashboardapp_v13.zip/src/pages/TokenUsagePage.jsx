import React, { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  BarChart3,
  Bot,
  CircleDollarSign,
  RefreshCw,
  Trash2,
  Zap,
} from "lucide-react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { fetchTokenUsageSummary, clearTokenUsageLog } from "../services/tokenUsageApi";

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const FEATURE_COLORS = {
  metric_analysis: "#06b6d4",
  copilot: "#a855f7",
  kpi_analysis: "#10b981",
  admin_analysis: "#f59e0b",
  general: "#64748b",
};

function featureColor(feature) {
  return FEATURE_COLORS[feature] || "#6366f1";
}

const chartOpts = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    tooltip: { backgroundColor: "#0f172a", borderColor: "#334155", borderWidth: 1 },
  },
  scales: {
    x: { grid: { color: "rgba(148,163,184,0.12)" }, ticks: { color: "#cbd5e1" } },
    y: { grid: { color: "rgba(148,163,184,0.12)" }, ticks: { color: "#cbd5e1" }, beginAtZero: true },
  },
};

function SummaryCard({ label, value, sub, icon: Icon, color = "cyan" }) {
  const colorMap = {
    cyan: { ring: "border-cyan-500/40", text: "text-cyan-300", bg: "bg-cyan-500/10", rail: "from-cyan-500 to-sky-500" },
    purple: { ring: "border-purple-500/40", text: "text-purple-300", bg: "bg-purple-500/10", rail: "from-purple-500 to-indigo-500" },
    emerald: { ring: "border-emerald-500/40", text: "text-emerald-300", bg: "bg-emerald-500/10", rail: "from-emerald-500 to-teal-500" },
    amber: { ring: "border-amber-500/40", text: "text-amber-300", bg: "bg-amber-500/10", rail: "from-amber-500 to-orange-500" },
  };
  const c = colorMap[color] || colorMap.cyan;
  return (
    <div className={`relative overflow-hidden rounded-2xl border ${c.ring} bg-slate-800/70 p-5 shadow-xl backdrop-blur-md`}>
      <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${c.rail}`} />
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-widest text-slate-400">{label}</p>
          <p className={`mt-3 text-3xl font-black leading-none ${c.text}`}>{value}</p>
          {sub && <p className="mt-2 text-xs font-semibold text-slate-400">{sub}</p>}
        </div>
        <div className={`${c.bg} ${c.text} rounded-xl p-3`}>
          <Icon size={20} />
        </div>
      </div>
    </div>
  );
}

function Panel({ title, icon: Icon, children, className = "" }) {
  return (
    <section className={`rounded-2xl border border-slate-700/50 bg-slate-800/55 p-5 shadow-xl backdrop-blur-md ${className}`}>
      <div className="mb-4 flex items-center gap-3">
        <div className="rounded-xl border border-cyan-400/25 bg-cyan-500/10 p-2 text-cyan-300">
          <Icon size={18} />
        </div>
        <h2 className="text-lg font-black text-white">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function fmt(n) {
  if (n == null) return "—";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function fmtCost(v) {
  if (v == null) return "—";
  if (v === 0) return "$0.000000";
  if (v < 0.000001) return "<$0.000001";
  return `$${v.toFixed(6)}`;
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-20 text-center">
      <div className="rounded-2xl border border-slate-700 bg-slate-800/60 p-6 text-slate-500">
        <Bot size={48} />
      </div>
      <p className="text-lg font-black text-slate-300">No token usage recorded yet</p>
      <p className="max-w-sm text-sm font-semibold text-slate-500">
        Token usage is tracked automatically every time the AI Copilot, Monthly Analysis, or KPI Analysis
        features call the OpenAI API. Use those features and come back here to see the stats.
      </p>
    </div>
  );
}

export default function TokenUsagePage() {
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [clearing, setClearing] = useState(false);
  const [clearMsg, setClearMsg] = useState("");

  const load = useCallback(() => {
    setLoading(true);
    setError("");
    fetchTokenUsageSummary()
      .then((result) => {
        setData(result);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message || "Failed to load token usage.");
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleClear() {
    if (!window.confirm("Clear all token usage logs? This cannot be undone.")) return;
    setClearing(true);
    try {
      const result = await clearTokenUsageLog();
      setClearMsg(`Cleared ${result.deleted_records ?? 0} record(s).`);
      setData(null);
      load();
    } catch (err) {
      setClearMsg(`Failed to clear: ${err.message}`);
    } finally {
      setClearing(false);
      setTimeout(() => setClearMsg(""), 4000);
    }
  }

  const daily = data?.daily ?? [];
  const byFeature = data?.by_feature ?? [];

  const dailyChart = {
    labels: daily.map((d) => d.date),
    datasets: [
      {
        label: "Total Tokens",
        data: daily.map((d) => d.total_tokens),
        backgroundColor: daily.map(() => "#06b6d480"),
        borderRadius: 6,
      },
    ],
  };

  const featureChart = {
    labels: byFeature.map((f) => f.label),
    datasets: [
      {
        label: "Total Tokens",
        data: byFeature.map((f) => f.total_tokens),
        backgroundColor: byFeature.map((f) => featureColor(f.feature) + "cc"),
        borderRadius: 6,
      },
    ],
  };

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-slate-900 font-inter text-slate-100">
      <div className="absolute top-[-10%] right-[-5%] h-[600px] w-[600px] rounded-full bg-fuchsia-600/20 blur-[120px] pointer-events-none" />
      <div className="absolute top-[40%] left-[-10%] h-[500px] w-[500px] rounded-full bg-cyan-500/20 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[20%] h-[400px] w-[400px] rounded-full bg-emerald-500/10 blur-[100px] pointer-events-none" />

      <Header />

      <main className="relative z-10 mx-auto flex w-full max-w-[1500px] flex-1 flex-col gap-6 px-4 pb-10">
        {/* Hero */}
        <section className="relative overflow-hidden rounded-2xl border border-slate-700/50 bg-slate-800/55 shadow-xl backdrop-blur-md">
          <div className="absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r from-purple-500 via-cyan-500 to-emerald-500" />

          <div className="px-5 py-4">
            {/* Row 1 — Back + action buttons */}
            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => navigate("/")}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/70 px-3 py-1.5 text-xs font-semibold text-slate-400 hover:border-slate-500 hover:text-white transition-all"
              >
                <ArrowLeft size={13} />
                Back
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={load}
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/70 px-3 py-1.5 text-xs font-bold text-slate-300 hover:border-cyan-400/60 hover:text-white disabled:opacity-50 transition-all"
                >
                  <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
                  Refresh
                </button>
                <button
                  type="button"
                  onClick={handleClear}
                  disabled={clearing}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-red-700/50 bg-red-900/20 px-3 py-1.5 text-xs font-bold text-red-300 hover:border-red-400/60 hover:text-red-200 disabled:opacity-50 transition-all"
                >
                  <Trash2 size={13} />
                  Clear Logs
                </button>
              </div>
            </div>

            {/* Row 2 — Title */}
            <div className="mt-3">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-purple-300">Admin Only</p>
              <h1 className="mt-0.5 text-2xl font-black tracking-tight text-white md:text-3xl">Token Usage</h1>
              <p className="mt-1 max-w-2xl text-xs font-medium leading-relaxed text-slate-400">
                Consolidated OpenAI API token consumption across all AI features — Copilot, Monthly Metric Analysis, KPI Analysis, and Admin Analysis.
              </p>
            </div>

            {/* Row 3 — meta chips */}
            <div className="mt-2.5 flex flex-wrap items-center gap-2">
              {data?.generated_at && (
                <span className="inline-flex items-center rounded-md border border-purple-400/25 bg-purple-500/10 px-2.5 py-1 text-[11px] font-bold text-purple-200">
                  Refreshed: {new Date(data.generated_at).toLocaleString()}
                </span>
              )}
              {data?.has_data && (
                <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-bold text-emerald-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  {data.total_calls} calls · {data.total_tokens?.toLocaleString()} tokens
                </span>
              )}
              {clearMsg && (
                <span className="text-[11px] font-semibold text-amber-300">{clearMsg}</span>
              )}
            </div>
          </div>
        </section>

        {/* Error */}
        {error && (
          <div className="rounded-2xl border border-red-400/30 bg-red-500/10 px-5 py-4 text-sm font-semibold text-red-300">
            {error}
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div className="flex items-center justify-center py-20">
            <RefreshCw size={32} className="animate-spin text-cyan-400" />
          </div>
        )}

        {/* No data */}
        {!loading && !error && data && !data.has_data && <EmptyState />}

        {/* Data */}
        {!loading && !error && data && data.has_data && (
          <>
            {/* Summary cards */}
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              <SummaryCard
                label="Total API Calls"
                value={fmt(data.total_calls)}
                sub="All AI features"
                icon={Zap}
                color="cyan"
              />
              <SummaryCard
                label="Total Tokens"
                value={fmt(data.total_tokens)}
                sub={`${fmt(data.total_prompt_tokens)} prompt + ${fmt(data.total_completion_tokens)} completion`}
                icon={BarChart3}
                color="purple"
              />
              <SummaryCard
                label="Prompt Tokens"
                value={fmt(data.total_prompt_tokens)}
                sub="Input to the model"
                icon={Bot}
                color="emerald"
              />
              <SummaryCard
                label="Est. Cost (USD)"
                value={fmtCost(data.total_estimated_cost_usd)}
                sub="Based on public pricing"
                icon={CircleDollarSign}
                color="amber"
              />
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
              <Panel title="Daily Token Consumption" icon={BarChart3}>
                {daily.length === 0 ? (
                  <p className="text-sm text-slate-500">No daily data available.</p>
                ) : (
                  <div className="h-[260px]">
                    <Bar data={dailyChart} options={chartOpts} />
                  </div>
                )}
              </Panel>
              <Panel title="Tokens by Feature" icon={Bot}>
                {byFeature.length === 0 ? (
                  <p className="text-sm text-slate-500">No feature data available.</p>
                ) : (
                  <div className="h-[260px]">
                    <Bar data={featureChart} options={chartOpts} />
                  </div>
                )}
              </Panel>
            </div>

            {/* Feature breakdown table */}
            <Panel title="Feature Breakdown" icon={BarChart3}>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[700px] text-left text-sm">
                  <thead className="border-b border-slate-700 bg-slate-900/70 text-slate-300">
                    <tr>
                      <th className="px-3 py-3 font-black">Feature</th>
                      <th className="px-3 py-3 font-black">API Calls</th>
                      <th className="px-3 py-3 font-black">Prompt Tokens</th>
                      <th className="px-3 py-3 font-black">Completion Tokens</th>
                      <th className="px-3 py-3 font-black">Total Tokens</th>
                      <th className="px-3 py-3 font-black">Est. Cost (USD)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {byFeature.map((row) => (
                      <tr key={row.feature} className="border-b border-slate-800">
                        <td className="px-3 py-3">
                          <span
                            className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-black"
                            style={{ background: featureColor(row.feature) + "22", color: featureColor(row.feature) }}
                          >
                            {row.label}
                          </span>
                        </td>
                        <td className="px-3 py-3 font-bold text-slate-300">{fmt(row.calls)}</td>
                        <td className="px-3 py-3 font-bold text-slate-300">{fmt(row.prompt_tokens)}</td>
                        <td className="px-3 py-3 font-bold text-slate-300">{fmt(row.completion_tokens)}</td>
                        <td className="px-3 py-3 font-black text-cyan-300">{fmt(row.total_tokens)}</td>
                        <td className="px-3 py-3 font-bold text-amber-300">{fmtCost(row.estimated_cost_usd)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="border-t-2 border-slate-600 bg-slate-900/50">
                    <tr>
                      <td className="px-3 py-3 font-black text-white">Total</td>
                      <td className="px-3 py-3 font-black text-white">{fmt(data.total_calls)}</td>
                      <td className="px-3 py-3 font-black text-white">{fmt(data.total_prompt_tokens)}</td>
                      <td className="px-3 py-3 font-black text-white">{fmt(data.total_completion_tokens)}</td>
                      <td className="px-3 py-3 font-black text-cyan-300">{fmt(data.total_tokens)}</td>
                      <td className="px-3 py-3 font-black text-amber-300">{fmtCost(data.total_estimated_cost_usd)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </Panel>

            {/* Model breakdown */}
            {data.by_model.length > 0 && (
              <Panel title="Model Breakdown" icon={Bot}>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[600px] text-left text-sm">
                    <thead className="border-b border-slate-700 bg-slate-900/70 text-slate-300">
                      <tr>
                        <th className="px-3 py-3 font-black">Model</th>
                        <th className="px-3 py-3 font-black">API Calls</th>
                        <th className="px-3 py-3 font-black">Total Tokens</th>
                        <th className="px-3 py-3 font-black">Est. Cost (USD)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.by_model.map((row) => (
                        <tr key={row.model} className="border-b border-slate-800">
                          <td className="px-3 py-3 font-black text-indigo-300">{row.model}</td>
                          <td className="px-3 py-3 font-bold text-slate-300">{fmt(row.calls)}</td>
                          <td className="px-3 py-3 font-black text-cyan-300">{fmt(row.total_tokens)}</td>
                          <td className="px-3 py-3 font-bold text-amber-300">{fmtCost(row.estimated_cost_usd)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Panel>
            )}

            {/* Recent calls */}
            {data.recent_calls.length > 0 && (
              <Panel title="Recent API Calls (last 20)" icon={Zap}>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[800px] text-left text-sm">
                    <thead className="border-b border-slate-700 bg-slate-900/70 text-slate-300">
                      <tr>
                        <th className="px-3 py-3 font-black">Timestamp (UTC)</th>
                        <th className="px-3 py-3 font-black">Feature</th>
                        <th className="px-3 py-3 font-black">Model</th>
                        <th className="px-3 py-3 font-black">Prompt</th>
                        <th className="px-3 py-3 font-black">Completion</th>
                        <th className="px-3 py-3 font-black">Total</th>
                        <th className="px-3 py-3 font-black">Cost</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.recent_calls.map((row, i) => (
                        <tr key={i} className="border-b border-slate-800">
                          <td className="px-3 py-3 font-mono text-xs text-slate-400">{row.timestamp}</td>
                          <td className="px-3 py-3">
                            <span
                              className="inline-flex rounded-full px-2 py-0.5 text-xs font-black"
                              style={{ background: featureColor(row.feature) + "22", color: featureColor(row.feature) }}
                            >
                              {row.feature}
                            </span>
                          </td>
                          <td className="px-3 py-3 font-bold text-indigo-300">{row.model}</td>
                          <td className="px-3 py-3 font-bold text-slate-300">{fmt(row.prompt_tokens)}</td>
                          <td className="px-3 py-3 font-bold text-slate-300">{fmt(row.completion_tokens)}</td>
                          <td className="px-3 py-3 font-black text-cyan-300">{fmt(row.total_tokens)}</td>
                          <td className="px-3 py-3 font-bold text-amber-300">{fmtCost(row.estimated_cost_usd)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Panel>
            )}
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
