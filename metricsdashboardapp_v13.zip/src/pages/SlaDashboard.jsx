import React, { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowLeft,
  ArrowUpRight,
  BarChart3,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  Info,
  Minus,
  Printer,
  RefreshCw,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  XCircle,
} from "lucide-react";
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  CategoryScale,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
} from "chart.js";
import { Bar, Line } from "react-chartjs-2";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { SAMPLE_SLA_CSV, STATUS_STYLES } from "../data/qeKpiSlaConfig";
import {
  buildExcelHtml,
  buildReportRows,
  buildSlaDashboard,
  downloadText,
  parseSlaCsv,
  toCsv,
} from "../utils/qeKpiAnalytics";
import { fetchSlaDashboardRows } from "../services/slaDashboardApi";

ChartJS.register(
  ArcElement,
  BarElement,
  CategoryScale,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
);

// ─── Palette ───────────────────────────────────────────────────────────────
const C = {
  emerald: "#10b981",
  amber: "#f59e0b",
  red: "#ef4444",
  cyan: "#06b6d4",
  indigo: "#6366f1",
  sky: "#0ea5e9",
  slate: "#64748b",
  purple: "#a855f7",
};

// ─── Shared chart defaults ──────────────────────────────────────────────────
const baseChart = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: { mode: "index", intersect: false },
  plugins: {
    legend: {
      labels: { color: "#94a3b8", font: { size: 12, weight: "600" }, boxWidth: 12, padding: 16 },
    },
    tooltip: {
      backgroundColor: "#0f172a",
      borderColor: "#334155",
      borderWidth: 1,
      padding: 10,
      titleColor: "#e2e8f0",
      bodyColor: "#94a3b8",
    },
  },
  scales: {
    x: {
      grid: { color: "rgba(148,163,184,0.08)" },
      ticks: { color: "#64748b", font: { size: 11, weight: "600" } },
    },
    y: {
      grid: { color: "rgba(148,163,184,0.08)" },
      ticks: { color: "#64748b", font: { size: 11 } },
      beginAtZero: false,
    },
  },
};

// ─── Helpers ─────────────────────────────────────────────────────────────────
function tone(status) {
  return STATUS_STYLES[status] || STATUS_STYLES.Red;
}

function StatusBadge({ status, size = "sm" }) {
  const s = tone(status);
  const sz = size === "lg" ? "px-4 py-1.5 text-sm font-black" : "px-2.5 py-1 text-xs font-black";
  const dot = status === "Green" ? "bg-emerald-400" : status === "Amber" ? "bg-amber-400" : "bg-red-400";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border ${sz} ${s.bg} ${s.border} ${s.text}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
      {s.label}
    </span>
  );
}

function Delta({ value, inverse = false }) {
  if (value === 0 || value == null)
    return <span className="inline-flex items-center gap-0.5 text-xs font-bold text-slate-500"><Minus size={12} /> 0</span>;
  const positive = inverse ? value < 0 : value > 0;
  return (
    <span className={`inline-flex items-center gap-0.5 text-xs font-black ${positive ? "text-emerald-400" : "text-red-400"}`}>
      {positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
      {Math.abs(value).toFixed(1)}
    </span>
  );
}

// ─── Section wrapper ──────────────────────────────────────────────────────────
function Section({ title, subtitle, icon: Icon, children, className = "", action }) {
  return (
    <div className={`rounded-2xl border border-slate-700/50 bg-slate-800/40 backdrop-blur-sm overflow-hidden ${className}`}>
      <div className="flex items-center justify-between gap-3 border-b border-slate-700/40 bg-slate-900/30 px-5 py-3.5">
        <div className="flex items-center gap-2.5">
          <span className="flex items-center justify-center rounded-lg bg-slate-700/60 p-1.5 text-cyan-300">
            <Icon size={16} />
          </span>
          <div>
            <h2 className="text-sm font-black text-white tracking-tight">{title}</h2>
            {subtitle && <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
        </div>
        {action}
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

// ─── Executive summary card ──────────────────────────────────────────────────
function SummaryCard({ label, value, sub, delta, deltaInverse, status, icon: Icon }) {
  const s = tone(status);
  return (
    <div className={`relative overflow-hidden rounded-2xl border bg-slate-900/60 p-5 ${s.border}`}>
      <div className={`absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r ${s.rail}`} />
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] font-black uppercase tracking-[0.14em] text-slate-400">{label}</p>
        <span className={`rounded-lg p-1.5 ${s.bg} ${s.text}`}><Icon size={15} /></span>
      </div>
      <p className={`mt-3 text-3xl font-black leading-none ${s.text}`}>{value}</p>
      <div className="mt-2 flex items-center gap-2">
        <p className="text-xs font-semibold text-slate-400">{sub}</p>
        {delta != null && <Delta value={delta} inverse={deltaInverse} />}
      </div>
    </div>
  );
}

// ─── KPI detail card ──────────────────────────────────────────────────────────
function KpiCard({ kpi }) {
  const s = tone(kpi.status);
  return (
    <div className={`relative overflow-hidden rounded-xl border bg-slate-900/50 p-4 ${s.border}`}>
      <div className={`absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r ${s.rail}`} />
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-[11px] font-black uppercase tracking-[0.1em] text-slate-400">{kpi.shortName}</p>
          <p className="mt-0.5 text-[13px] font-black leading-snug text-white">{kpi.name}</p>
        </div>
        <StatusBadge status={kpi.status} />
      </div>
      <div className="mt-3 flex items-end justify-between gap-2">
        <p className={`text-2xl font-black leading-none ${s.text}`}>{kpi.displayValue}</p>
        <Delta value={kpi.delta} inverse={["uatRejectionRate", "defectReopenRate", "criticalLeakage"].includes(kpi.id)} />
      </div>
      {/* Progress bar — achievement */}
      <div className="mt-3">
        <div className="mb-1 flex justify-between text-[10px] font-bold text-slate-500">
          <span>Achievement</span><span>{kpi.achievement}%</span>
        </div>
        <div className="h-1.5 w-full rounded-full bg-slate-700/60">
          <div
            className={`h-1.5 rounded-full ${s.strongBg} transition-all duration-700`}
            style={{ width: `${Math.min(kpi.achievement, 100)}%` }}
          />
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-slate-500">
        <span>Target {kpi.targetLabel}</span>
        <span className={kpi.status !== "Green" ? "text-rose-400" : "text-slate-500"}>
          {kpi.weightage}% weight
        </span>
      </div>
    </div>
  );
}

// ─── Observation item ─────────────────────────────────────────────────────────
function Observation({ text, index }) {
  const isAlert = text.toLowerCase().includes("critical") || text.toLowerCase().includes("breach") || text.toLowerCase().includes("immediate");
  const isGood = text.toLowerCase().includes("healthy") || text.toLowerCase().includes("inside healthy");
  const Icon = isAlert ? AlertTriangle : isGood ? CheckCircle2 : Info;
  const color = isAlert ? "text-red-400 bg-red-500/10 border-red-500/25" : isGood ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/25" : "text-cyan-400 bg-cyan-500/10 border-cyan-500/25";
  return (
    <div className={`flex gap-3 rounded-xl border p-4 ${color}`}>
      <Icon size={16} className="mt-0.5 shrink-0" />
      <p className="text-sm font-semibold leading-relaxed text-slate-200">{text}</p>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function SlaDashboard() {
  const navigate = useNavigate();
  const [uploadedRows, setUploadedRows] = useState([]);
  const [dataSource, setDataSource] = useState("sample");
  const [loadMessage, setLoadMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    fetchSlaDashboardRows()
      .then((rows) => {
        if (!active) return;
        if (rows.length) {
          setUploadedRows(rows);
          setDataSource("uploaded");
          setLoadMessage("");
        } else {
          setDataSource("sample");
          setLoadMessage("No uploaded SLA data found. Showing sample data.");
        }
      })
      .catch((err) => {
        if (!active) return;
        setDataSource("sample");
        setLoadMessage(`Backend unavailable — showing sample data. ${err.message || ""}`.trim());
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const dashboard = useMemo(() => {
    if (uploadedRows.length) return buildSlaDashboard(uploadedRows);
    return buildSlaDashboard(parseSlaCsv(SAMPLE_SLA_CSV).rows);
  }, [uploadedRows]);

  const { latest, months, trend, observations } = dashboard;
  const labels = months.map((m) => m.month);

  // Chart datasets
  const slaLineData = {
    labels,
    datasets: [
      {
        label: "Overall SLA Score",
        data: months.map((m) => m.score),
        borderColor: C.cyan,
        backgroundColor: `${C.cyan}18`,
        fill: true,
        tension: 0.4,
        pointRadius: 5,
        pointHoverRadius: 7,
        borderWidth: 2.5,
        pointBackgroundColor: C.cyan,
      },
      {
        label: "DRE",
        data: months.map((m) => m.kpis.find((k) => k.id === "dre")?.value ?? 0),
        borderColor: C.emerald,
        backgroundColor: `${C.emerald}12`,
        fill: true,
        tension: 0.4,
        pointRadius: 4,
        pointHoverRadius: 6,
        borderWidth: 2,
        pointBackgroundColor: C.emerald,
      },
      {
        label: "Automation Stability",
        data: months.map((m) => m.kpis.find((k) => k.id === "automationStability")?.value ?? 0),
        borderColor: C.indigo,
        backgroundColor: `${C.indigo}12`,
        fill: true,
        tension: 0.4,
        pointRadius: 4,
        pointHoverRadius: 6,
        borderWidth: 2,
        pointBackgroundColor: C.indigo,
      },
    ],
  };

  const leakageBarData = {
    labels,
    datasets: [
      {
        label: "Sev1",
        data: months.map((m) => m.sev1),
        backgroundColor: `${C.red}cc`,
        borderRadius: 5,
        stack: "s",
      },
      {
        label: "Sev2",
        data: months.map((m) => m.sev2),
        backgroundColor: `${C.amber}cc`,
        borderRadius: 5,
        stack: "s",
      },
    ],
  };

  const kpiScoreBarData = {
    labels: latest.kpis.map((k) => k.shortName),
    datasets: [
      {
        label: "Achievement %",
        data: latest.kpis.map((k) => k.achievement),
        backgroundColor: latest.kpis.map((k) =>
          k.status === "Green" ? `${C.emerald}cc` : k.status === "Amber" ? `${C.amber}cc` : `${C.red}cc`,
        ),
        borderRadius: 6,
      },
    ],
  };

  const downloadCsv = () =>
    downloadText(`sla-report-${latest.month}.csv`, toCsv(buildReportRows(dashboard)), "text/csv");
  const downloadExcel = () =>
    downloadText(`sla-report-${latest.month}.xls`, buildExcelHtml(dashboard), "application/vnd.ms-excel");

  const sScore = tone(latest.status);

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-[#080f1e] text-slate-100">
      {/* Background glows */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 -right-32 h-[600px] w-[600px] rounded-full bg-cyan-600/10 blur-[120px]" />
        <div className="absolute top-1/2 -left-40 h-[500px] w-[500px] rounded-full bg-indigo-600/10 blur-[140px]" />
        <div className="absolute -bottom-20 right-1/4 h-[400px] w-[400px] rounded-full bg-emerald-600/8 blur-[100px]" />
      </div>

      <Header />

      <main className="relative z-10 mx-auto w-full max-w-[1600px] px-4 pb-12 space-y-5">

        {/* ── Hero ─────────────────────────────────────────────────────── */}
        <div className="relative overflow-hidden rounded-2xl border border-slate-700/50 bg-slate-900/60 backdrop-blur-sm">
          <div className="absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r from-cyan-500 via-sky-400 to-emerald-400" />

          <div className="px-5 py-4">
            {/* Row 1 — Back + Export */}
            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => navigate("/")}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-1.5 text-xs font-semibold text-slate-400 hover:border-slate-500 hover:text-white transition-all"
              >
                <ArrowLeft size={13} />
                Back
              </button>

              <div className="flex items-center gap-2">
                <button type="button" onClick={downloadCsv}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-1.5 text-xs font-bold text-slate-300 hover:border-slate-500 hover:text-white transition-all">
                  <FileText size={13} /> CSV
                </button>
                <button type="button" onClick={downloadExcel}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-1.5 text-xs font-bold text-slate-300 hover:border-slate-500 hover:text-white transition-all">
                  <FileSpreadsheet size={13} /> Excel
                </button>
                <button type="button" onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-cyan-600/50 bg-cyan-600/15 px-3 py-1.5 text-xs font-bold text-cyan-300 hover:bg-cyan-600/25 transition-all">
                  <Printer size={13} /> PDF
                </button>
              </div>
            </div>

            {/* Row 2 — Title + meta */}
            <div className="mt-3 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-cyan-400">
                  Enterprise SLA Governance
                </p>
                <h1 className="mt-0.5 text-2xl font-black tracking-tight text-white md:text-3xl">
                  SLA Dashboard
                </h1>
                <p className="mt-1 text-xs font-medium text-slate-400 max-w-xl leading-relaxed">
                  Quality Engineering KPI monitoring — defect leakage, regression adherence, automation stability, and service credit exposure.
                </p>
              </div>

              {/* Score + trend — right-aligned on sm+ */}
              <div className="mt-2 sm:mt-0 flex items-center gap-2 shrink-0">
                <div className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 ${sScore.border} ${sScore.bg}`}>
                  <ShieldCheck size={13} className={sScore.text} />
                  <span className={`text-xs font-black ${sScore.text}`}>{latest.score}%</span>
                  <StatusBadge status={latest.status} />
                </div>
                <div className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/50 px-3 py-1.5">
                  {trend === "Improving"
                    ? <TrendingUp size={13} className="text-emerald-400" />
                    : trend === "Declining"
                    ? <TrendingDown size={13} className="text-red-400" />
                    : <Minus size={13} className="text-slate-400" />}
                  <span className="text-xs font-bold text-slate-300">{trend}</span>
                </div>
              </div>
            </div>

            {/* Row 3 — status chips */}
            <div className="mt-2.5 flex flex-wrap items-center gap-2">
              <span className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-bold ${
                dataSource === "uploaded"
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                  : "border-amber-500/30 bg-amber-500/10 text-amber-300"
              }`}>
                <span className={`h-1.5 w-1.5 rounded-full ${dataSource === "uploaded" ? "bg-emerald-400" : "bg-amber-400"}`} />
                {dataSource === "uploaded" ? "Live data" : "Sample data"}
              </span>

              <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/60 bg-slate-800/40 px-2.5 py-1 text-[11px] font-bold text-slate-400">
                Period: {latest.month}
              </span>

              <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/60 bg-slate-800/40 px-2.5 py-1 text-[11px] font-bold text-slate-400">
                {latest.kpis.filter(k => k.status === "Green").length} Healthy &nbsp;·&nbsp;
                {latest.warningKpis} Warning &nbsp;·&nbsp;
                {latest.failedKpis} Breach
              </span>

              {loading && (
                <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-500">
                  <RefreshCw size={11} className="animate-spin" /> Loading…
                </span>
              )}
              {loadMessage && (
                <span className="text-[11px] font-semibold text-amber-300">{loadMessage}</span>
              )}
            </div>
          </div>
        </div>

        {/* ── Executive Summary ────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
          <SummaryCard
            label="Overall SLA Score"
            value={`${latest.score}%`}
            sub={`Period: ${latest.month}`}
            status={latest.status}
            icon={ShieldCheck}
          />
          <SummaryCard
            label="Service Credit Risk"
            value={`${latest.serviceCreditRisk}%`}
            sub="Potential exposure"
            status={latest.serviceCreditRisk > 0 ? latest.status : "Green"}
            icon={AlertTriangle}
          />
          <SummaryCard
            label="Failed KPIs"
            value={latest.failedKpis}
            sub={`${latest.warningKpis} KPI(s) in warning`}
            status={latest.failedKpis ? "Red" : latest.warningKpis ? "Amber" : "Green"}
            icon={XCircle}
          />
          <SummaryCard
            label="Critical Breaches"
            value={latest.criticalKpis}
            sub="High-weight KPIs failed"
            status={latest.criticalKpis ? "Red" : "Green"}
            icon={AlertTriangle}
          />
          <SummaryCard
            label="Trend Direction"
            value={trend}
            sub="vs previous period"
            status={trend === "Declining" ? "Amber" : "Green"}
            icon={trend === "Improving" ? TrendingUp : trend === "Declining" ? TrendingDown : CheckCircle2}
          />
        </div>

        {/* ── KPI Cards ────────────────────────────────────────────────── */}
        <div>
          <div className="mb-3 flex items-center gap-2.5">
            <span className="flex items-center justify-center rounded-lg bg-slate-700/60 p-1.5 text-cyan-300">
              <BarChart3 size={15} />
            </span>
            <div>
              <h2 className="text-sm font-black text-white">KPI Performance Summary</h2>
              <p className="text-[11px] font-semibold text-slate-500">Latest period — all 7 quality KPIs with achievement and trend delta</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
            {latest.kpis.map((kpi) => (
              <KpiCard key={kpi.id} kpi={kpi} />
            ))}
          </div>
        </div>

        {/* ── SLA Trend Chart ──────────────────────────────────────────── */}
        <Section
          title="SLA Score & KPI Trend"
          subtitle="Monthly trend — Overall SLA Score, DRE, and Automation Stability"
          icon={TrendingUp}
        >
          <div className="h-[300px] w-full">
            <Line
              data={slaLineData}
              options={{
                ...baseChart,
                scales: {
                  ...baseChart.scales,
                  y: { ...baseChart.scales.y, min: 70, max: 105 },
                },
              }}
            />
          </div>
        </Section>

        {/* ── Defect Leakage + KPI Achievement ────────────────────────── */}
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
          <Section
            title="Critical Defect Leakage"
            subtitle="Sev1 and Sev2 production leakage by month"
            icon={AlertTriangle}
          >
            <div className="h-[260px]">
              <Bar
                data={leakageBarData}
                options={{
                  ...baseChart,
                  scales: {
                    ...baseChart.scales,
                    x: { ...baseChart.scales.x, stacked: true },
                    y: { ...baseChart.scales.y, stacked: true, beginAtZero: true },
                  },
                  plugins: {
                    ...baseChart.plugins,
                    legend: { ...baseChart.plugins.legend, display: true },
                  },
                }}
              />
            </div>
          </Section>

          <Section
            title="KPI Achievement — Current Period"
            subtitle="Achievement percentage per KPI (colour-coded by status)"
            icon={BarChart3}
          >
            <div className="h-[260px]">
              <Bar
                data={kpiScoreBarData}
                options={{
                  ...baseChart,
                  scales: {
                    ...baseChart.scales,
                    y: { ...baseChart.scales.y, min: 0, max: 105, beginAtZero: true },
                  },
                  plugins: { ...baseChart.plugins, legend: { display: false } },
                }}
              />
            </div>
          </Section>
        </div>

        {/* ── KPI Grid Table + Root Cause ──────────────────────────────── */}
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">

          {/* Table */}
          <Section
            title="KPI Performance Grid"
            subtitle="Actual vs target with penalty exposure"
            icon={FileSpreadsheet}
            className="xl:col-span-2"
          >
            <div className="overflow-x-auto -mx-1">
              <table className="w-full min-w-[680px] text-left text-sm border-separate border-spacing-0">
                <thead>
                  <tr className="text-[11px] font-black uppercase tracking-widest text-slate-500">
                    <th className="pb-2.5 pr-3 pl-1">KPI</th>
                    <th className="pb-2.5 px-3 text-right">Actual</th>
                    <th className="pb-2.5 px-3">Target</th>
                    <th className="pb-2.5 px-3">Status</th>
                    <th className="pb-2.5 px-3 text-right">Weight</th>
                    <th className="pb-2.5 px-3 text-right">Penalty</th>
                    <th className="pb-2.5 pl-3 text-right">Achievement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/40">
                  {latest.kpis.map((kpi, i) => {
                    const s = tone(kpi.status);
                    const penalty = kpi.status === "Red" ? `${kpi.weightage}%` : kpi.status === "Amber" ? `${Math.round(kpi.weightage / 2)}%` : "—";
                    return (
                      <tr key={kpi.id} className={`transition-colors hover:bg-slate-800/40 ${i % 2 === 0 ? "" : "bg-slate-800/20"}`}>
                        <td className="py-3 pr-3 pl-1">
                          <p className="font-black text-white text-[13px]">{kpi.name}</p>
                          <p className="text-[11px] font-semibold text-slate-500">{kpi.shortName}</p>
                        </td>
                        <td className={`py-3 px-3 text-right font-black text-base ${s.text}`}>{kpi.displayValue}</td>
                        <td className="py-3 px-3 font-semibold text-slate-400 text-[13px]">{kpi.targetLabel}</td>
                        <td className="py-3 px-3"><StatusBadge status={kpi.status} /></td>
                        <td className="py-3 px-3 text-right font-bold text-slate-400 text-[13px]">{kpi.weightage}%</td>
                        <td className={`py-3 px-3 text-right font-bold text-[13px] ${kpi.status === "Red" ? "text-red-400" : kpi.status === "Amber" ? "text-amber-400" : "text-slate-600"}`}>
                          {penalty}
                        </td>
                        <td className="py-3 pl-3 text-right">
                          <div className="flex flex-col items-end gap-1">
                            <span className="text-[12px] font-black text-slate-300">{kpi.achievement}%</span>
                            <div className="h-1 w-16 rounded-full bg-slate-700/60">
                              <div className={`h-full rounded-full ${s.strongBg}`} style={{ width: `${kpi.achievement}%` }} />
                            </div>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-slate-600/60">
                    <td colSpan={4} className="pt-3 pl-1 text-xs font-black uppercase tracking-widest text-slate-500">Weighted SLA Score</td>
                    <td colSpan={3} className={`pt-3 text-right text-xl font-black ${sScore.text}`}>{latest.score}%</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </Section>

          {/* Root Cause */}
          <Section
            title="Root Cause Analysis"
            subtitle="Automated rule-engine observations"
            icon={Info}
          >
            <div className="space-y-2.5">
              {observations.map((obs, i) => (
                <Observation key={i} text={obs} index={i} />
              ))}
            </div>
          </Section>
        </div>

        {/* ── Service Credit Risk ─────────────────────────────────────── */}
        <Section
          title="Service Credit Risk Assessment"
          subtitle="Exposure based on failed KPI weights"
          icon={ShieldCheck}
        >
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <div className="rounded-xl border border-slate-700/60 bg-slate-900/50 p-5">
              <p className="text-[11px] font-black uppercase tracking-widest text-slate-500">Potential Credit</p>
              <p className={`mt-2 text-3xl font-black ${latest.serviceCreditRisk > 0 ? "text-red-400" : "text-emerald-400"}`}>
                {latest.serviceCreditRisk}%
              </p>
              <p className="mt-1 text-xs font-semibold text-slate-500">Service credit exposure</p>
            </div>
            <div className="rounded-xl border border-slate-700/60 bg-slate-900/50 p-5">
              <p className="text-[11px] font-black uppercase tracking-widest text-slate-500">Highest Impact KPI</p>
              <p className="mt-2 text-xl font-black text-white">
                {[...latest.kpis].sort((a, b) => b.weightage - a.weightage).find((k) => k.status !== "Green")?.shortName ?? "None"}
              </p>
              <p className="mt-1 text-xs font-semibold text-slate-500">Top breached by weight</p>
            </div>
            <div className="rounded-xl border border-slate-700/60 bg-slate-900/50 p-5">
              <p className="text-[11px] font-black uppercase tracking-widest text-slate-500">Release Health</p>
              <p className={`mt-2 text-xl font-black ${sScore.text}`}>{sScore.label}</p>
              <StatusBadge status={latest.status} />
            </div>
            <div className="rounded-xl border border-slate-700/60 bg-slate-900/50 p-5">
              <p className="text-[11px] font-black uppercase tracking-widest text-slate-500">KPI Breakdown</p>
              <div className="mt-2 flex gap-3">
                <div className="text-center">
                  <p className="text-xl font-black text-emerald-400">{latest.kpis.filter((k) => k.status === "Green").length}</p>
                  <p className="text-[10px] font-bold text-slate-500">Healthy</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-black text-amber-400">{latest.warningKpis}</p>
                  <p className="text-[10px] font-bold text-slate-500">Warning</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-black text-red-400">{latest.failedKpis}</p>
                  <p className="text-[10px] font-bold text-slate-500">Breach</p>
                </div>
              </div>
            </div>
          </div>
        </Section>

        {/* ── SLA Breach Heatmap ──────────────────────────────────────── */}
        <Section
          title="SLA Breach Heatmap"
          subtitle="Per-KPI health indicator across the current period"
          icon={BarChart3}
        >
          {/* Legend */}
          <div className="mb-5 flex flex-wrap gap-3">
            {[
              { label: "Healthy — meeting target", color: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" },
              { label: "Warning — near threshold", color: "border-amber-500/40 bg-amber-500/10 text-amber-300" },
              { label: "Breach — SLA failed", color: "border-red-500/40 bg-red-500/10 text-red-300" },
            ].map((item) => (
              <span key={item.label} className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1 text-xs font-bold ${item.color}`}>
                <span className="h-1.5 w-1.5 rounded-full bg-current" />
                {item.label}
              </span>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {dashboard.moduleRisk.map((item) => {
              const s = tone(item.status);
              const trackBg = item.status === "Red" ? "bg-red-950/60" : item.status === "Amber" ? "bg-amber-950/60" : "bg-emerald-950/60";
              return (
                <div
                  key={item.label}
                  className={`rounded-xl border p-4 ${s.border} ${
                    item.status === "Red"
                      ? "bg-red-500/8"
                      : item.status === "Amber"
                      ? "bg-amber-500/8"
                      : "bg-emerald-500/8"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className={`text-[11px] font-black uppercase tracking-widest ${s.text}`}>{item.label}</p>
                      <p className="mt-0.5 text-[13px] font-black leading-snug text-white">{item.name}</p>
                    </div>
                    <StatusBadge status={item.status} />
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <div className="rounded-lg border border-white/8 bg-slate-900/40 px-2.5 py-2">
                      <p className="text-[10px] font-black uppercase text-slate-500">Actual</p>
                      <p className={`mt-0.5 text-base font-black ${s.text}`}>{item.actual}</p>
                    </div>
                    <div className="rounded-lg border border-white/8 bg-slate-900/40 px-2.5 py-2">
                      <p className="text-[10px] font-black uppercase text-slate-500">Target</p>
                      <p className="mt-0.5 text-base font-black text-white">{item.target}</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="mb-1 flex items-center justify-between text-[10px] font-bold text-slate-500">
                      <span>{item.message}</span>
                      <span>{item.value}% health</span>
                    </div>
                    <div className={`h-2 w-full rounded-full ${trackBg} border border-white/5`}>
                      <div
                        className={`h-full rounded-full ${s.strongBg} transition-all duration-700`}
                        style={{ width: `${item.value}%` }}
                      />
                    </div>
                  </div>
                  <p className="mt-2 text-right text-[10px] font-bold text-slate-500">Weight {item.weightage}%</p>
                </div>
              );
            })}
          </div>
        </Section>

      </main>
      <Footer />
    </div>
  );
}
