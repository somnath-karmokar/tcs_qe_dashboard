import React from "react";
import { useLocation, useParams, Link } from "react-router-dom";
import kpiData from "../data/mockData.json";
import GaugeChart from "../components/GaugeChart";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { IoMdArrowRoundBack } from "react-icons/io";
import { parseThreshold } from "../utils/ThresholdParser";
import slugify from "slugify";

export default function KPIDetails() {
  const { kpiName } = useParams();
  const location = useLocation();
  const { kpi: passedKpi } = location.state || {};

  const kpi =
    passedKpi ||
    kpiData.find((k) => slugify(k.kpiname, { lower: true, strict: true }) === kpiName);

  if (!kpi) {
    return <div className="p-6 text-red-500">KPI not found</div>;
  }

  const lastSix = [...kpi.history].slice(-6).reverse();

  const lastSixValues = lastSix
    .map((r) => parseFloat(r.value))
    .filter((n) => Number.isFinite(n));

  const recommendationText = String(kpi.analysisRecommendation || "").trim();
  const recommendationInsight = Array.isArray(kpi.insights)
    ? kpi.insights.find((item) =>
        String(item?.title || "").toLowerCase().includes("recommend"),
      )
    : null;

  const recommendationDescription = String(recommendationInsight?.description || "").trim();
  const recommendationExample = String(recommendationInsight?.example || "").trim();
  const changeValue = Number.parseFloat(kpi.changeVsAvgPct);
  const isGenericRecommendation =
    recommendationText.toLowerCase() === "maintain current approach and monitor trend monthly.";

  const detailedRecommendationPoints = [];
  if (recommendationDescription) {
    detailedRecommendationPoints.push(recommendationDescription);
  }
  if (recommendationExample) {
    detailedRecommendationPoints.push(`Example: ${recommendationExample}`);
  }
  if (Number.isFinite(changeValue)) {
    if (changeValue <= -10) {
      detailedRecommendationPoints.push(
        `Metric is ${changeValue.toFixed(1)}% below 6-month average. Create a corrective sprint plan with a KPI owner and weekly checkpoints.`,
      );
    } else if (changeValue >= 5) {
      detailedRecommendationPoints.push(
        `Metric is ${changeValue.toFixed(1)}% above 6-month average. Scale current practices and document them for reuse across teams.`,
      );
    } else {
      detailedRecommendationPoints.push(
        `Metric variance is ${changeValue.toFixed(1)}% vs 6-month average. Continue monitoring with fortnightly review and trigger alerts for sudden drops.`,
      );
    }
  }

  const uniqueRecommendationPoints = [...new Set(detailedRecommendationPoints.filter(Boolean))];

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 relative overflow-x-hidden p-4">
      {/* Decorative dark background orbs */}
      <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-indigo-900/40 to-transparent pointer-events-none" />
      <div className="absolute top-[10%] right-[-5%] w-[300px] h-[300px] rounded-full bg-cyan-600/20 blur-[100px] pointer-events-none" />

      <div className="flex items-center gap-4 mb-6 z-10">
        <button
          onClick={() => window.history.back()}
          className="p-3 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 shadow-xl transition-all border border-slate-700"
        >
          <IoMdArrowRoundBack size={28} />
        </button>
        <h1 className="text-3xl font-bold text-white tracking-tight drop-shadow-md">
          {kpi.kpiname} <span className="text-cyan-400 font-medium ml-2">Details</span>
        </h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 z-10">
        {lastSix.map((record) => (
          <div key={record.id} className="h-72 bg-slate-800/60 backdrop-blur-md border border-slate-700/50 rounded-2xl p-2 shadow-xl hover:shadow-[0_8px_32px_0_rgba(0,0,0,0.3)] hover:-translate-y-1 transition-all duration-300">
            <GaugeChart
              title={record.period}
              value={record.value}
              status={record.status}
              threshold={parseThreshold(kpi.guidelines?.ideal)}
              historyValues={lastSixValues}
              monthDate={record.updated_at}
              trendLink={`/trendanalysis/${slugify(kpi.kpiname, {
                lower: true,
                strict: true,
              })}?month=${record.updated_at ? record.updated_at.slice(0, 7) : ""}`}
              kpiData={kpi}
            />
          </div>
        ))}
      </div>

      {(kpi.analysisSummary || kpi.analysisRecommendation || kpi.analysisTrend || kpi.analysisRisk) && (
        <div className="mt-8 bg-slate-800/80 backdrop-blur-md rounded-2xl p-6 z-10 border-t-4 border-t-cyan-500 shadow-2xl">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center space-x-3 drop-shadow-sm">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-sparkles"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
            </div>
            <span>AI Metric Analysis</span>
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-base mb-6">
            <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/50 shadow-inner">
              <p className="text-slate-400 font-medium mb-1">Trend</p>
              <p className="text-slate-100 font-bold">{kpi.analysisTrend || "NA"}</p>
            </div>
            <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/50 shadow-inner">
              <p className="text-slate-400 font-medium mb-1">Risk</p>
              <p className={`font-bold ${kpi.analysisRisk?.toLowerCase() === 'high' ? 'text-rose-400' : kpi.analysisRisk?.toLowerCase() === 'low' ? 'text-emerald-400' : 'text-amber-400'}`}>
                {kpi.analysisRisk || "NA"}
              </p>
            </div>
            <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/50 shadow-inner">
              <p className="text-slate-400 font-medium mb-1">Generated Metric</p>
              <p className="text-slate-100 font-bold">{kpi.generatedMetric ?? "NA"}</p>
            </div>
            <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/50 shadow-inner">
              <p className="text-slate-400 font-medium mb-1">Change vs Avg</p>
              <p className={`font-bold ${kpi.changeVsAvgPct > 0 ? 'text-emerald-400' : kpi.changeVsAvgPct < 0 ? 'text-rose-400' : 'text-slate-100'}`}>
                {kpi.changeVsAvgPct ?? "NA"}%
              </p>
            </div>
          </div>
          
          {kpi.analysisSummary && (
            <div className="mb-6">
              <h3 className="text-base font-bold text-white uppercase tracking-wider mb-2">Summary</h3>
              <p className="text-base text-slate-100 leading-relaxed bg-slate-900/50 p-5 rounded-xl border border-slate-700/50">
                {kpi.analysisSummary}
              </p>
            </div>
          )}
          
          {(kpi.analysisRecommendation || uniqueRecommendationPoints.length > 0) && (
            <div>
              <h3 className="text-base font-bold text-white uppercase tracking-wider mb-2">Recommendation</h3>
              <div className="text-base text-slate-100 leading-relaxed bg-brand-900/30 p-5 rounded-xl border border-brand-700/30">
                {uniqueRecommendationPoints.length > 0 ? (
                  <ul className="space-y-3">
                    {uniqueRecommendationPoints.map((point, idx) => (
                      <li key={`${idx}-${point}`} className="flex items-start space-x-3">
                        <span className="text-brand-400 mt-2 w-2 h-2 rounded-full bg-brand-400 shrink-0 shadow-[0_0_8px_rgba(129,140,248,0.8)]"></span>
                        <span className="font-medium text-slate-100">{point}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span>
                    {isGenericRecommendation
                      ? "Define specific owner-level actions with timeline and checkpoints for this metric."
                      : recommendationText}
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
