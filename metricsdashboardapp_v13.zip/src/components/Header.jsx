import React, { useState } from "react";
import logo from "../assets/primark-logo.webp";
import { useNavigate, useLocation } from "react-router-dom";
import {
  BotMessageSquare,
  ChevronLeft,
  ChevronRight,
  Coins,
  LogOut,
  Menu,
  ShieldCheck,
  X,
} from "lucide-react";
import { useMonth } from "../context/MonthContext";
import { useAuth } from "../context/AuthContext";

function NavBtn({ onClick, title, children, variant = "default", active = false }) {
  const base =
    "relative flex items-center justify-center rounded-xl border transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400";
  const variants = {
    default:
      "p-2.5 border-slate-700/60 bg-slate-800/60 text-slate-400 hover:border-slate-500 hover:bg-slate-700/70 hover:text-white",
    emerald:
      "p-2.5 border-emerald-500/30 bg-emerald-500/10 text-emerald-300 hover:border-emerald-400/60 hover:bg-emerald-500/20 hover:text-emerald-200 shadow-[0_0_14px_rgba(16,185,129,0.10)] hover:shadow-[0_0_20px_rgba(16,185,129,0.22)]",
    purple:
      "p-2.5 border-purple-500/30 bg-purple-500/10 text-purple-300 hover:border-purple-400/60 hover:bg-purple-500/20 hover:text-purple-200",
    cyan:
      "p-2.5 border-cyan-500/30 bg-cyan-500/10 text-cyan-300 hover:border-cyan-400/60 hover:bg-cyan-500/20 hover:text-cyan-200 shadow-[0_0_14px_rgba(6,182,212,0.12)] hover:shadow-[0_0_20px_rgba(6,182,212,0.28)]",
    red: "p-2.5 border-red-500/30 bg-red-500/10 text-red-300 hover:border-red-400/60 hover:bg-red-500/20 hover:text-red-200",
  };
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-label={title}
      className={`${base} ${variants[variant]} ${active ? "ring-1 ring-cyan-400/40" : ""}`}
    >
      {children}
    </button>
  );
}

export default function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const { selectedMonth, setSelectedMonth, months } = useMonth();
  const { isAdmin, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const currentIndex = months.indexOf(selectedMonth);
  const hasMonths = months.length > 0 && currentIndex >= 0;
  const isFirstMonth = !hasMonths || currentIndex === 0;
  const isLastMonth = !hasMonths || currentIndex === months.length - 1;

  function handlePrevious() {
    if (currentIndex < months.length - 1) setSelectedMonth(months[currentIndex + 1]);
  }
  function handleNext() {
    if (currentIndex > 0) setSelectedMonth(months[currentIndex - 1]);
  }
  function handleSlaClick() {
    navigate(isAdmin ? "/sla-dashboard" : "/admin-login");
    setMobileOpen(false);
  }
  function handleLogout() {
    logout();
    navigate("/");
    setMobileOpen(false);
  }

  const isOnSla = location.pathname === "/sla-dashboard";
  const isOnToken = location.pathname === "/token-usage";

  return (
    <header className="mx-2 mt-2 mb-4 rounded-2xl shadow-2xl overflow-hidden border border-slate-700/60 bg-slate-900/80 backdrop-blur-xl">
      {/* Top accent gradient */}
      <div className="h-[3px] bg-gradient-to-r from-sky-500 via-cyan-400 to-emerald-400" />

      <div className="flex items-center justify-between gap-3 px-4 md:px-6 py-3">

        {/* ── LEFT: Logo + Brand ── */}
        <button
          type="button"
          onClick={() => { navigate("/"); setMobileOpen(false); }}
          className="flex items-center gap-3 group shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-xl"
          aria-label="Go to home"
        >
          {/* Logo on white card so the blue circle and white text show properly */}
          <img
            src={logo}
            alt="Primark"
            className="w-20 h-20 shrink-0 object-contain drop-shadow-md group-hover:drop-shadow-lg transition-all duration-300"
          />

          {/* Brand text — hide on mobile, show from sm+ */}
          <div className="hidden sm:block text-left leading-none">
            <p className="text-[19px] font-black text-white tracking-tight leading-snug">
              Primark
            </p>
            <p className="text-[11px] font-bold text-cyan-400 tracking-[0.16em] uppercase mt-0.5">
              QE Dashboard
            </p>
          </div>
        </button>

        {/* ── CENTER: Page title (large screens only) ── */}
        <div className="absolute inset-x-0 justify-center pointer-events-none hidden lg:flex">
          <div className="flex flex-col items-center gap-0.5">
            <h1 className="text-[22px] font-black tracking-tight text-white leading-tight">
              Quality Engineering Dashboard
            </h1>
            <p className="text-[11px] font-semibold text-slate-400 tracking-[0.12em] uppercase">
              Enterprise KPI Intelligence Platform
            </p>
          </div>
        </div>

        {/* ── RIGHT: Controls ── */}
        <div className="flex items-center gap-2 z-10 ml-auto">

          {/* Month navigator */}
          <div className="hidden sm:flex items-center bg-slate-800/70 border border-slate-700/60 rounded-xl overflow-hidden shadow-inner">
            <button
              type="button"
              onClick={handlePrevious}
              disabled={isLastMonth}
              title="Previous Month"
              className="flex items-center justify-center px-2 py-2 text-slate-400 hover:bg-slate-700/70 hover:text-white disabled:opacity-25 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={18} />
            </button>

            <div className="flex flex-col items-center justify-center px-4 py-1.5 min-w-[110px] border-x border-slate-700/60">
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 leading-none mb-0.5">
                Period
              </span>
              <span className="text-sm font-black text-white tracking-wide leading-tight whitespace-nowrap">
                {selectedMonth || "No data"}
              </span>
            </div>

            <button
              type="button"
              onClick={handleNext}
              disabled={isFirstMonth}
              title="Next Month"
              className="flex items-center justify-center px-2 py-2 text-slate-400 hover:bg-slate-700/70 hover:text-white disabled:opacity-25 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={18} />
            </button>
          </div>

          {/* Divider */}
          <div className="hidden sm:block h-8 w-px bg-slate-700/80 mx-0.5" />

          {/* SLA Dashboard */}
          <NavBtn
            onClick={handleSlaClick}
            title={isAdmin ? "SLA Dashboard" : "Admin Login — SLA Dashboard"}
            variant="emerald"
            active={isOnSla}
          >
            <ShieldCheck size={20} />
            {!isAdmin && (
              <span className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-amber-400 ring-2 ring-slate-900" />
            )}
          </NavBtn>

          {/* Token Usage (admin only) */}
          {isAdmin && (
            <NavBtn
              onClick={() => navigate("/token-usage")}
              title="Token Usage Summary"
              variant="purple"
              active={isOnToken}
            >
              <Coins size={20} />
            </NavBtn>
          )}

          {/* Logout (admin only) */}
          {isAdmin && (
            <NavBtn onClick={handleLogout} title="Logout Admin" variant="red">
              <LogOut size={20} />
            </NavBtn>
          )}

          {/* AI Assistant */}
          <NavBtn onClick={() => navigate("/assistant")} title="AI Data Assistant" variant="cyan">
            <BotMessageSquare size={20} />
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-70" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-cyan-500 ring-2 ring-slate-900" />
            </span>
          </NavBtn>

          {/* Mobile menu toggle */}
          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            title="Menu"
            className="sm:hidden flex items-center justify-center p-2.5 rounded-xl border border-slate-700/60 bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-700/70 transition-all"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* ── MOBILE DROPDOWN ── */}
      {mobileOpen && (
        <div className="sm:hidden border-t border-slate-700/60 bg-slate-900/95 px-4 py-4 flex flex-col gap-3">
          {/* Month nav (mobile) */}
          <div className="flex items-center bg-slate-800/70 border border-slate-700/60 rounded-xl overflow-hidden">
            <button
              type="button"
              onClick={handlePrevious}
              disabled={isLastMonth}
              className="flex-1 flex items-center justify-center py-2 text-slate-400 hover:bg-slate-700/70 hover:text-white disabled:opacity-25 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={18} />
            </button>
            <div className="flex flex-col items-center px-4 py-2 min-w-[110px]">
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Period</span>
              <span className="text-sm font-black text-white">{selectedMonth || "No data"}</span>
            </div>
            <button
              type="button"
              onClick={handleNext}
              disabled={isFirstMonth}
              className="flex-1 flex items-center justify-center py-2 text-slate-400 hover:bg-slate-700/70 hover:text-white disabled:opacity-25 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={18} />
            </button>
          </div>

          {/* Mobile action buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleSlaClick}
              className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 text-sm font-bold hover:bg-emerald-500/20 transition-all"
            >
              <ShieldCheck size={16} />
              {isAdmin ? "SLA Dashboard" : "Admin Login"}
            </button>

            <button
              type="button"
              onClick={() => { navigate("/assistant"); setMobileOpen(false); }}
              className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-cyan-500/30 bg-cyan-500/10 text-cyan-300 text-sm font-bold hover:bg-cyan-500/20 transition-all"
            >
              <BotMessageSquare size={16} />
              AI Assistant
            </button>

            {isAdmin && (
              <button
                type="button"
                onClick={() => { navigate("/token-usage"); setMobileOpen(false); }}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-purple-500/30 bg-purple-500/10 text-purple-300 text-sm font-bold hover:bg-purple-500/20 transition-all"
              >
                <Coins size={16} />
                Token Usage
              </button>
            )}

            {isAdmin && (
              <button
                type="button"
                onClick={handleLogout}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 text-sm font-bold hover:bg-red-500/20 transition-all"
              >
                <LogOut size={16} />
                Logout
              </button>
            )}
          </div>

          {/* Admin badge */}
          {isAdmin && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-black text-emerald-300 tracking-wide">Admin session active</span>
            </div>
          )}
        </div>
      )}
    </header>
  );
}
