import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import slugify from "slugify";
import { useMonth } from "../context/MonthContext";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";
import { Code2, Zap, Users, ShieldCheck, ArrowUpRight, ArrowDownRight, Minus, Filter } from "lucide-react";

const FILTER_STORAGE_KEY = "primark.dashboard.filters";

function readSavedFilters() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(FILTER_STORAGE_KEY) || "{}");
    return {
      domain: parsed.domain || "",
      portfolio: parsed.portfolio || "",
      project: parsed.project || "",
      month: parsed.month || "",
    };
  } catch {
    return { domain: "", portfolio: "", project: "", month: "" };
  }
}

export default function KPIDashboard() {
  const navigate = useNavigate();
  const { selectedMonth } = useMonth();
  const savedFilters = readSavedFilters();
  const [apiPayload, setApiPayload] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedDomain, setSelectedDomain] = useState(savedFilters.domain);
  const [selectedPortfolio, setSelectedPortfolio] = useState(savedFilters.portfolio);
  const [selectedProject, setSelectedProject] = useState(savedFilters.project);

  useEffect(() => {
    let active = true;
    if (!selectedMonth) {
      setApiPayload(null);
      setError("");
      setLoading(false);
      return () => {
        active = false;
      };
    }

    setLoading(true);
    setError("");

    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 12,
      llmTimeBudgetSeconds: 60,
    })
      .then((payload) => {
        if (!active) return;
        setApiPayload(payload);
      })
      .catch(async (err) => {
        if (!active) return;
        setApiPayload(null);
        setError(err?.message || "No metrics available for the selected month.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  useEffect(() => {
    sessionStorage.setItem(
      FILTER_STORAGE_KEY,
      JSON.stringify({
        month: selectedMonth,
        domain: selectedDomain,
        portfolio: selectedPortfolio,
        project: selectedProject,
      }),
    );
  }, [selectedMonth, selectedDomain, selectedPortfolio, selectedProject]);

  const buildStatusFromSeries = (history, risk = "") => {
    if (Array.isArray(history) && history.length >= 2) {
      const [current, previous] = history;
      if (typeof current?.value === "number" && typeof previous?.value === "number") {
        const delta = current.value - previous.value;
        if (delta > 0) return "Green";
      }
    }

    const riskLower = String(risk).toLowerCase();
    if (riskLower === "low") return "Green";
    if (riskLower === "normal") return "Green";
    if (riskLower === "high") return "Red";
    if (riskLower === "medium") return "Amber";

    if (!Array.isArray(history) || history.length < 2) return "Amber";
    const [current, previous] = history;
    if (typeof current?.value !== "number" || typeof previous?.value !== "number") return "Amber";
    const delta = current.value - previous.value;
    if (delta >= 0) return "Green";
    if (delta > -5) return "Amber";
    return "Red";
  };

  const kpiData = useMemo(() => {
    if (!apiPayload?.categories?.length) {
      return [];
    }

    const analysisByMetric = new Map();
    (apiPayload.analysis?.metrics || []).forEach((metric) => {
      const key = `${metric.category}::${metric.metric_name}::${metric.domain || "Unassigned"}::${metric.portfolio || "General"}::${metric.project || "General"}`;
      analysisByMetric.set(key, metric);
    });

    return apiPayload.categories.flatMap((category) =>
      (category.metrics || []).map((metric) => {
        const domain = metric.domain || "Unassigned";
        const portfolio = metric.portfolio || "General";
        const project = metric.project || "General";
        const key = `${category.name}::${metric.name}::${domain}::${portfolio}::${project}`;
        const analysis = analysisByMetric.get(key);
        const history = (metric.history || []).map((item, index) => ({
          id: index + 1,
          period: item.month,
          value: item.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: item.month_id ? `${item.month_id}-01` : "",
        }));
        return {
          dimension: category.name,
          domain,
          portfolio,
          project,
          kpiname: metric.name,
          definition: analysis?.summary || `${metric.name} metric`,
          analysisSummary: analysis?.summary || "",
          analysisRecommendation: analysis?.recommendation || "",
          analysisTrend: analysis?.trend || "",
          analysisRisk: analysis?.risk || "",
          generatedMetric: analysis?.generated_metric,
          changeVsAvgPct: analysis?.change_vs_avg_pct,
          guidelines: { ideal: metric.unit === "%" ? "> 80%" : "" },
          value: metric.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: apiPayload.month_id ? `${apiPayload.month_id}-01` : "",
          history,
          insights: metric.insights || analysis?.insights || [],
          insightPoints: (metric.insights || analysis?.insights || []).map(
            (item) => `${item?.title || ""}: ${item?.description || ""}`.trim(),
          ),
        };
      }),
    );
  }, [apiPayload, selectedMonth]);
  const dataMonthLabel = apiPayload?.dashboard?.month || selectedMonth;
  const analysisMeta = apiPayload?.analysis || null;
  const domainOptions = useMemo(
    () => Array.from(new Set(kpiData.map((kpi) => kpi.domain || "Unassigned"))).sort(),
    [kpiData],
  );
  const portfolioOptions = useMemo(() => {
    const available = kpiData
      .filter((kpi) => !selectedDomain || (kpi.domain || "Unassigned") === selectedDomain)
      .map((kpi) => kpi.portfolio || "General");
    return Array.from(new Set(available)).sort();
  }, [kpiData, selectedDomain]);
  const projectOptions = useMemo(() => {
    const available = kpiData
      .filter((kpi) => !selectedDomain || (kpi.domain || "Unassigned") === selectedDomain)
      .filter((kpi) => !selectedPortfolio || (kpi.portfolio || "General") === selectedPortfolio)
      .map((kpi) => kpi.project || "General");
    return Array.from(new Set(available)).sort();
  }, [kpiData, selectedDomain, selectedPortfolio]);

  useEffect(() => {
    if (domainOptions.length > 0 && !domainOptions.includes(selectedDomain)) {
      setSelectedDomain(domainOptions[0]);
    }
  }, [domainOptions, selectedDomain]);
  useEffect(() => {
    if (portfolioOptions.length > 0 && !portfolioOptions.includes(selectedPortfolio)) {
      setSelectedPortfolio(portfolioOptions[0]);
    }
  }, [portfolioOptions, selectedPortfolio]);
  useEffect(() => {
    if (projectOptions.length > 0 && !projectOptions.includes(selectedProject)) {
      setSelectedProject(projectOptions[0]);
    }
  }, [projectOptions, selectedProject]);

  const filteredKpiData = useMemo(
    () =>
      kpiData.filter((kpi) => {
        const domainMatch = !selectedDomain || (kpi.domain || "Unassigned") === selectedDomain;
        const portfolioMatch =
          !selectedPortfolio || (kpi.portfolio || "General") === selectedPortfolio;
        const projectMatch = !selectedProject || (kpi.project || "General") === selectedProject;
        return domainMatch && portfolioMatch && projectMatch;
      }),
    [kpiData, selectedDomain, selectedPortfolio, selectedProject],
  );

  const groupedData = filteredKpiData.reduce((acc, kpi) => {
    if (!acc[kpi.dimension]) acc[kpi.dimension] = [];
    acc[kpi.dimension].push(kpi);
    return acc;
  }, {});
  const preferredDimensions = ["Engineering", "Velocity", "Collaboration", "Quality"];
  const visibleDimensions = [
    ...preferredDimensions.filter((dimension) => groupedData[dimension]?.length),
    ...Object.keys(groupedData)
      .filter((dimension) => !preferredDimensions.includes(dimension))
      .sort(),
  ];

  const renderKpiCard = (kpi) => {
    const historyValues = Array.isArray(kpi.history)
      ? kpi.history
          .map((item) => Number(item?.value))
          .filter((value) => Number.isFinite(value))
      : [];
    const isUpward = historyValues.length >= 2 && historyValues[0] > historyValues[1];
    const normalizedStatus = String(kpi.status || "").toLowerCase();
    const isPositive = isUpward || normalizedStatus === "green" || normalizedStatus === "normal";
    const isWarning = normalizedStatus === "amber";
    const isCritical = !isPositive && normalizedStatus === "red";
    const portfolioLabel = String(kpi.portfolio || "").trim();
    const projectLabel = String(kpi.project || "").trim();
    const showPortfolioLabel = portfolioLabel && portfolioLabel.toLowerCase() !== "general";
    const showProjectLabel = projectLabel && projectLabel.toLowerCase() !== "general";
    const cardTone = isPositive
      ? {
          card: "bg-slate-950/88 border-green-400/35 shadow-green-950/20 hover:border-green-300/70",
          surface: "bg-green-400/10",
          glow: "bg-green-400/20",
          text: "text-slate-50",
          value: "text-green-200",
          badge: "bg-green-400/15 text-green-100 border-green-300/35",
          icon: "bg-green-400/15 text-green-200 border-green-300/35",
          accent: "from-green-300 via-green-400 to-green-600",
          statusPill: "bg-green-400/18 text-green-100 border-green-300/40",
          statusLabel: "Healthy",
        }
      : isCritical
        ? {
            card: "bg-slate-950/88 border-red-400/35 shadow-red-950/20 hover:border-red-300/70",
            surface: "bg-red-400/10",
            glow: "bg-red-400/20",
            text: "text-slate-50",
            value: "text-red-200",
            badge: "bg-red-400/15 text-red-100 border-red-300/35",
            icon: "bg-red-400/15 text-red-200 border-red-300/35",
            accent: "from-red-300 via-red-500 to-red-700",
            statusPill: "bg-red-400/18 text-red-100 border-red-300/40",
            statusLabel: "Needs attention",
          }
        : {
            card: "bg-slate-950/88 border-amber-400/40 shadow-amber-950/20 hover:border-amber-300/75",
            surface: "bg-amber-400/10",
            glow: "bg-amber-400/20",
            text: "text-slate-50",
            value: "text-amber-200",
            badge: "bg-amber-400/15 text-amber-100 border-amber-300/35",
            icon: "bg-amber-400/15 text-amber-100 border-amber-300/35",
            accent: "from-amber-200 via-amber-400 to-orange-500",
            statusPill: "bg-amber-400/18 text-amber-100 border-amber-300/40",
            statusLabel: "Watch",
          };
    
    return (
      <div
        key={kpi.kpiname}
        onClick={() =>
          navigate(
            `/kpi/${slugify(kpi.kpiname, { lower: true, strict: true })}`,
            { state: { kpi } },
          )
        }
        className={`group cursor-pointer ${cardTone.card} border rounded-xl shadow-lg hover:shadow-[0_20px_50px_rgba(2,6,23,0.42)] hover:-translate-y-1 transition-all duration-300 p-3.5 flex flex-col gap-2 h-[124px] overflow-hidden relative backdrop-blur-md font-inter`}
      >
        <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${cardTone.accent} pointer-events-none`} />
        <div className={`absolute -right-8 -top-10 h-28 w-28 rounded-full ${cardTone.glow} blur-2xl pointer-events-none transition-transform duration-300 group-hover:scale-125`} />
        <div className={`absolute left-3 right-3 top-4 h-16 rounded-full ${cardTone.surface} blur-2xl pointer-events-none`} />
        <div className="absolute inset-0 bg-[linear-gradient(145deg,rgba(255,255,255,0.08),rgba(255,255,255,0.02)_38%,rgba(2,6,23,0.2))] pointer-events-none" />
        <div className="flex min-h-0 flex-1 justify-between items-start w-full z-10 gap-2 pt-0.5">
          <div className="min-w-0 pr-1">
            <p className={`text-sm ${cardTone.text} font-bold leading-tight line-clamp-3 tracking-normal`}>
              {kpi.kpiname}
            </p>
          </div>
          <div className="flex shrink-0 items-start">
            <div className={`flex items-center justify-center w-7 h-7 rounded-lg shrink-0 shadow-md border ${cardTone.icon}`}>
              {isPositive ? <ArrowUpRight size={12} strokeWidth={3} /> :
               isCritical ? <ArrowDownRight size={12} strokeWidth={3} /> :
               <Minus size={12} strokeWidth={3} />}
            </div>
          </div>
        </div>
        
        <div className="flex items-end justify-between gap-2 w-full z-10">
          <div className="min-w-0 flex-1">
            <span className={`block truncate text-3xl font-black tracking-normal leading-none ${cardTone.value}`}>
              {kpi.value}
            </span>
          </div>
          <span className={`inline-flex max-w-[112px] shrink-0 rounded-full border px-2 py-1 text-[11px] font-extrabold uppercase leading-none tracking-normal ${cardTone.statusPill} backdrop-blur-md shadow-sm`}>
            {cardTone.statusLabel}
          </span>
          {/* {(showProjectLabel || showPortfolioLabel) && (
            <p className={`rounded-full border px-2.5 py-1 text-[11px] ${cardTone.badge} font-bold uppercase text-right leading-tight tracking-normal backdrop-blur-md shadow-sm truncate max-w-[120px]`}>
              {showProjectLabel ? projectLabel : portfolioLabel}
            </p>
          )} */}
        </div>
      </div>
    );
  };

  const getDimensionConfig = (dimension) => {
    switch(dimension) {
      case "Engineering":
        return {
          icon: Code2,
          panel: "bg-gradient-to-br from-slate-900 via-cyan-950/70 to-slate-800 border-cyan-300/40 hover:border-cyan-200/70",
          glow: "bg-cyan-400/20",
          iconBox: "bg-cyan-400/15 text-cyan-100 border-cyan-300/35",
          accent: "bg-cyan-300",
          title: "text-white",
        };
      case "Velocity":
        return {
          icon: Zap,
          panel: "bg-gradient-to-br from-slate-900 via-amber-950/70 to-slate-800 border-amber-300/45 hover:border-amber-200/75",
          glow: "bg-amber-400/20",
          iconBox: "bg-amber-400/15 text-amber-100 border-amber-300/35",
          accent: "bg-amber-300",
          title: "text-white",
        };
      case "Collaboration":
        return {
          icon: Users,
          panel: "bg-gradient-to-br from-slate-900 via-sky-950/70 to-slate-800 border-sky-300/40 hover:border-sky-200/70",
          glow: "bg-sky-400/20",
          iconBox: "bg-sky-400/15 text-sky-100 border-sky-300/35",
          accent: "bg-sky-300",
          title: "text-white",
        };
      case "Quality":
        return {
          icon: ShieldCheck,
          panel: "bg-gradient-to-br from-slate-900 via-emerald-950/70 to-slate-800 border-emerald-300/40 hover:border-emerald-200/70",
          glow: "bg-emerald-400/20",
          iconBox: "bg-emerald-400/15 text-emerald-100 border-emerald-300/35",
          accent: "bg-emerald-300",
          title: "text-white",
        };
      default:
        return {
          icon: Code2,
          panel: "bg-gradient-to-br from-slate-900 via-slate-800 to-slate-700 border-slate-400/35 hover:border-slate-300/60",
          glow: "bg-slate-400/15",
          iconBox: "bg-slate-400/15 text-slate-100 border-slate-300/30",
          accent: "bg-slate-300",
          title: "text-white",
        };
    }
  };

  const renderDimensionCards = (dimension) => {
    const config = getDimensionConfig(dimension);
    const Icon = config.icon;
    
    return (
      <div className={`${config.panel} rounded-2xl p-5 flex flex-col h-full animate-fade-in relative overflow-hidden shadow-xl border backdrop-blur-md transition-colors duration-300`}>
        <div className={`absolute -right-10 -top-10 w-40 h-40 rounded-full ${config.glow} blur-3xl pointer-events-none opacity-70`} />
        <div className={`absolute -left-16 bottom-0 w-44 h-44 rounded-full ${config.glow} blur-3xl pointer-events-none opacity-35`} />
        <div className="absolute inset-x-0 top-0 h-px bg-white/10 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-br from-white/[0.035] via-transparent to-black/10 pointer-events-none" />
        
        <div className="flex items-center space-x-3 mb-5 relative z-10">
          <div className={`p-3 rounded-xl border shadow-sm backdrop-blur-sm ${config.iconBox}`}>
            <Icon size={24} />
          </div>
          <div>
            <div className={`h-1 w-10 rounded-full ${config.accent} mb-2`} />
            <h3 className={`text-xl font-bold ${config.title} tracking-normal font-inter`}>
              {dimension}
            </h3>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 flex-1 relative z-10">
          {groupedData[dimension]?.map((kpi) => renderKpiCard(kpi))}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full flex flex-col relative pb-12">
      {loading && (
        <div className="flex justify-center items-center py-12">
          <div className="animate-pulse-slow px-6 py-3 bg-slate-800/80 backdrop-blur-md text-brand-400 rounded-full text-base font-medium border border-slate-700 shadow-xl flex items-center space-x-3">
            <div className="w-5 h-5 rounded-full border-2 border-brand-400 border-t-transparent animate-spin" />
            <span>Loading dashboard metrics...</span>
          </div>
        </div>
      )}
      
      {!loading && error && (
        <div className="mx-auto mt-2 mb-6 bg-rose-900/50 backdrop-blur-md border border-rose-500/50 rounded-xl px-6 py-4 text-base text-rose-200 max-w-2xl text-center shadow-xl">
          {error}
        </div>
      )}

      {!loading && kpiData.length > 0 && (
        <div className="mx-auto mb-6 w-full max-w-4xl bg-slate-800/80 backdrop-blur-md rounded-xl px-5 py-4 border border-slate-600 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-end gap-4">
            <div className="flex items-center gap-2 text-slate-100 font-semibold min-w-[140px]">
              <Filter size={18} className="text-cyan-300" />
              <span>Filters</span>
            </div>
            <label className="flex-1 text-sm text-slate-300">
              <span className="block mb-1 font-medium">Domain</span>
              <select
                value={selectedDomain}
                onChange={(event) => {
                  setSelectedDomain(event.target.value);
                  setSelectedPortfolio("");
                  setSelectedProject("");
                }}
                className="w-full rounded-lg border border-slate-500 bg-slate-900 px-3 py-2 text-white outline-none focus:border-cyan-400"
              >
                {domainOptions.map((domain) => (
                  <option key={domain} value={domain}>
                    {domain}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex-1 text-sm text-slate-300">
              <span className="block mb-1 font-medium">Portfolio</span>
              <select
                value={selectedPortfolio}
                onChange={(event) => {
                  setSelectedPortfolio(event.target.value);
                  setSelectedProject("");
                }}
                className="w-full rounded-lg border border-slate-500 bg-slate-900 px-3 py-2 text-white outline-none focus:border-cyan-400"
              >
                {portfolioOptions.map((portfolio) => (
                  <option key={portfolio} value={portfolio}>
                    {portfolio}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex-1 text-sm text-slate-300">
              <span className="block mb-1 font-medium">Project</span>
              <select
                value={selectedProject}
                onChange={(event) => setSelectedProject(event.target.value)}
                className="w-full rounded-lg border border-slate-500 bg-slate-900 px-3 py-2 text-white outline-none focus:border-cyan-400"
              >
                {projectOptions.map((project) => (
                  <option key={project} value={project}>
                    {project}
                  </option>
                ))}
              </select>
            </label>
            <div className="text-sm text-slate-300 md:text-right">
              <span className="block font-semibold text-white">{filteredKpiData.length}</span>
              <span>metrics shown</span>
            </div>
          </div>
        </div>
      )}

      {!loading && !error && kpiData.length > 0 && analysisMeta && (
        <div className="mx-auto mb-8 w-full max-w-4xl bg-slate-800/80 backdrop-blur-md rounded-2xl px-8 py-5 text-base text-slate-100 flex flex-wrap items-center justify-between gap-4 shadow-xl border border-slate-600">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_12px_rgba(52,211,153,1)]" />
            <span className="font-medium text-slate-200">Analysis month: <span className="font-bold text-white ml-1">{analysisMeta.month || dataMonthLabel}</span></span>
          </div>
          <div className="hidden sm:block w-px h-6 bg-slate-500" />
          <div className="text-sm text-slate-300 font-medium">
            Generated: <span className="text-white">{analysisMeta.generated_at || "NA"}</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 xl:gap-8 w-full max-w-[1400px] mx-auto z-10">
        {visibleDimensions.map((dimension) => renderDimensionCards(dimension))}
      </div>
      {!loading && !error && !selectedMonth && (
        <div className="mx-auto mt-6 rounded-xl border border-slate-600 bg-slate-800/80 px-6 py-5 text-slate-200">
          No monthly data uploaded yet.
        </div>
      )}
      {!loading && !error && selectedMonth && kpiData.length === 0 && (
        <div className="mx-auto mt-6 rounded-xl border border-slate-600 bg-slate-800/80 px-6 py-5 text-slate-200">
          No metrics available for {selectedMonth}.
        </div>
      )}
      {!loading && !error && kpiData.length > 0 && visibleDimensions.length === 0 && (
        <div className="mx-auto mt-6 rounded-xl border border-slate-600 bg-slate-800/80 px-6 py-5 text-slate-200">
          No metrics match the selected domain, portfolio, and project.
        </div>
      )}
    </div>
  );
}
