export const SLA_STORAGE_KEY = "primark.qe-sla-dashboard.csv";

export const REQUIRED_SLA_COLUMNS = [
  "month",
  "sit_defects",
  "uat_defects",
  "prod_defects",
  "sev1",
  "sev2",
  "planned_tests",
  "executed_tests",
  "reopened_defects",
  "closed_defects",
  "successful_runs",
  "total_runs",
  "regression_cycles_completed",
  "total_regression_cycles",
  "uat_missed_defects",
  "total_uat_defects",
];

export const SAMPLE_SLA_CSV = `month,sit_defects,uat_defects,prod_defects,sev1,sev2,planned_tests,executed_tests,reopened_defects,closed_defects,successful_runs,total_runs,regression_cycles_completed,total_regression_cycles,uat_missed_defects,total_uat_defects,blocked_due_to_environment,blocked_due_to_test_data,false_negatives
2026-01,312,10,2,0,1,1280,1275,7,210,940,970,10,10,2,38,0,0,4
2026-02,286,12,1,0,2,1210,1198,8,202,912,956,9,10,3,42,4,0,5
2026-03,334,18,4,1,3,1325,1290,15,225,884,990,9,10,6,46,8,3,9
2026-04,301,11,1,0,1,1240,1238,6,218,963,994,10,10,2,40,0,0,2
2026-05,318,16,3,0,3,1300,1278,10,221,925,982,9,10,5,44,6,0,7
2026-06,329,9,1,0,1,1340,1336,5,230,982,1010,10,10,1,39,0,0,3`;

export const SLA_KPI_RULES = [
  {
    id: "dre",
    name: "Defect Removal Efficiency",
    shortName: "DRE",
    weightage: 25,
    targetLabel: ">= 98%",
    unit: "%",
    formula: "(SIT + UAT Defects) / (SIT + UAT + Production Defects) * 100",
  },
  {
    id: "criticalLeakage",
    name: "Critical Defect Leakage",
    shortName: "Leakage",
    weightage: 25,
    targetLabel: "0 Sev1, controlled Sev2",
    unit: "",
    formula: "Sev1 + Sev2 production leakage; any Sev1 is a critical failure",
  },
  {
    id: "regressionCycleTime",
    name: "Regression Cycle Time",
    shortName: "Regression",
    weightage: 10,
    targetLabel: "100%",
    unit: "%",
    formula: "Regression cycles completed within SLA / total regression cycles * 100",
  },
  {
    id: "testExecutionAdherence",
    name: "Test Execution Adherence",
    shortName: "Execution",
    weightage: 10,
    targetLabel: "100%",
    unit: "%",
    formula: "Executed test cases / planned test cases after approved exclusions * 100",
  },
  {
    id: "uatRejectionRate",
    name: "UAT Rejection Rate",
    shortName: "UAT Reject",
    weightage: 5,
    targetLabel: "< 5%",
    unit: "%",
    formula: "UAT missed defects / total UAT defects * 100",
  },
  {
    id: "defectReopenRate",
    name: "Defect Reopen Rate",
    shortName: "Reopen",
    weightage: 5,
    targetLabel: "<= 5%",
    unit: "%",
    formula: "Reopened defects / closed defects * 100",
  },
  {
    id: "automationStability",
    name: "Automation Script Stability",
    shortName: "Automation",
    weightage: 20,
    targetLabel: ">= 95%",
    unit: "%",
    formula: "Stable automation runs / total automation runs excluding false negatives * 100",
  },
];

export const STATUS_STYLES = {
  Green: {
    label: "Healthy",
    text: "text-emerald-200",
    subtleText: "text-emerald-300",
    bg: "bg-emerald-500/15",
    strongBg: "bg-emerald-500",
    border: "border-emerald-300/35",
    rail: "from-emerald-400 via-emerald-500 to-teal-500",
  },
  Amber: {
    label: "Warning",
    text: "text-amber-200",
    subtleText: "text-amber-300",
    bg: "bg-amber-500/15",
    strongBg: "bg-amber-500",
    border: "border-amber-300/35",
    rail: "from-amber-300 via-amber-500 to-orange-500",
  },
  Red: {
    label: "Breach",
    text: "text-red-200",
    subtleText: "text-red-300",
    bg: "bg-red-500/15",
    strongBg: "bg-red-500",
    border: "border-red-300/35",
    rail: "from-red-400 via-rose-500 to-red-600",
  },
};
