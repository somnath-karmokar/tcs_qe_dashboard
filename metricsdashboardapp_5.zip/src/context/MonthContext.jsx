import React, { createContext, useContext, useEffect, useState } from "react";
import { fetchAvailableMonths } from "../services/monthlyMetricsApi";

const MonthContext = createContext();
const fallbackMonths = ["Feb 2026", "Jan 2026", "Dec 2025", "Nov 2025", "Oct 2025", "Sep 2025"];
const monthMap = {
  Jan: "01",
  Feb: "02",
  Mar: "03",
  Apr: "04",
  May: "05",
  Jun: "06",
  Jul: "07",
  Aug: "08",
  Sep: "09",
  Oct: "10",
  Nov: "11",
  Dec: "12",
};

function monthLabelToId(label) {
  const [mon, year] = String(label || "").trim().split(/\s+/);
  if (!mon || !year || !monthMap[mon]) return "";
  return `${year}-${monthMap[mon]}`;
}

function sortMonthsDesc(labels) {
  return [...labels].sort((a, b) => monthLabelToId(b).localeCompare(monthLabelToId(a)));
}

// eslint-disable-next-line react-refresh/only-export-components
export const useMonth = () => {
  const context = useContext(MonthContext);
  if (!context) {
    throw new Error("useMonth must be used within MonthProvider");
  }
  return context;
};

export const MonthProvider = ({ children }) => {
  const sortedFallbackMonths = sortMonthsDesc(fallbackMonths);
  const [months, setMonths] = useState(sortedFallbackMonths);
  const [selectedMonth, setSelectedMonth] = useState(sortedFallbackMonths[0]);

  useEffect(() => {
    let active = true;

    fetchAvailableMonths()
      .then((apiMonths) => {
        if (!active || !Array.isArray(apiMonths) || apiMonths.length === 0) return;
        const sorted = [...apiMonths].sort((a, b) =>
          String(b?.month_id || "").localeCompare(String(a?.month_id || ""))
        );
        const labels = sorted.map((item) => item?.month).filter(Boolean);
        if (labels.length === 0) return;
        setMonths(labels);
        setSelectedMonth(labels[0]);
      })
      .catch(() => {
        // keep fallback months when API is unavailable
      });

    return () => {
      active = false;
    };
  }, []);

  const value = {
    selectedMonth,
    setSelectedMonth,
    months,
  };

  return (
    <MonthContext.Provider value={value}>
      {children}
    </MonthContext.Provider>
  );
};
