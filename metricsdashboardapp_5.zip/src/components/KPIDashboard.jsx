import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import kpiDataOriginal from "../data/mockData.json";
import slugify from "slugify";
import { useMonth } from "../context/MonthContext";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";

export default function KPIDashboard() {
  const navigate = useNavigate();
  const { selectedMonth } = useMonth();
  const [apiPayload, setApiPayload] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isLatestFallback, setIsLatestFallback] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    setIsLatestFallback(false);

    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 12,
      llmTimeBudgetSeconds: 60,
    })
      .then((payload) => {
        if (!active) return;
        setApiPayload(payload);
      })
      .catch(async (err) => {
        if (!active) return;
        try {
          const latestPayload = await fetchFrontendDashboard(undefined, 6, {
            ensureAnalysis: true,
            useLlm: true,
            maxLlmMetrics: 12,
            llmTimeBudgetSeconds: 60,
          });
          if (!active) return;
          setApiPayload(latestPayload);
          setIsLatestFallback(true);
          setError(err?.message || "Selected month not available. Showing latest updated metrics.");
        } catch (fallbackErr) {
          if (!active) return;
          setApiPayload(null);
          setError(fallbackErr?.message || "Unable to load dashboard data from API.");
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  const getKPIDataForMonth = (month) => {
    return kpiDataOriginal
      .map((kpi) => {
        const monthData = kpi.history.find((h) => h.period === month);
        if (!monthData) return null;
        return {
          dimension: kpi.dimension,
          kpiname: kpi.kpiname,
          definition: kpi.definition,
          guidelines: kpi.guidelines,
          value: monthData.value,
          status: monthData.status,
          updated_at: monthData.updated_at,
          history: kpi.history,
        };
      })
      .filter(Boolean);
  };

  const buildStatusFromSeries = (history, risk = "") => {
    const riskLower = String(risk).toLowerCase();
    if (riskLower === "low") return "Green";
    if (riskLower === "high") return "Red";
    if (riskLower === "medium") return "Amber";

    if (!Array.isArray(history) || history.length < 2) return "Amber";
    const [current, previous] = history;
    if (typeof current?.value !== "number" || typeof previous?.value !== "number") return "Amber";
    const delta = current.value - previous.value;
    if (delta >= 0) return "Green";
    if (delta > -5) return "Amber";
    return "Red";
  };

  const kpiData = useMemo(() => {
    if (!apiPayload?.categories?.length) {
      return getKPIDataForMonth(selectedMonth);
    }

    const analysisByMetric = new Map();
    (apiPayload.analysis?.metrics || []).forEach((metric) => {
      const key = `${metric.category}::${metric.metric_name}`;
      analysisByMetric.set(key, metric);
    });

    return apiPayload.categories.flatMap((category) =>
      (category.metrics || []).map((metric) => {
        const key = `${category.name}::${metric.name}`;
        const analysis = analysisByMetric.get(key);
        const history = (metric.history || []).map((item, index) => ({
          id: index + 1,
          period: item.month,
          value: item.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: item.month_id ? `${item.month_id}-01` : "",
        }));
        return {
          dimension: category.name,
          kpiname: metric.name,
          definition: analysis?.summary || `${metric.name} metric`,
          analysisSummary: analysis?.summary || "",
          analysisRecommendation: analysis?.recommendation || "",
          analysisTrend: analysis?.trend || "",
          analysisRisk: analysis?.risk || "",
          generatedMetric: analysis?.generated_metric,
          changeVsAvgPct: analysis?.change_vs_avg_pct,
          guidelines: { ideal: metric.unit === "%" ? "> 80%" : "" },
          value: metric.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: apiPayload.month_id ? `${apiPayload.month_id}-01` : "",
          history,
          insights: metric.insights || analysis?.insights || [],
          insightPoints: (metric.insights || analysis?.insights || []).map(
            (item) => `${item?.title || ""}: ${item?.description || ""}`.trim(),
          ),
        };
      }),
    );
  }, [apiPayload, selectedMonth]);
  const dataMonthLabel = apiPayload?.dashboard?.month || selectedMonth;
  const analysisMeta = apiPayload?.analysis || null;

  const groupedData = kpiData.reduce((acc, kpi) => {
    if (!acc[kpi.dimension]) acc[kpi.dimension] = [];
    acc[kpi.dimension].push(kpi);
    return acc;
  }, {});

  const renderKpiCard = (kpi) => {
    return (
      <div
        key={kpi.kpiname}
        onClick={() =>
          navigate(
            `/kpi/${slugify(kpi.kpiname, { lower: true, strict: true })}`,
            { state: { kpi } },
          )
        }
        className="cursor-pointer bg-white/90 backdrop-blur-sm border border-gray-200/50 rounded-lg shadow-sm flex flex-col items-center justify-center text-center hover:shadow-lg hover:scale-[1.02] transition-all duration-200 p-1.5 h-[70px]"
      >
        <p className="text-[10px] text-gray-700 font-medium mb-1 line-clamp-2 leading-tight px-1">
          {kpi.kpiname}
        </p>
        <span
          className={`px-1.5 py-0.5 text-xs rounded-md font-bold shadow-sm ${
            kpi.status === "Green"
              ? "bg-green-500 text-white"
              : kpi.status === "Amber"
                ? "bg-amber-500 text-white"
                : "bg-red-500 text-white"
          }`}
        >
          {kpi.value}
        </span>
        <p className="text-[10px] text-gray-500 mt-0.5">{dataMonthLabel}</p>
      </div>
    );
  };

  const renderDimensionCards = (dimension) => (
    <div className="grid grid-cols-2 gap-2">
      {groupedData[dimension]?.map((kpi) => renderKpiCard(kpi))}
    </div>
  );

  return (
    <div className="w-full h-[calc(98vh-64px)] overflow-hidden bg-gray-50 flex flex-col relative">
      {loading && (
        <p className="text-xs text-gray-500 text-center pt-2">Loading dashboard metrics...</p>
      )}
      {!loading && (
        <p className="text-xs text-gray-600 text-center pt-1">
          Selected month: <span className="font-semibold">{selectedMonth}</span> | Showing metrics for:{" "}
          <span className="font-semibold">{dataMonthLabel}</span>
          {isLatestFallback ? " (latest update)" : ""}
        </p>
      )}
      {error && (
        <p className="text-xs text-amber-700 text-center pt-1">
          {error}
        </p>
      )}
      {!loading && analysisMeta && (
        <div className="mx-auto mt-1 mb-1 w-[98%] bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 flex items-center justify-between">
          <span>
            Analysis month: <span className="font-semibold">{analysisMeta.month || dataMonthLabel}</span>
          </span>
          <span>
            Overall generated metric:{" "}
            <span className="font-semibold">{analysisMeta.overall_generated_metric ?? "NA"}</span>
          </span>
          <span>
            Generated at: <span className="font-semibold">{analysisMeta.generated_at || "NA"}</span>
          </span>
        </div>
      )}
      <div className="flex-1 px-3 py-2 grid grid-rows-2 gap-3 max-w-[1600px] mx-auto w-full">
        <div className="grid grid-cols-[1fr_320px_1fr] gap-4">
          <div className="bg-gradient-to-br from-red-100 to-pink-100 rounded-2xl p-3 shadow-lg">
            <h3 className="text-xs font-bold text-gray-800 mb-2 flex items-center gap-2">
              <span className="w-1 h-4 bg-red-500 rounded-full" />
              Engineering
            </h3>
            {renderDimensionCards("Engineering")}
          </div>
          <div className="relative" />
          <div className="bg-gradient-to-br from-lime-100 to-green-100 rounded-2xl p-3 shadow-lg">
            <h3 className="text-xs font-bold text-gray-800 mb-2 flex items-center gap-2">
              <span className="w-1 h-4 bg-lime-500 rounded-full" />
              Velocity
            </h3>
            {renderDimensionCards("Velocity")}
          </div>
        </div>
        <div className="grid grid-cols-[1fr_320px_1fr] gap-4">
          <div className="bg-gradient-to-br from-purple-100 to-violet-100 rounded-2xl p-3 shadow-lg mb-5">
            <h3 className="text-xs font-bold text-gray-800 mb-2 flex items-center gap-2">
              <span className="w-1 h-4 bg-purple-500 rounded-full" />
              Collaboration
            </h3>
            {renderDimensionCards("Collaboration")}
          </div>
          <div className="relative" />
          <div className="bg-gradient-to-br from-orange-100 to-amber-100 rounded-2xl p-3 shadow-lg mb-5">
            <h3 className="text-xs font-bold text-gray-800 mb-2 flex items-center gap-2">
              <span className="w-1 h-4 bg-orange-500 rounded-full" />
              Quality
            </h3>
            {renderDimensionCards("Quality")}
          </div>
        </div>
      </div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none">
        <div className="relative w-60 h-60 rounded-full overflow-hidden shadow-2xl border-[5px] border-white">
          <div
            className="absolute inset-0 bg-gradient-to-br from-red-400 to-pink-400"
            style={{ clipPath: "polygon(0 0, 50% 0, 50% 50%, 0 50%)" }}
          />
          <div
            className="absolute inset-0 bg-gradient-to-bl from-lime-400 to-green-400"
            style={{ clipPath: "polygon(50% 0, 100% 0, 100% 50%, 50% 50%)" }}
          />
          <div
            className="absolute inset-0 bg-gradient-to-tr from-purple-400 to-violet-400"
            style={{ clipPath: "polygon(0 50%, 50% 50%, 50% 100%, 0 100%)" }}
          />
          <div
            className="absolute inset-0 bg-gradient-to-tl from-orange-400 to-amber-400"
            style={{
              clipPath: "polygon(50% 50%, 100% 50%, 100% 100%, 50% 100%)",
            }}
          />
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute w-0.5 h-full bg-white/90 left-1/2 -translate-x-1/2 shadow-sm" />
            <div className="absolute h-0.5 w-full bg-white/90 top-1/2 -translate-y-1/2 shadow-sm" />
          </div>
          <div className="absolute top-[25%] left-[28%] -translate-x-1/2 -translate-y-1/2">
            <p className="text-white text-[12px] font-bold drop-shadow-md whitespace-nowrap">
              Engineering
            </p>
          </div>
          <div className="absolute top-[25%] right-[25%] translate-x-1/2 -translate-y-1/2">
            <p className="text-white text-[12px] font-bold drop-shadow-md whitespace-nowrap">
              Velocity
            </p>
          </div>
          <div className="absolute bottom-[25%] left-[28%] -translate-x-1/2 translate-y-1/2">
            <p className="text-white text-[12px] font-bold drop-shadow-md whitespace-nowrap">
              Collaboration
            </p>
          </div>
          <div className="absolute bottom-[25%] right-[25%] translate-x-1/2 translate-y-1/2">
            <p className="text-white text-[12px] font-bold drop-shadow-md whitespace-nowrap">
              Quality
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
