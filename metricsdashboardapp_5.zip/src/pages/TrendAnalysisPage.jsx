import React, { useEffect, useMemo, useState } from "react";
import { useParams, useLocation } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import PlotLineChart from "../components/PlotLineChart";
import kpiData from "../data/mockData.json";
import slugify from "slugify";
import { parseThreshold } from "../utils/ThresholdParser";
import { IoMdArrowRoundBack } from "react-icons/io";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";
import { useMonth } from "../context/MonthContext";

export default function TrendAnalysisPage() {
  const { kpiName } = useParams();
  const location = useLocation();
  const { selectedMonth } = useMonth();
  const { kpi: passedKpi, selectedPeriod = "", selectedMonthId = "" } = location.state || {};
  const [apiPayload, setApiPayload] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);

    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 12,
      llmTimeBudgetSeconds: 60,
    })
      .then((payload) => {
        if (!active) return;
        setApiPayload(payload);
      })
      .catch(async () => {
        try {
          const latestPayload = await fetchFrontendDashboard(undefined, 6, {
            ensureAnalysis: true,
            useLlm: true,
            maxLlmMetrics: 12,
            llmTimeBudgetSeconds: 60,
          });
          if (!active) return;
          setApiPayload(latestPayload);
        } catch {
          if (!active) return;
          setApiPayload(null);
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  const kpiFromApi = useMemo(() => {
    if (!apiPayload?.categories?.length) return null;

    const analysisByMetric = new Map();
    (apiPayload.analysis?.metrics || []).forEach((metric) => {
      const key = `${metric.category}::${metric.metric_name}`;
      analysisByMetric.set(key, metric);
    });

    const allKpis = apiPayload.categories.flatMap((category) =>
      (category.metrics || []).map((metric) => {
        const key = `${category.name}::${metric.name}`;
        const analysis = analysisByMetric.get(key);
        const history = (metric.history || []).map((item, index) => ({
          id: index + 1,
          period: item.month,
          value: item.value,
          status: "Amber",
          updated_at: item.month_id ? `${item.month_id}-01` : "",
        }));
        return {
          dimension: category.name,
          kpiname: metric.name,
          definition: analysis?.summary || `${metric.name} metric`,
          analysisSummary: analysis?.summary || "",
          analysisRecommendation: analysis?.recommendation || "",
          analysisTrend: analysis?.trend || "",
          analysisRisk: analysis?.risk || "",
          generatedMetric: analysis?.generated_metric,
          changeVsAvgPct: analysis?.change_vs_avg_pct,
          guidelines: { ideal: metric.unit === "%" ? "> 80%" : "" },
          value: metric.value,
          status: "Amber",
          updated_at: apiPayload.month_id ? `${apiPayload.month_id}-01` : "",
          history,
          insights: metric.insights || analysis?.insights || [],
          insightPoints: (metric.insights || analysis?.insights || []).map(
            (item) => `${item?.title || ""}: ${item?.description || ""}`.trim(),
          ),
          analysisHistory: metric.analysis_history || [],
        };
      }),
    );

    return (
      allKpis.find((k) => slugify(k.kpiname, { lower: true, strict: true }) === kpiName) || null
    );
  }, [apiPayload, kpiName]);

  const kpi =
    kpiFromApi ||
    passedKpi ||
    kpiData.find((k) => slugify(k.kpiname, { lower: true, strict: true }) === kpiName);

  if (!kpi) {
    if (loading) {
      return <div className="p-6 text-gray-500">Loading trend analysis...</div>;
    }
    return <div className="p-6 text-red-500">KPI not found</div>;
  }

  const lastSix = [...kpi.history].slice(-6).reverse();
  const categories = lastSix.map((h) => h.period); 
  const values = lastSix.map((h) => h.value); 
  const threshold = parseThreshold(kpi.guidelines.ideal);
  const normalizedSelectedPeriod = selectedPeriod.trim().toLowerCase();

  const history = Array.isArray(kpi.analysisHistory) ? kpi.analysisHistory : [];
  const filtered = history.filter((entry) => {
    if (!entry) return false;
    const entryMonthId = String(entry.month_id || "").trim();
    const entryMonthLabel = String(entry.month || "").trim().toLowerCase();

    if (selectedMonthId && entryMonthId === selectedMonthId) return true;
    if (normalizedSelectedPeriod && entryMonthLabel === normalizedSelectedPeriod) return true;

    return false;
  });
  const filteredAnalysisHistory =
    selectedMonthId || normalizedSelectedPeriod
      ? filtered.length > 0
        ? filtered
        : history
      : history;

  return (
    <div className="min-h-screen flex flex-col p-2 mt-2">
      {/* <Header /> */}
      <div className="flex items-center gap-2 mb-2">
        <button
          onClick={() => window.history.back()}
          className="p-2 rounded-lg "
        >
          <IoMdArrowRoundBack size={20} />
        </button>

        <h1
          className="text-xl font-bold bg-sky-800 rounded-lg py-2 px-2 text-white
                   inline-block md:mx-2"
        >
          {kpi.kpiname} - Trend Analysis
        </h1>
      </div>
      <main className="flex-1 flex flex-col">
        <PlotLineChart
          title={kpi.kpiname}
          categories={categories}
          values={values}
          threshold={threshold}
          guidelines={kpi.guidelines}
          insights={kpi.insights || []}
          insightPoints={kpi.insightPoints || []}
          analysisHistory={filteredAnalysisHistory}
          metricAnalysis={{
            summary: kpi.analysisSummary,
            recommendation: kpi.analysisRecommendation,
            trend: kpi.analysisTrend,
            risk: kpi.analysisRisk,
            generatedMetric: kpi.generatedMetric,
            changeVsAvgPct: kpi.changeVsAvgPct,
          }}
        />

        
      </main>
      {/* <Footer /> */}
    </div>
  );
}
