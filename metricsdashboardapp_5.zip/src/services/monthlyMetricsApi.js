const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000/api";

async function handleResponse(response) {
  if (!response.ok) {
    let detail = `Request failed (${response.status})`;
    try {
      const parsed = await response.json();
      if (parsed?.detail) {
        detail = typeof parsed.detail === "string" ? parsed.detail : JSON.stringify(parsed.detail);
      }
    } catch {
      // ignore response parse errors
    }
    throw new Error(detail);
  }
  return response.json();
}

export async function fetchAvailableMonths() {
  const response = await fetch(`${API_BASE_URL}/monthly-metrics/months`);
  const payload = await handleResponse(response);
  return payload?.months || [];
}

export async function fetchFrontendDashboard(month, historyMonths = 6, options = {}) {
  const {
    ensureAnalysis = false,
    refreshAnalysis = false,
    useLlm = true,
    maxLlmMetrics = 8,
    llmTimeBudgetSeconds = 45,
  } = options;
  const query = new URLSearchParams();
  query.set("history_months", String(historyMonths));
  if (month) query.set("month", month);
  query.set("ensure_analysis", String(Boolean(ensureAnalysis)));
  query.set("refresh_analysis", String(Boolean(refreshAnalysis)));
  query.set("use_llm", String(Boolean(useLlm)));
  query.set("max_llm_metrics", String(Number(maxLlmMetrics)));
  query.set("llm_time_budget_seconds", String(Number(llmTimeBudgetSeconds)));
  const response = await fetch(`${API_BASE_URL}/monthly-metrics/frontend?${query.toString()}`);
  return handleResponse(response);
}
