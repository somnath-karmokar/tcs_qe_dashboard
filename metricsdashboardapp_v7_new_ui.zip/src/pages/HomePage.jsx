import React from "react";
import Header from "../components/Header";
import KPIDashboard from "../components/KPIDashboard";
import Footer from "../components/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen w-full flex flex-col bg-slate-900 relative overflow-x-hidden">
      {/* Decorative vibrant glowing orbs */}
      <div className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] rounded-full bg-fuchsia-600/20 blur-[120px] pointer-events-none" />
      <div className="absolute top-[40%] left-[-10%] w-[500px] h-[500px] rounded-full bg-cyan-500/20 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[20%] w-[400px] h-[400px] rounded-full bg-emerald-500/10 blur-[100px] pointer-events-none" />

      <Header />
      <main className="flex-1 w-full max-w-[1800px] mx-auto relative z-10 px-2 sm:px-4">
        <KPIDashboard />
      </main>
      <Footer />
    </div>
  );
}
