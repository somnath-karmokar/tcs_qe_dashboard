import React, { useEffect, useMemo, useState } from "react";
import { useParams, useLocation } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import PlotLineChart from "../components/PlotLineChart";
import kpiData from "../data/mockData.json";
import slugify from "slugify";
import { parseThreshold } from "../utils/ThresholdParser";
import { IoMdArrowRoundBack } from "react-icons/io";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";
import { useMonth } from "../context/MonthContext";

export default function TrendAnalysisPage() {
  const { kpiName } = useParams();
  const location = useLocation();
  const { selectedMonth } = useMonth();
  const { kpi: passedKpi, selectedPeriod = "", selectedMonthId = "" } = location.state || {};
  const [apiPayload, setApiPayload] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);

    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 12,
      llmTimeBudgetSeconds: 60,
    })
      .then((payload) => {
        if (!active) return;
        setApiPayload(payload);
      })
      .catch(async () => {
        try {
          const latestPayload = await fetchFrontendDashboard(undefined, 6, {
            ensureAnalysis: true,
            useLlm: true,
            maxLlmMetrics: 12,
            llmTimeBudgetSeconds: 60,
          });
          if (!active) return;
          setApiPayload(latestPayload);
        } catch {
          if (!active) return;
          setApiPayload(null);
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  const kpiFromApi = useMemo(() => {
    if (!apiPayload?.categories?.length) return null;

    const analysisByMetric = new Map();
    (apiPayload.analysis?.metrics || []).forEach((metric) => {
      const key = `${metric.category}::${metric.metric_name}::${metric.domain || "Unassigned"}::${metric.portfolio || "General"}`;
      analysisByMetric.set(key, metric);
    });

    const allKpis = apiPayload.categories.flatMap((category) =>
      (category.metrics || []).map((metric) => {
        const domain = metric.domain || "Unassigned";
        const portfolio = metric.portfolio || "General";
        const key = `${category.name}::${metric.name}::${domain}::${portfolio}`;
        const analysis = analysisByMetric.get(key);
        const history = (metric.history || []).map((item, index) => ({
          id: index + 1,
          period: item.month,
          value: item.value,
          status: "Amber",
          updated_at: item.month_id ? `${item.month_id}-01` : "",
        }));
        return {
          dimension: category.name,
          domain,
          portfolio,
          kpiname: metric.name,
          definition: analysis?.summary || `${metric.name} metric`,
          analysisSummary: analysis?.summary || "",
          analysisRecommendation: analysis?.recommendation || "",
          analysisTrend: analysis?.trend || "",
          analysisRisk: analysis?.risk || "",
          generatedMetric: analysis?.generated_metric,
          changeVsAvgPct: analysis?.change_vs_avg_pct,
          guidelines: { ideal: metric.unit === "%" ? "> 80%" : "" },
          value: metric.value,
          status: "Amber",
          updated_at: apiPayload.month_id ? `${apiPayload.month_id}-01` : "",
          history,
          insights: metric.insights || analysis?.insights || [],
          insightPoints: (metric.insights || analysis?.insights || []).map(
            (item) => `${item?.title || ""}: ${item?.description || ""}`.trim(),
          ),
          analysisHistory: metric.analysis_history || [],
        };
      }),
    );

    const slugMatches = allKpis.filter((k) => slugify(k.kpiname, { lower: true, strict: true }) === kpiName);
    if (passedKpi?.domain || passedKpi?.portfolio) {
      const exactMatch = slugMatches.find(
        (k) =>
          (!passedKpi.domain || k.domain === passedKpi.domain) &&
          (!passedKpi.portfolio || k.portfolio === passedKpi.portfolio),
      );
      if (exactMatch) return exactMatch;
    }
    return slugMatches[0] || null;
  }, [apiPayload, kpiName, passedKpi?.domain, passedKpi?.portfolio]);

  const kpi =
    kpiFromApi ||
    passedKpi ||
    kpiData.find((k) => slugify(k.kpiname, { lower: true, strict: true }) === kpiName);

  if (!kpi) {
    if (loading) {
      return <div className="p-6 text-gray-500">Loading trend analysis...</div>;
    }
    return <div className="p-6 text-red-500">KPI not found</div>;
  }

  const lastSix = [...kpi.history].slice(-6).reverse();
  const categories = lastSix.map((h) => h.period); 
  const values = lastSix.map((h) => h.value); 
  const threshold = parseThreshold(kpi.guidelines.ideal);
  const normalizedSelectedPeriod = selectedPeriod.trim().toLowerCase();

  const history = Array.isArray(kpi.analysisHistory) ? kpi.analysisHistory : [];
  const filtered = history.filter((entry) => {
    if (!entry) return false;
    const entryMonthId = String(entry.month_id || "").trim();
    const entryMonthLabel = String(entry.month || "").trim().toLowerCase();

    if (selectedMonthId && entryMonthId === selectedMonthId) return true;
    if (normalizedSelectedPeriod && entryMonthLabel === normalizedSelectedPeriod) return true;

    return false;
  });
  const filteredAnalysisHistory =
    selectedMonthId || normalizedSelectedPeriod
      ? filtered.length > 0
        ? filtered
        : history
      : history;

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 relative overflow-x-hidden p-4">
      {/* Decorative dark background orbs */}
      <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-indigo-900/40 to-transparent pointer-events-none" />
      <div className="absolute top-[10%] left-[-5%] w-[300px] h-[300px] rounded-full bg-cyan-600/20 blur-[100px] pointer-events-none" />

      <div className="flex items-center gap-4 mb-6 z-10">
        <button
          onClick={() => window.history.back()}
          className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 shadow-xl transition-all border border-slate-700"
        >
          <IoMdArrowRoundBack size={24} />
        </button>

        <h1 className="text-2xl font-bold text-white tracking-tight drop-shadow-md">
          {kpi.kpiname} <span className="text-cyan-400 font-medium ml-2">Trend Analysis</span>
        </h1>
      </div>
      <div className="z-10 mb-4 flex flex-wrap gap-3 text-sm text-slate-200">
        <span className="rounded-lg border border-slate-600 bg-slate-800 px-3 py-1.5">
          Domain: <span className="font-semibold text-white">{kpi.domain || "Unassigned"}</span>
        </span>
        <span className="rounded-lg border border-slate-600 bg-slate-800 px-3 py-1.5">
          Portfolio: <span className="font-semibold text-white">{kpi.portfolio || "General"}</span>
        </span>
      </div>
      
      <main className="flex-1 flex flex-col w-full max-w-[1600px] mx-auto z-10 bg-slate-800/60 backdrop-blur-md rounded-2xl p-6 mb-8 border border-slate-700/50 shadow-xl">
        <div className="bg-white rounded-xl p-4 shadow-inner">
          {/* PlotLineChart might expect a light background for Highcharts/Chart.js readability unless we inject a dark theme to it. Wrapping it in a white container keeps the chart legible while the rest of the page is dark. */}
          <PlotLineChart
            title={kpi.kpiname}
            categories={categories}
            values={values}
            threshold={threshold}
            guidelines={kpi.guidelines}
            insights={kpi.insights || []}
            insightPoints={kpi.insightPoints || []}
            analysisHistory={filteredAnalysisHistory}
            metricAnalysis={{
              summary: kpi.analysisSummary,
              recommendation: kpi.analysisRecommendation,
              trend: kpi.analysisTrend,
              risk: kpi.analysisRisk,
              generatedMetric: kpi.generatedMetric,
              changeVsAvgPct: kpi.changeVsAvgPct,
            }}
          />
        </div>
      </main>
    </div>
  );
}
