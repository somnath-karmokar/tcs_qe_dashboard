import React from "react";

export default function Footer() {
  return (
    <footer className="bg-slate-800/50 backdrop-blur-md border border-slate-700/50 mx-2 mt-4 mb-2 text-center py-5 rounded-xl flex flex-col items-center justify-center">
      <span className="text-slate-400 font-medium text-base tracking-wide">
        © 2026 Enterprise Quality Metrics. All rights reserved.
      </span>
    </footer>
  );
}
