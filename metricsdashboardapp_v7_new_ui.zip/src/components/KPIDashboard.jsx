import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import kpiDataOriginal from "../data/mockData.json";
import slugify from "slugify";
import { useMonth } from "../context/MonthContext";
import { fetchFrontendDashboard } from "../services/monthlyMetricsApi";
import { Code2, Zap, Users, ShieldCheck, ArrowUpRight, ArrowDownRight, Minus, Filter } from "lucide-react";

export default function KPIDashboard() {
  const navigate = useNavigate();
  const { selectedMonth } = useMonth();
  const [apiPayload, setApiPayload] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isLatestFallback, setIsLatestFallback] = useState(false);
  const [selectedDomain, setSelectedDomain] = useState("All");
  const [selectedPortfolio, setSelectedPortfolio] = useState("All");

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    setIsLatestFallback(false);

    fetchFrontendDashboard(selectedMonth, 6, {
      ensureAnalysis: true,
      useLlm: true,
      maxLlmMetrics: 12,
      llmTimeBudgetSeconds: 60,
    })
      .then((payload) => {
        if (!active) return;
        setApiPayload(payload);
      })
      .catch(async (err) => {
        if (!active) return;
        try {
          const latestPayload = await fetchFrontendDashboard(undefined, 6, {
            ensureAnalysis: true,
            useLlm: true,
            maxLlmMetrics: 12,
            llmTimeBudgetSeconds: 60,
          });
          if (!active) return;
          setApiPayload(latestPayload);
          setIsLatestFallback(true);
          setError(err?.message || "Selected month not available. Showing latest updated metrics.");
        } catch (fallbackErr) {
          if (!active) return;
          setApiPayload(null);
          setError(fallbackErr?.message || "Unable to load dashboard data from API.");
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedMonth]);

  const getKPIDataForMonth = (month) => {
    return kpiDataOriginal
      .map((kpi) => {
        const monthData = kpi.history.find((h) => h.period === month);
        if (!monthData) return null;
        return {
          dimension: kpi.dimension,
          domain: kpi.domain || "Unassigned",
          portfolio: kpi.portfolio || "General",
          kpiname: kpi.kpiname,
          definition: kpi.definition,
          guidelines: kpi.guidelines,
          value: monthData.value,
          status: monthData.status,
          updated_at: monthData.updated_at,
          history: kpi.history,
        };
      })
      .filter(Boolean);
  };

  const buildStatusFromSeries = (history, risk = "") => {
    if (Array.isArray(history) && history.length >= 2) {
      const [current, previous] = history;
      if (typeof current?.value === "number" && typeof previous?.value === "number") {
        const delta = current.value - previous.value;
        if (delta > 0) return "Green";
      }
    }

    const riskLower = String(risk).toLowerCase();
    if (riskLower === "low") return "Green";
    if (riskLower === "normal") return "Green";
    if (riskLower === "high") return "Red";
    if (riskLower === "medium") return "Amber";

    if (!Array.isArray(history) || history.length < 2) return "Amber";
    const [current, previous] = history;
    if (typeof current?.value !== "number" || typeof previous?.value !== "number") return "Amber";
    const delta = current.value - previous.value;
    if (delta >= 0) return "Green";
    if (delta > -5) return "Amber";
    return "Red";
  };

  const kpiData = useMemo(() => {
    if (!apiPayload?.categories?.length) {
      return getKPIDataForMonth(selectedMonth);
    }

    const analysisByMetric = new Map();
    (apiPayload.analysis?.metrics || []).forEach((metric) => {
      const key = `${metric.category}::${metric.metric_name}::${metric.domain || "Unassigned"}::${metric.portfolio || "General"}`;
      analysisByMetric.set(key, metric);
    });

    return apiPayload.categories.flatMap((category) =>
      (category.metrics || []).map((metric) => {
        const domain = metric.domain || "Unassigned";
        const portfolio = metric.portfolio || "General";
        const key = `${category.name}::${metric.name}::${domain}::${portfolio}`;
        const analysis = analysisByMetric.get(key);
        const history = (metric.history || []).map((item, index) => ({
          id: index + 1,
          period: item.month,
          value: item.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: item.month_id ? `${item.month_id}-01` : "",
        }));
        return {
          dimension: category.name,
          domain,
          portfolio,
          kpiname: metric.name,
          definition: analysis?.summary || `${metric.name} metric`,
          analysisSummary: analysis?.summary || "",
          analysisRecommendation: analysis?.recommendation || "",
          analysisTrend: analysis?.trend || "",
          analysisRisk: analysis?.risk || "",
          generatedMetric: analysis?.generated_metric,
          changeVsAvgPct: analysis?.change_vs_avg_pct,
          guidelines: { ideal: metric.unit === "%" ? "> 80%" : "" },
          value: metric.value,
          status: buildStatusFromSeries(metric.history, analysis?.risk),
          updated_at: apiPayload.month_id ? `${apiPayload.month_id}-01` : "",
          history,
          insights: metric.insights || analysis?.insights || [],
          insightPoints: (metric.insights || analysis?.insights || []).map(
            (item) => `${item?.title || ""}: ${item?.description || ""}`.trim(),
          ),
        };
      }),
    );
  }, [apiPayload, selectedMonth]);
  const dataMonthLabel = apiPayload?.dashboard?.month || selectedMonth;
  const analysisMeta = apiPayload?.analysis || null;
  const domainOptions = useMemo(
    () => ["All", ...Array.from(new Set(kpiData.map((kpi) => kpi.domain || "Unassigned"))).sort()],
    [kpiData],
  );
  const portfolioOptions = useMemo(() => {
    const available = kpiData
      .filter((kpi) => selectedDomain === "All" || (kpi.domain || "Unassigned") === selectedDomain)
      .map((kpi) => kpi.portfolio || "General");
    return ["All", ...Array.from(new Set(available)).sort()];
  }, [kpiData, selectedDomain]);

  useEffect(() => {
    if (!portfolioOptions.includes(selectedPortfolio)) {
      setSelectedPortfolio("All");
    }
  }, [portfolioOptions, selectedPortfolio]);

  const filteredKpiData = useMemo(
    () =>
      kpiData.filter((kpi) => {
        const domainMatch = selectedDomain === "All" || (kpi.domain || "Unassigned") === selectedDomain;
        const portfolioMatch =
          selectedPortfolio === "All" || (kpi.portfolio || "General") === selectedPortfolio;
        return domainMatch && portfolioMatch;
      }),
    [kpiData, selectedDomain, selectedPortfolio],
  );

  const groupedData = filteredKpiData.reduce((acc, kpi) => {
    if (!acc[kpi.dimension]) acc[kpi.dimension] = [];
    acc[kpi.dimension].push(kpi);
    return acc;
  }, {});
  const preferredDimensions = ["Engineering", "Velocity", "Collaboration", "Quality"];
  const visibleDimensions = [
    ...preferredDimensions.filter((dimension) => groupedData[dimension]?.length),
    ...Object.keys(groupedData)
      .filter((dimension) => !preferredDimensions.includes(dimension))
      .sort(),
  ];

  const renderKpiCard = (kpi) => {
    const historyValues = Array.isArray(kpi.history)
      ? kpi.history
          .map((item) => Number(item?.value))
          .filter((value) => Number.isFinite(value))
      : [];
    const isUpward = historyValues.length >= 2 && historyValues[0] > historyValues[1];
    const normalizedStatus = String(kpi.status || "").toLowerCase();
    const isPositive = isUpward || normalizedStatus === "green" || normalizedStatus === "normal";
    const isWarning = normalizedStatus === "amber";
    const isCritical = !isPositive && normalizedStatus === "red";
    const cardTone = isPositive
      ? {
          card: "from-green-400 via-green-500 to-emerald-700 border-green-200/80 shadow-green-950/25",
          glow: "bg-green-100/45",
          text: "text-white",
          subtext: "text-green-50/90",
          value: "text-white",
          badge: "bg-white/18 text-white border-white/25",
          icon: "bg-white text-green-700",
          accent: "bg-green-100",
        }
      : isCritical
        ? {
            card: "from-rose-500 via-red-600 to-rose-800 border-rose-300/70 shadow-rose-950/25",
            glow: "bg-rose-200/35",
            text: "text-white",
            subtext: "text-rose-50/90",
            value: "text-white",
            badge: "bg-white/18 text-white border-white/25",
            icon: "bg-white text-rose-700",
            accent: "bg-rose-200",
          }
        : {
            card: "from-amber-300 via-orange-400 to-amber-600 border-amber-100/80 shadow-amber-950/25",
            glow: "bg-white/35",
            text: "text-slate-950",
            subtext: "text-slate-900/80",
            value: "text-slate-950",
            badge: "bg-white/30 text-slate-950 border-white/35",
            icon: "bg-slate-950 text-amber-200",
            accent: "bg-white",
          };
    
    return (
      <div
        key={kpi.kpiname}
        onClick={() =>
          navigate(
            `/kpi/${slugify(kpi.kpiname, { lower: true, strict: true })}`,
            { state: { kpi } },
          )
        }
        className={`group cursor-pointer bg-gradient-to-br ${cardTone.card} border rounded-xl shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 p-3.5 flex flex-col justify-between h-[118px] overflow-hidden relative`}
      >
        <div className={`absolute -right-8 -top-10 h-24 w-24 rounded-full ${cardTone.glow} blur-2xl pointer-events-none transition-transform duration-300 group-hover:scale-125`} />
        <div className={`absolute left-0 top-0 h-full w-1 ${cardTone.accent} pointer-events-none`} />
        <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-colors pointer-events-none" />
        <div className="flex justify-between items-start w-full z-10">
          <p className={`text-sm ${cardTone.text} font-bold leading-snug line-clamp-2 pr-2`}>
            {kpi.kpiname}
          </p>
          <div className={`flex items-center justify-center w-7 h-7 rounded-full shrink-0 shadow-md ${cardTone.icon}`}>
            {isPositive ? <ArrowUpRight size={12} strokeWidth={3} /> :
             isCritical ? <ArrowDownRight size={12} strokeWidth={3} /> :
             <Minus size={12} strokeWidth={3} />}
          </div>
        </div>
        
        <div className="flex items-end justify-between gap-3 w-full z-10 mt-3">
          <div className="min-w-0">
            <span className={`block text-3xl font-extrabold tracking-tight ${cardTone.value}`}>
              {kpi.value}
            </span>
          </div>
          <p className={`max-w-[52%] rounded-full border px-2.5 py-1 text-[11px] ${cardTone.badge} font-bold uppercase text-right leading-tight truncate`}>
            {kpi.portfolio}
          </p>
        </div>
      </div>
    );
  };

  const getDimensionConfig = (dimension) => {
    switch(dimension) {
      case "Engineering": return { icon: Code2, bg: "bg-gradient-to-br from-indigo-600 to-purple-800", glow: "bg-purple-500/50" };
      case "Velocity": return { icon: Zap, bg: "bg-gradient-to-br from-orange-500 to-rose-700", glow: "bg-rose-500/50" };
      case "Collaboration": return { icon: Users, bg: "bg-gradient-to-br from-blue-500 to-cyan-700", glow: "bg-cyan-500/50" };
      case "Quality": return { icon: ShieldCheck, bg: "bg-gradient-to-br from-emerald-500 to-teal-800", glow: "bg-teal-500/50" };
      default: return { icon: Code2, bg: "bg-gradient-to-br from-slate-600 to-slate-800", glow: "bg-slate-500/50" };
    }
  };

  const renderDimensionCards = (dimension) => {
    const config = getDimensionConfig(dimension);
    const Icon = config.icon;
    
    return (
      <div className={`${config.bg} rounded-2xl p-5 flex flex-col h-full animate-fade-in relative overflow-hidden shadow-xl border border-white/10`}>
        <div className={`absolute -right-10 -top-10 w-40 h-40 rounded-full ${config.glow} blur-3xl pointer-events-none`} />
        
        <div className="flex items-center space-x-3 mb-5 relative z-10">
          <div className="p-3 rounded-xl bg-black/20 border border-white/10 shadow-sm backdrop-blur-sm">
            <Icon size={24} className="text-white" />
          </div>
          <h3 className="text-xl font-bold text-white tracking-wide drop-shadow-md">
            {dimension}
          </h3>
        </div>
        
        <div className="grid grid-cols-2 gap-4 flex-1 relative z-10">
          {groupedData[dimension]?.map((kpi) => renderKpiCard(kpi))}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full flex flex-col relative pb-12">
      {loading && (
        <div className="flex justify-center items-center py-12">
          <div className="animate-pulse-slow px-6 py-3 bg-slate-800/80 backdrop-blur-md text-brand-400 rounded-full text-base font-medium border border-slate-700 shadow-xl flex items-center space-x-3">
            <div className="w-5 h-5 rounded-full border-2 border-brand-400 border-t-transparent animate-spin" />
            <span>Loading dashboard metrics...</span>
          </div>
        </div>
      )}
      
      {!loading && error && (
        <div className="mx-auto mt-2 mb-6 bg-rose-900/50 backdrop-blur-md border border-rose-500/50 rounded-xl px-6 py-4 text-base text-rose-200 max-w-2xl text-center shadow-xl">
          {error}
        </div>
      )}

      {!loading && (
        <div className="mx-auto mb-6 w-full max-w-4xl bg-slate-800/80 backdrop-blur-md rounded-xl px-5 py-4 border border-slate-600 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-end gap-4">
            <div className="flex items-center gap-2 text-slate-100 font-semibold min-w-[140px]">
              <Filter size={18} className="text-cyan-300" />
              <span>Filters</span>
            </div>
            <label className="flex-1 text-sm text-slate-300">
              <span className="block mb-1 font-medium">Domain</span>
              <select
                value={selectedDomain}
                onChange={(event) => {
                  setSelectedDomain(event.target.value);
                  setSelectedPortfolio("All");
                }}
                className="w-full rounded-lg border border-slate-500 bg-slate-900 px-3 py-2 text-white outline-none focus:border-cyan-400"
              >
                {domainOptions.map((domain) => (
                  <option key={domain} value={domain}>
                    {domain}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex-1 text-sm text-slate-300">
              <span className="block mb-1 font-medium">Portfolio</span>
              <select
                value={selectedPortfolio}
                onChange={(event) => setSelectedPortfolio(event.target.value)}
                className="w-full rounded-lg border border-slate-500 bg-slate-900 px-3 py-2 text-white outline-none focus:border-cyan-400"
              >
                {portfolioOptions.map((portfolio) => (
                  <option key={portfolio} value={portfolio}>
                    {portfolio}
                  </option>
                ))}
              </select>
            </label>
            <div className="text-sm text-slate-300 md:text-right">
              <span className="block font-semibold text-white">{filteredKpiData.length}</span>
              <span>metrics shown</span>
            </div>
          </div>
        </div>
      )}

      {!loading && !error && analysisMeta && (
        <div className="mx-auto mb-8 w-full max-w-4xl bg-slate-800/80 backdrop-blur-md rounded-2xl px-8 py-5 text-base text-slate-100 flex flex-wrap items-center justify-between gap-4 shadow-xl border border-slate-600">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_12px_rgba(52,211,153,1)]" />
            <span className="font-medium text-slate-200">Analysis month: <span className="font-bold text-white ml-1">{analysisMeta.month || dataMonthLabel}</span></span>
          </div>
          <div className="hidden sm:block w-px h-6 bg-slate-500" />
          <div className="font-medium text-slate-200">
            Score: <span className="font-bold text-white bg-brand-600 px-3 py-1.5 rounded-md border border-brand-500 ml-1 text-lg">{analysisMeta.overall_generated_metric ?? "NA"}</span>
          </div>
          <div className="hidden sm:block w-px h-6 bg-slate-500" />
          <div className="text-sm text-slate-300 font-medium">
            Generated: <span className="text-white">{analysisMeta.generated_at || "NA"}</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 xl:gap-8 w-full max-w-[1400px] mx-auto z-10">
        {visibleDimensions.map((dimension) => renderDimensionCards(dimension))}
      </div>
      {!loading && visibleDimensions.length === 0 && (
        <div className="mx-auto mt-6 rounded-xl border border-slate-600 bg-slate-800/80 px-6 py-5 text-slate-200">
          No metrics match the selected domain and portfolio.
        </div>
      )}
    </div>
  );
}
