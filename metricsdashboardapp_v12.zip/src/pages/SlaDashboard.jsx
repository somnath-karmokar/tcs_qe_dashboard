import React, { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  Download,
  FileSpreadsheet,
  FileText,
  Printer,
  ShieldCheck,
} from "lucide-react";
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  CategoryScale,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
} from "chart.js";
import { Bar, Doughnut, Line } from "react-chartjs-2";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { SAMPLE_SLA_CSV, STATUS_STYLES } from "../data/qeKpiSlaConfig";
import {
  buildExcelHtml,
  buildReportRows,
  buildSlaDashboard,
  downloadText,
  parseSlaCsv,
  toCsv,
} from "../utils/qeKpiAnalytics";
import { fetchSlaDashboardRows } from "../services/slaDashboardApi";

ChartJS.register(
  ArcElement,
  BarElement,
  CategoryScale,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
);

const colors = {
  green: "#10b981",
  amber: "#f59e0b",
  red: "#ef4444",
  cyan: "#06b6d4",
  indigo: "#6366f1",
  slate: "#64748b",
};

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { labels: { color: "#cbd5e1", font: { weight: 700 } } },
    tooltip: { backgroundColor: "#0f172a", borderColor: "#334155", borderWidth: 1 },
  },
  scales: {
    x: { grid: { color: "rgba(148,163,184,0.14)" }, ticks: { color: "#cbd5e1" } },
    y: { grid: { color: "rgba(148,163,184,0.14)" }, ticks: { color: "#cbd5e1" }, beginAtZero: true },
  },
};

function tone(status) {
  return STATUS_STYLES[status] || STATUS_STYLES.Red;
}

function StatusPill({ status }) {
  const style = tone(status);
  return (
    <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-black ${style.bg} ${style.border} ${style.text}`}>
      {style.label}
    </span>
  );
}

function Panel({ title, icon: Icon, children, className = "" }) {
  return (
    <section className={`rounded-2xl border border-slate-700/50 bg-slate-800/55 p-5 shadow-xl backdrop-blur-md ${className}`}>
      <div className="mb-4 flex items-center gap-3">
        <div className="rounded-xl border border-cyan-400/25 bg-cyan-500/10 p-2 text-cyan-300">
          <Icon size={18} />
        </div>
        <h2 className="text-lg font-black tracking-normal text-white">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function SummaryCard({ label, value, helper, status, icon: Icon }) {
  const style = tone(status);
  return (
    <div className={`relative overflow-hidden rounded-2xl border bg-slate-800/70 p-5 shadow-xl backdrop-blur-md ${style.border}`}>
      <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${style.rail}`} />
      <div className={`absolute -right-12 -top-12 h-32 w-32 rounded-full ${style.strongBg} opacity-10 blur-2xl`} />
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-black uppercase tracking-normal text-slate-400">{label}</p>
          <p className={`mt-3 text-4xl font-black leading-none ${style.text}`}>{value}</p>
          <p className="mt-2 text-sm font-semibold text-slate-300">{helper}</p>
        </div>
        <div className={`${style.bg} ${style.text} rounded-xl p-3`}>
          <Icon size={22} />
        </div>
      </div>
    </div>
  );
}

function KpiCard({ kpi }) {
  const style = tone(kpi.status);
  return (
    <div className={`relative min-h-[190px] overflow-hidden rounded-2xl border bg-slate-800/70 p-5 shadow-xl backdrop-blur-md ${style.border}`}>
      <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${style.rail}`} />
      <div className={`absolute -right-12 -top-12 h-32 w-32 rounded-full ${style.strongBg} opacity-10 blur-2xl`} />
      <div className="relative flex h-full flex-col justify-between gap-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-base font-black leading-snug text-white">{kpi.name}</p>
            <p className="mt-1 text-xs font-black uppercase tracking-normal text-slate-400">Weight {kpi.weightage}%</p>
          </div>
          <StatusPill status={kpi.status} />
        </div>
        <div>
          <p className={`text-4xl font-black leading-none ${style.text}`}>{kpi.displayValue}</p>
          <div className="mt-3 grid grid-cols-2 gap-2 text-xs font-bold">
            <span className="rounded-lg border border-slate-700 bg-slate-900/70 px-2 py-2 text-slate-300">Target {kpi.targetLabel}</span>
            <span className="rounded-lg border border-slate-700 bg-slate-900/70 px-2 py-2 text-slate-300">Risk {kpi.risk}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function lineData(labels, datasets) {
  return {
    labels,
    datasets: datasets.map((dataset) => ({
      fill: true,
      tension: 0.35,
      pointRadius: 4,
      pointHoverRadius: 6,
      borderWidth: 2,
      backgroundColor: `${dataset.color}20`,
      borderColor: dataset.color,
      ...dataset,
    })),
  };
}

function barData(labels, values, colorSet) {
  return {
    labels,
    datasets: [{ data: values, backgroundColor: colorSet, borderRadius: 8 }],
  };
}

function donutData(items) {
  return {
    labels: items.map((item) => item.label),
    datasets: [
      {
        data: items.map((item) => item.value),
        backgroundColor: [colors.red, colors.amber, colors.cyan, colors.green, colors.indigo],
        borderColor: "#ffffff",
        borderWidth: 3,
      },
    ],
  };
}

export default function SlaDashboard() {
  const navigate = useNavigate();
  const [uploadedRows, setUploadedRows] = useState([]);
  const [dataSource, setDataSource] = useState("sample");
  const [loadMessage, setLoadMessage] = useState("");

  useEffect(() => {
    let active = true;
    fetchSlaDashboardRows()
      .then((rows) => {
        if (!active) return;
        if (rows.length) {
          setUploadedRows(rows);
          setDataSource("uploaded");
          setLoadMessage("");
        } else {
          setDataSource("sample");
          setLoadMessage("No uploaded SLA CSV found yet. Showing sample data.");
        }
      })
      .catch((error) => {
        if (!active) return;
        setDataSource("sample");
        setLoadMessage(`Unable to load uploaded SLA CSV. Showing sample data. ${error.message || ""}`.trim());
      });
    return () => {
      active = false;
    };
  }, []);

  const dashboard = useMemo(() => {
    if (uploadedRows.length) return buildSlaDashboard(uploadedRows);
    const parsed = parseSlaCsv(SAMPLE_SLA_CSV);
    return buildSlaDashboard(parsed.rows);
  }, [uploadedRows]);

  const latest = dashboard.latest;
  const months = dashboard.months;
  const labels = months.map((month) => month.month);

  const downloadCsvReport = () => {
    downloadText(`sla-dashboard-${latest.month}.csv`, toCsv(buildReportRows(dashboard)), "text/csv");
  };

  const downloadExcelReport = () => {
    downloadText(`sla-dashboard-${latest.month}.xls`, buildExcelHtml(dashboard), "application/vnd.ms-excel");
  };

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-slate-900 font-inter text-slate-100">
      <div className="absolute top-[-10%] right-[-5%] h-[600px] w-[600px] rounded-full bg-fuchsia-600/20 blur-[120px] pointer-events-none" />
      <div className="absolute top-[40%] left-[-10%] h-[500px] w-[500px] rounded-full bg-cyan-500/20 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[20%] h-[400px] w-[400px] rounded-full bg-emerald-500/10 blur-[100px] pointer-events-none" />
      <Header />
      <main className="relative z-10 mx-auto flex w-full max-w-[1500px] flex-1 flex-col gap-6 px-4 pb-10">
        <section className="relative overflow-hidden rounded-3xl border border-slate-700/50 bg-slate-800/55 p-6 shadow-xl backdrop-blur-md">
          <div className="absolute inset-x-0 top-0 h-2 bg-gradient-to-r from-cyan-500 via-emerald-500 to-amber-500" />
          <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
            <div>
              <button
                type="button"
                onClick={() => navigate("/")}
                className="mb-5 inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/70 px-4 py-2 text-sm font-black text-slate-300 shadow-sm hover:border-cyan-400/60 hover:text-white"
              >
                <ArrowLeft size={16} />
                Back
              </button>
              <p className="text-sm font-black uppercase tracking-[0.18em] text-cyan-300">Enterprise SLA Governance</p>
              <h1 className="mt-2 text-4xl font-black tracking-normal text-white md:text-5xl">SLA Dashboard</h1>
              <p className="mt-3 max-w-4xl text-base font-medium leading-relaxed text-slate-300">
                Quality Engineering KPI cockpit for SLA health, service credit exposure, defect leakage, release readiness, and automation stability.
              </p>
              <p className="mt-3 inline-flex rounded-full border border-cyan-400/25 bg-cyan-500/10 px-3 py-1 text-xs font-black text-cyan-200">
                Data source: {dataSource === "uploaded" ? "Streamlit uploaded SLA CSV" : "Sample SLA data"}
              </p>
              {loadMessage && <p className="mt-2 text-sm font-semibold text-amber-200">{loadMessage}</p>}
            </div>
            <div className="flex flex-wrap gap-3">
              <button type="button" onClick={downloadCsvReport} className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/70 px-4 py-2 text-sm font-black text-slate-300 hover:border-cyan-400/60 hover:text-white">
                <FileText size={16} />
                CSV
              </button>
              <button type="button" onClick={downloadExcelReport} className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/70 px-4 py-2 text-sm font-black text-slate-300 hover:border-cyan-400/60 hover:text-white">
                <FileSpreadsheet size={16} />
                Excel
              </button>
              <button type="button" onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-xl bg-cyan-600 px-4 py-2 text-sm font-black text-white shadow-lg shadow-cyan-600/25 hover:bg-cyan-700">
                <Printer size={16} />
                PDF
              </button>
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
          <SummaryCard label="Overall SLA Score" value={`${latest.score}%`} helper={`Month ${latest.month}`} status={latest.status} icon={ShieldCheck} />
          <SummaryCard label="Service Credit Risk" value={`${latest.serviceCreditRisk}%`} helper="Potential exposure" status={latest.serviceCreditRisk > 0 ? latest.status : "Green"} icon={AlertTriangle} />
          <SummaryCard label="Failed KPIs" value={latest.failedKpis} helper={`${latest.warningKpis} KPI(s) in warning`} status={latest.failedKpis ? "Red" : latest.warningKpis ? "Amber" : "Green"} icon={BarChart3} />
          <SummaryCard label="Critical KPI Count" value={latest.criticalKpis} helper="High-weight breaches" status={latest.criticalKpis ? "Red" : "Green"} icon={AlertTriangle} />
          <SummaryCard label="Trend Direction" value={dashboard.trend} helper="Compared with previous month" status={dashboard.trend === "Declining" ? "Amber" : "Green"} icon={ShieldCheck} />
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {latest.kpis.map((kpi) => (
            <KpiCard key={kpi.id} kpi={kpi} />
          ))}
        </div>

        <Panel title="SLA Trend Analysis" icon={BarChart3}>
          <div className="h-[320px] w-full">
            <Line
              data={lineData(labels, [
                { label: "Overall SLA Score", data: months.map((month) => month.score), color: colors.cyan },
                { label: "DRE", data: months.map((month) => month.kpis.find((kpi) => kpi.id === "dre").value), color: colors.green },
                { label: "Automation Stability", data: months.map((month) => month.kpis.find((kpi) => kpi.id === "automationStability").value), color: colors.indigo },
              ])}
              options={chartOptions}
            />
          </div>
        </Panel>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <Panel title="Defect Leakage Trend" icon={AlertTriangle}>
            <div className="h-[280px] w-full">
              <Bar
                data={barData(
                  labels,
                  months.map((month) => month.sev1 + month.sev2),
                  months.map((month) => (month.sev1 > 0 ? colors.red : month.sev2 > 2 ? colors.amber : colors.green)),
                )}
                options={{ ...chartOptions, plugins: { ...chartOptions.plugins, legend: { display: false } } }}
              />
            </div>
          </Panel>
          <Panel title="Severity And Defect Status" icon={FileText}>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="h-[280px]">
                <Doughnut data={donutData(dashboard.severityDistribution)} options={{ ...chartOptions, scales: undefined }} />
              </div>
              <div className="h-[280px]">
                <Doughnut data={donutData(dashboard.defectStatus)} options={{ ...chartOptions, scales: undefined }} />
              </div>
            </div>
          </Panel>
        </div>

        <Panel title="SLA Breach Heatmap" icon={ShieldCheck}>
          <div className="mb-5 grid grid-cols-1 gap-3 md:grid-cols-3">
            <div className="rounded-xl border border-emerald-300/40 bg-emerald-500/25 px-4 py-3">
              <p className="text-sm font-black text-emerald-100">Healthy</p>
              <p className="mt-1 text-xs font-bold text-emerald-200">Meeting target. Full health line.</p>
            </div>
            <div className="rounded-xl border border-amber-300/40 bg-amber-500/25 px-4 py-3">
              <p className="text-sm font-black text-amber-100">Warning</p>
              <p className="mt-1 text-xs font-bold text-amber-200">Near threshold. Partial health line.</p>
            </div>
            <div className="rounded-xl border border-red-300/40 bg-red-500/25 px-4 py-3">
              <p className="text-sm font-black text-red-100">Breach</p>
              <p className="mt-1 text-xs font-bold text-red-200">Below SLA. Short health line.</p>
            </div>
          </div>
          <div className="grid w-full grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {dashboard.moduleRisk.map((item) => {
              const style = tone(item.status);
              const heatClass =
                item.status === "Red"
                  ? "bg-red-500/30 ring-1 ring-red-300/45 shadow-[0_0_32px_rgba(239,68,68,0.22)]"
                  : item.status === "Amber"
                    ? "bg-amber-400/30 ring-1 ring-amber-200/45 shadow-[0_0_32px_rgba(245,158,11,0.20)]"
                    : "bg-emerald-500/30 ring-1 ring-emerald-200/45 shadow-[0_0_32px_rgba(16,185,129,0.20)]";
              const trackClass =
                item.status === "Red"
                  ? "bg-red-950/60"
                  : item.status === "Amber"
                    ? "bg-amber-950/60"
                    : "bg-emerald-950/60";
              return (
                <div key={item.label} className={`rounded-2xl border p-5 ${heatClass} ${style.border}`}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <p className={`text-sm font-black ${style.text}`}>{item.label}</p>
                      <p className="mt-1 truncate text-base font-black text-white">{item.name}</p>
                    </div>
                    <div className={`shrink-0 rounded-full border px-3 py-1 text-xs font-black ${style.bg} ${style.border} ${style.text}`}>
                      {style.label}
                    </div>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    <div className="rounded-xl border border-white/10 bg-slate-900/45 px-3 py-2">
                      <p className="text-[11px] font-black uppercase text-slate-400">Actual</p>
                      <p className={`mt-1 text-lg font-black ${style.text}`}>{item.actual}</p>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-slate-900/45 px-3 py-2">
                      <p className="text-[11px] font-black uppercase text-slate-400">Target</p>
                      <p className="mt-1 text-lg font-black text-white">{item.target}</p>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center justify-between text-xs font-black text-slate-300">
                    <span>{item.message}</span>
                    <span>{item.value}% health</span>
                  </div>
                  <div className={`mt-2 h-4 rounded-full border border-white/10 ${trackClass} shadow-inner`}>
                    <div className={`h-full rounded-full ${style.strongBg} shadow-[0_0_18px_currentColor]`} style={{ width: `${item.value}%` }} />
                  </div>
                  <div className="mt-3 flex justify-end text-[11px] font-bold text-slate-400">
                    <span>Weight {item.weightage}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <Panel title="KPI Performance Grid" icon={FileSpreadsheet} className="xl:col-span-2">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[820px] text-left text-sm">
                <thead className="border-b border-slate-700 bg-slate-900/70 text-slate-300">
                  <tr>
                    <th className="px-3 py-3 font-black">KPI</th>
                    <th className="px-3 py-3 font-black">Actual</th>
                    <th className="px-3 py-3 font-black">Target</th>
                    <th className="px-3 py-3 font-black">Status</th>
                    <th className="px-3 py-3 font-black">Weight</th>
                    <th className="px-3 py-3 font-black">Penalty Exposure</th>
                  </tr>
                </thead>
                <tbody>
                  {latest.kpis.map((kpi) => (
                    <tr key={kpi.id} className="border-b border-slate-800">
                      <td className="px-3 py-3 font-black text-white">{kpi.name}</td>
                      <td className={`px-3 py-3 font-black ${tone(kpi.status).text}`}>{kpi.displayValue}</td>
                      <td className="px-3 py-3 font-bold text-slate-300">{kpi.targetLabel}</td>
                      <td className="px-3 py-3"><StatusPill status={kpi.status} /></td>
                      <td className="px-3 py-3 font-bold text-slate-300">{kpi.weightage}%</td>
                      <td className="px-3 py-3 font-bold text-slate-300">{kpi.status === "Red" ? `${kpi.weightage}%` : kpi.status === "Amber" ? `${Math.round(kpi.weightage / 2)}%` : "0%"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>

          <Panel title="Root Cause Analysis" icon={AlertTriangle}>
            <div className="space-y-3">
              {dashboard.observations.map((item) => (
                <div key={item} className="rounded-xl border border-cyan-400/20 bg-cyan-500/10 p-4 text-sm font-bold leading-relaxed text-cyan-50">
                  {item}
                </div>
              ))}
            </div>
          </Panel>
        </div>

        <Panel title="Service Credit Risk" icon={ShieldCheck}>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="rounded-2xl border border-slate-700 bg-slate-900/70 p-5">
              <p className="text-sm font-black uppercase text-slate-400">Potential Service Credit</p>
              <p className="mt-2 text-3xl font-black text-white">{latest.serviceCreditRisk}%</p>
            </div>
            <div className="rounded-2xl border border-slate-700 bg-slate-900/70 p-5">
              <p className="text-sm font-black uppercase text-slate-400">Highest Impact KPI</p>
              <p className="mt-2 text-2xl font-black text-white">
                {[...latest.kpis].sort((a, b) => b.weightage - a.weightage).find((kpi) => kpi.status !== "Green")?.shortName || "None"}
              </p>
            </div>
            <div className="rounded-2xl border border-slate-700 bg-slate-900/70 p-5">
              <p className="text-sm font-black uppercase text-slate-400">Release Health</p>
              <p className={`mt-2 text-3xl font-black ${tone(latest.status).text}`}>{tone(latest.status).label}</p>
            </div>
          </div>
        </Panel>
      </main>
      <Footer />
    </div>
  );
}
